<?php
include 'config.inc.php';  // Include the database connection

// Fetch categories for the dropdown
$query = "SELECT * FROM forum_categories ORDER BY name ASC";
$categories_result = $con->query($query);

// Fetch recent threads from the database
$query_threads = "SELECT forum_threads.id, forum_threads.title, forum_threads.created_at, forum_categories.name as category_name 
                  FROM forum_threads 
                  JOIN forum_categories ON forum_threads.category_id = forum_categories.id 
                  ORDER BY forum_threads.created_at DESC LIMIT 5";
$threads_result = $con->query($query_threads);

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $title = htmlspecialchars($_POST['title']);
    $description = htmlspecialchars($_POST['description']);
    $category_id = $_POST['category'];

    // Insert the thread into the database
    $insert_query = "INSERT INTO forum_threads (title, description, category_id, created_at) 
                     VALUES ('$title', '$description', '$category_id', NOW())";

    if ($con->query($insert_query) === TRUE) {
        echo "New thread created successfully!";
        header("Location: new_forum.php"); // Redirect to the home page after success
        exit;
    } else {
        echo "Error: " . $con->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">

    <style>
/* Global Styles */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(to right, #f4f4f9, #e6e6e6);
}

h1{
    margin: 0;
    color: #fff;
}

h2{
    color:#3b3c36;
}


/* Categories Section */
.categories {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    margin-bottom: 40px;
}

.categories h2 {
    font-size: 2em;
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

.categories h2 i {
    margin-right: 10px;
    color: #B40023;
}

.category-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.category-list li {
    background-color: #f9f9f9;
    padding: 14px 20px;
    margin-bottom: 12px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.category-list li:hover {
    background-color: #f1f1f1;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.category-list a {
    color: #B40023;
    font-weight: 600;
    text-decoration: none;
    display: flex;
    align-items: center;
    font-size: 1.1em;
}

.category-list a:hover {
    color: #9b001d;
}

.category-list a i {
    margin-right: 10px;
    font-size: 1.3em;
}
/* Recent Threads Section */
.recent-threads {
    margin: 0;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}

/* Title Styles */
.recent-threads h2 {
    font-size: 2.2em; /* Bigger title */
    color: #333;
    margin-bottom: 20px;
    font-weight: 600;
    text-transform: uppercase;
}

.recent-threads h2 i {
    margin-right: 10px;
    color: #B40023;
}

/* Thread List */
.thread-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

/* Thread Item */
.thread-item {
    background-color: #fff;
    padding: 18px;
    margin-bottom: 12px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.thread-item:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.thread-item a {
    color: #B40023;
    font-weight: 600;
    text-decoration: none;
    display: flex;
    align-items: center;
    font-size: 1.1em;
    margin-bottom: 8px;
    transition: color 0.3s ease;
}

.thread-item a:hover {
    color: #9b001d;
}

.thread-item a i {
    margin-right: 12px;
}

.thread-item span {
    font-size: 0.9em;
    color: #777;
    display: flex;
    align-items: center;
}

.thread-item span i {
    margin-right: 6px;
    color: #B40023;
}

/* Responsive Design */
@media (max-width: 1024px) {
    .recent-threads h2 {
        font-size: 2em; /* Slightly smaller font for tablets */
    }

    .thread-item {
        padding: 16px;
    }

    .thread-item a {
        font-size: 1em;
    }

    .thread-item span {
        font-size: 0.8em;
    }
}

/* Mobile-First Design */
@media (max-width: 768px) {
    .recent-threads {
        padding: 15px;
    }

    .recent-threads h2 {
        font-size: 1.6em; /* Smaller title for mobile */
        margin-bottom: 15px;
    }

    .thread-item {
        padding: 14px;
        margin-bottom: 10px;
    }

    .thread-item a {
        font-size: 0.95em;
        margin-bottom: 6px;
    }

    .thread-item span {
        font-size: 0.8em;
    }
}


/* Buttons */
a.button {
    display: inline-block;
    padding: 12px 20px;
    background-color: #B40023;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

a.button:hover {
    background-color: #9b001d;
}

/* Container */
.container-forum {
    width: 90%;
    max-width: 1200px;
    margin: 40px auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    position: relative; /* Keeps the container content in place */
}

/* Background Shapes (Bouncing Animation) */
.shape {
    position: fixed;
    width: 300px;
    height: 300px;
    background-color: #B40023;
    opacity: 0.1;
    border-radius: 50%;
    z-index: -1;
    animation: bounceShape 15s ease-in-out infinite; /* Bouncing effect */
}

/* Keyframes for Bouncing Animation */
@keyframes bounceShape {
    0% {
        transform: translateX(0) translateY(0); /* Start at the top-left corner */
    }
    25% {
        transform: translateX(80vw) translateY(20vh); /* Move to the right and slightly down */
    }
    50% {
        transform: translateX(40vw) translateY(80vh); /* Move to the middle and lower */
    }
    75% {
        transform: translateX(10vw) translateY(20vh); /* Move to the left and slightly down */
    }
    100% {
        transform: translateX(0) translateY(0); /* Return to the top-left */
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .container-forum {
        width: 90%;
    }

    .categories h2 {
        font-size: 1.4em;
    }

    .category-list li {
        padding: 10px 15px;
    }

    .category-list a {
        font-size: 0.9em;
    }

    .category-list a i {
        font-size: 1.1em;
    }
    .recent-threads h2{
        font-size: 1.4em;
    }
}

@media (max-width: 480px) {
    .category-list li, .thread-list li {
        padding: 10px;
    }

    .thread-item span {
        font-size: 0.7em;
    }
}


/* Modal form container */
.modal-content {
    background-color: #fff;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    max-width: 40%; /* Make modal 40% of the screen width */
    margin: 0 auto;
    position: relative;
    min-width: 300px; /* Ensure it's not too small on very narrow screens */
}

/* Close button */
.close {
    position: absolute;
    top: 10px;
    right: 15px;
    color: #aaa;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

/* Close button hover effect */
.close:hover,
.close:focus {
    color: #333;
    text-decoration: none;
}

/* Form label */
form label {
    font-size: 16px;
    font-weight: 500;
    color: #333;
    margin-bottom: 8px;
    display: block;
}

/* Form input */
form input[type="text"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 16px;
    outline: none;
    transition: all 0.3s ease;
}

/* Input focus effect */
form input[type="text"]:focus {
    border-color: #B40023;
    box-shadow: 0 0 5px rgba(180, 0, 35, 0.4);
}

/* Submit button */
form button {
    width: 100%;
    padding: 12px;
    background-color: #B40023;
    color: #fff;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

/* Submit button hover effect */
form button:hover {
    background-color: #9b0020;
}

/* Form input and button: Focused or active state */
form input:focus, form button:active {
    outline: none;
}

label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }
        input, textarea, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }


</style>
</head>
<body>
<?php include('header.inc.php'); ?>

<!-- Background Shapes -->
<div class="shape"></div>
<div class="shape"></div>

<div class="container-forum">
<a href="javascript:void(0);" class="button" id="openModalButton">
    <i class="fas fa-plus"></i> Create a New Category
</a>

<!-- Modal -->
<div id="categoryModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span id="closeModal" class="close">&times;</span>
        <div class="form-container">
            <form action="add_category.php" method="POST">
                <label for="category_name">Category Name</label>
                <input type="text" id="category_name" name="category_name" required>
                <button type="submit">Create Category</button>
            </form>
        </div>
    </div>
</div>


<!-- Categories Section -->
<div class="categories">
    <h2><i class="fas fa-th-list"></i> Forum Categories</h2>
    <ul class="category-list">
        <?php while ($category = $categories_result->fetch_assoc()): ?>
            <li>
                <a href="forum_category.php?id=<?= $category['id'] ?>">
                    <i class="fas fa-folder-open"></i> <?= htmlspecialchars($category['name']) ?>
                </a>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="javascript:void(0);" class="button" id="openThreadModalButton">
    <i class="fas fa-comment-dots"></i> Create a New Thread
</a>

<!-- Modal for Creating a New Thread -->
<div id="threadModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span id="closeThreadModal" class="close">&times;</span>
        <div class="form-container">
        <form method="POST">
            <label for="title">Thread Title</label>
            <input type="text" id="title" name="title" required>

            <label for="category">Select Category</label>
            <select id="category" name="category" required>
    <?php
    // Reset the result pointer to the beginning
    $categories_result->data_seek(0);

    // Check if there are categories in the result
    if ($categories_result->num_rows > 0) {
        while ($category = $categories_result->fetch_assoc()) {
            echo '<option value="' . htmlspecialchars($category['id']) . '">' . htmlspecialchars($category['name']) . '</option>';
        }
    } else {
        echo '<option value="">No categories available</option>';
    }
    ?>
</select>


            <label for="description">Thread Description</label>
            <textarea id="description" name="description" rows="4" required></textarea>

            <button type="submit">Create Thread</button>
        </form>

        </div>
    </div>
</div>


        <!-- Recent Threads Section -->
        <div class="recent-threads">
            <h2><i class="fas fa-comment-dots"></i> Recent Threads</h2>
            <ul class="thread-list">
                <?php while ($thread = $threads_result->fetch_assoc()): ?>
                    <li class="thread-item">
                        <a href="thread.php?id=<?= $thread['id'] ?>">
                            <i class="fas fa-arrow-right"></i> <?= htmlspecialchars($thread['title']) ?>
                        </a>
                        <span>
                            <i class="fas fa-folder"></i> <?= htmlspecialchars($thread['category_name']) ?> | 
                            <i class="fas fa-clock"></i> <?= date('F j, Y, g:i a', strtotime($thread['created_at'])) ?>
                        </span>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>

</div>


</body>

<script>
      // Get modal element
      var modal = document.getElementById("categoryModal");

// Get open modal button
var openModalButton = document.getElementById("openModalButton");

// Get close button
var closeModal = document.getElementById("closeModal");

// When the user clicks the button, open the modal
openModalButton.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks the close button, close the modal
closeModal.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

 // Get modal element for thread creation
 var threadModal = document.getElementById("threadModal");

// Get open modal button for thread creation
var openThreadModalButton = document.getElementById("openThreadModalButton");

// Get close button for thread creation modal
var closeThreadModal = document.getElementById("closeThreadModal");

// When the user clicks the button, open the modal
openThreadModalButton.onclick = function() {
    threadModal.style.display = "block";
}

// When the user clicks the close button, close the modal
closeThreadModal.onclick = function() {
    threadModal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == threadModal) {
        threadModal.style.display = "none";
    }
}
</script>
</html>
