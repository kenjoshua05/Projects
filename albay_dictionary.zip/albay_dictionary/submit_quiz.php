<?php
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
if (!logged_in()) {
    header('Location: login.php'); // Redirect to login page
    exit;
}

// Process the quiz submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quiz_id = isset($_POST['quiz_id']) ? (int)$_POST['quiz_id'] : 0;
    $attempt_id = isset($_POST['attempt_id']) ? (int)$_POST['attempt_id'] : 0; // Get the attempt_id
    $answers = isset($_POST['answers']) ? $_POST['answers'] : [];

    if ($quiz_id == 0 || $attempt_id == 0 || empty($answers)) {
        echo "Invalid submission.";
        exit;
    }

    $user_id = $_SESSION['USER']['id'];
    $score = 0;
    $total_questions = 0;

    foreach ($answers as $question_id => $choice_id) {
        $total_questions++;

        // Check if the selected choice is correct
        $query = "SELECT is_correct FROM choices WHERE id = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param('i', $choice_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($row['is_correct']) {
                $score++;
            }
        }

        // Store the user's answer
        $query = "INSERT INTO user_quiz_answers (user_id, question_id, selected_choice_id, attempt_id) VALUES (?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param('iiii', $user_id, $question_id, $choice_id, $attempt_id);
        if (!$stmt->execute()) {
            die("Execute failed: " . $stmt->error);
        }
    }

    // Store the quiz result with attempt_id
    $query = "INSERT INTO user_quiz_results (user_id, quiz_id, score, attempt_id) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param('iiii', $user_id, $quiz_id, $score, $attempt_id);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    // Update the total quizzes taken
    $query = "UPDATE users SET total_quizzes_taken = total_quizzes_taken + 1 WHERE id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $user_id);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    // Update the total correct answers
    $query = "UPDATE users SET total_correct_answers = total_correct_answers + ? WHERE id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('ii', $score, $user_id);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    // Update the last quiz taken timestamp
    $query = "UPDATE users SET last_quiz_taken = NOW() WHERE id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $user_id);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    // Redirect to a result page or display the score
    header("Location: quiz_result.php?quiz_id=$quiz_id&score=$score&total_questions=$total_questions");
    exit;
} else {
    echo "Invalid request.";
    exit;
}
?>
