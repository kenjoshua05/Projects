<?php
require('config.inc.php');
require('functions.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


    <style>

.searchbg{
	background-color: #f7f7f7;
    display: flex;
    justify-content: center;
    align-items: center;
	padding-top: 10px;
	margin-top:20px;
    z-index: 1;
}

.search-container1 {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #ffffff;
    padding: 15px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 50px;
    width: 100%;
    max-width: 900px;
    z-index: 1;
}
.search-container1 a{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    max-width: 900px;
    z-index: 1;
}


#search-form {
    display: flex;
    justify-content: flex-start; /* Align elements to start */
    align-items: center;
    width: 100%;
}

/* Modern Dropdown Styling */
.dropdown-container {
    position: relative;
    width: 10%; /* Super small width for dropdown */
    min-width: 60px; /* Minimum width to show the text fully */
    z-index: 1;
}

#category {
    width: 100%;
    padding: 12px 30px 12px 12px; /* Add padding to ensure space for icon */
    border-radius: 40px;
    border: 1px solid #ddd;
    font-size: 16px;
    color: #333;
    background-color: #f9f9f9;
    appearance: none;
    cursor: pointer;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    min-height: 40px; /* Minimum height to ensure visibility of the selected option */
}

#category:hover,
#category:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}

.dropdown-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    color: #777;
    font-size: 16px;
    margin-left: 5px; /* Add a tiny space to the left of the icon */
}

/* Search Input */
#search-input {
    flex-grow: 1;
    padding: 12px;
    margin-left: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 30px;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    z-index: 1;
}

#search-input:hover,
#search-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}

#search-input::placeholder {
    color: #aaa;
}

/* Search Button */
#search-button {
    padding: 12px 20px;
    background-color: #B40023;
    color: #fff;
    border: none;
    border-radius: 50px;
    cursor: pointer;
    margin-left: 10px;
    transition: background-color 0.3s ease;
}

#search-button:hover {
    background-color: #d63447;
}

/* Media Queries for Responsiveness */

/* Tablets and Larger Screens */
@media (max-width: 768px) {
    #search-form {
        flex-wrap: nowrap; /* Prevent wrapping */
    }

    .dropdown-container {
        width: 10%; /* Super small width for dropdown */
        min-width: 60px; /* Minimum width to show the text fully */
    }

    #search-input {
        width: 70%; /* Adjust width for better fit */
        margin-left: 10px;
    }

    #search-button {
        width: 20%; /* Adjust width for better fit */
        margin-left: 10px;
    }
}

/* Mobile Devices */
@media (max-width: 576px) {
    #search-form {
        flex-wrap: nowrap; /* Prevent wrapping */
    }

    .dropdown-container {
        width: 10%; /* Super small width for dropdown */
        min-width: 60px; /* Minimum width to show the text fully */
    }

    #search-input {
        width: 70%; /* 70% width for input */
    }

    #search-button {
        width: 20%; /* 20% width for button */
    }
}

/* Title Styles */
.section-title {
    text-align: center;
    font-size: 3rem; /* Larger text size for modern feel */
    font-weight: 700; /* Bold text */
    color: #B40023; /* Accent color */
    margin-top: 30px;
    letter-spacing: 1px; /* Slightly increased spacing for readability */
    text-transform: uppercase; /* All caps for a modern look */
    line-height: 1.4;
    position: relative;
    opacity: 0;
    animation: popUp 1s forwards ease-out; /* Slow "pop" effect */
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 2;

    /* Add background and adjust width */
    background-color: #f5f5f5; /* Light gray background */
    width: 60%; /* Set the width to 60% of the parent container */
    margin-left: auto; /* Center horizontally */
    margin-right: auto; /* Center horizontally */
    padding: 20px; /* Padding around the text */
    border-radius: 8px; /* Optional rounded corners */
    text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.2); /* Shadow effect */
}



/* Animation for "pop" effect */
@keyframes popUp {
    0% {
        opacity: 0;
        transform: translateY(-30px);
    }
    50% {
        opacity: 0.7;
        transform: translateY(10px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 1024px) {
    .section-title {
        width: 95%; /* Adjust width for tablets */
    }
}
/* Responsive Title */
@media (max-width: 768px) {
    .section-title {
        font-size: 2.5rem;
        width: 95%;
    }
}

@media (max-width: 480px) {
    .section-title {
        font-size: 2rem;
        width: 95%;
    }
}

/* Word Container */
.new-word {
    background: #ffffff;
    margin: 20px auto;
    padding: 30px;
    max-width: 900px;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    gap: 15px;
    z-index: 1;
    transform: translateY(-8px);
}

.new-word h2 {
    font-size: 2.5rem;
    font-weight: 600;
    color: #333;
    margin-bottom: 10px;
    transition: color 0.3s ease;
    z-index: 1;
}

.new-word h2 a {
    text-decoration: none;
    color: inherit;
}

.new-word h2 a:hover {
    color: #B40023;
}

.new-word p {
    font-size: 1.1rem;
    color: #444;
    line-height: 1.5;
}

.new-word p strong {
    color: #333;
}

/* Audio Control Button */
.audio-control {
    display: flex;
    align-items: center;
    gap: 15px;
}

.audio-button {
    background-color: #2575fc;
    color: white;
    border: none;
    padding: 12px 18px;
    border-radius: 50px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.audio-button:hover {
    background-color: #1a62c2;
    transform: translateY(-3px);
}

.audio-button i {
    font-size: 1.3rem;
}

.audio-button span {
    font-size: 1.1rem;
}

/* Adding icons to the page */
.fas {
    font-size: 1.6rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .section-title {
        font-size: 2.5rem;
          width: 95%;
    }

    .new-word {
        padding: 20px;
    }

    .word-title {
        font-size: 1.8rem;
    }

    .audio-button {
        padding: 10px 15px;
    }
}

@media (max-width: 480px) {
    .section-title {
        font-size: 2rem;
    }

    .new-word {
        padding: 15px;
        margin: 10px;
    }

    .word-title {
        font-size: 1.6rem;
    }

    .audio-button {
        padding: 10px;
    }
}

        /* Background Shapes */
        .shape {
            position: fixed;
            width: 400px;
            height: 400px;
            background-color: green;
            opacity: 0.6;
            border-radius: 50%;
            z-index: 0; /* Ensure shapes are behind content */
            animation: bounceShape 15s ease-in-out infinite;
        }

        /* Keyframes for Bouncing Animation */
        @keyframes bounceShape {
            0% {
                transform: translateX(0) translateY(0); /* Start at the top-left corner */
            }
            25% {
                transform: translateX(80vw) translateY(20vh); /* Move to the right and slightly down */
            }
            50% {
                transform: translateX(40vw) translateY(80vh); /* Move to the middle and lower */
            }
            75% {
                transform: translateX(10vw) translateY(20vh); /* Move to the left and slightly down */
            }
            100% {
                transform: translateX(0) translateY(0); /* Return to the top-left */
            }
        }

        /* Additional styles for creating multiple shapes */
        .shape:nth-child(1) {
            animation-delay: 0s;
        }
        .shape:nth-child(2) {
            animation-delay: 3s;
            background-color: red;
        }
        .shape:nth-child(3) {
            animation-delay: 6s;
            background-color: blue;
        }



</style>
</head>
<body>
<section class="class_1">
    <?php include('header.inc.php'); ?>

<!-- Background Shapes -->
<div class="shape"></div>
    <div class="shape"></div>
    <div class="shape"></div>
    
    <div class="searchbg">
        <div class="search-container1">
            <form id="search-form" action="search.php" method="GET">
                <div class="dropdown-container">
                    <select id="category" name="category">
                        <option value="all">All</option>
                        <option value="words">Words</option>
                        <option value="example">Examples</option>
                        <option value="meaning">Meaning</option>
                    </select>
                    <i class="fas fa-caret-down dropdown-icon"></i>
                </div>
                <input type="text" id="search-input" name="query" placeholder="Search...">
                <button type="submit" id="search-button"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

	<h1 class="section-title">
    <i class="fas fa-star"></i> Recent Words<i class="fas fa-star"></i>
</h1>

<?php
$query = "SELECT id, word, english_meaning, pronunciation, audio_file FROM dialect_data ORDER BY id DESC LIMIT 5"; 
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0) {
    while ($newWord = mysqli_fetch_assoc($result)) {
        $audioId = "audio-player-" . $newWord['id']; // Generate a unique ID for each audio player
        ?>
        <div class="new-word">
            <h2><a href="word.php?id=<?php echo $newWord['id']; ?>"><i class="fas fa-book-open"></i> <?php echo htmlspecialchars($newWord['word']); ?></a></h2>
            <p><strong><i class="fas fa-translate"></i> English Meaning:</strong> <?php echo htmlspecialchars($newWord['english_meaning']); ?></p>
            <p><strong><i class="fas fa-microphone"></i>Pronunciation Guide:</strong> <?php echo htmlspecialchars($newWord['pronunciation']); ?></p>
            <p>
                <strong><i class="fas fa-headphones-alt"></i> Listen:</strong>
                <button onclick="playAudio('<?php echo $audioId; ?>')" class="audio-button">
                    <i class="fas fa-play-circle"></i> Play Audio
                </button>
            </p>
            <audio id="<?php echo $audioId; ?>">
                <source src="admin/<?php echo htmlspecialchars($newWord['audio_file']); ?>" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        </div>
        <?php
    }
} else {
    echo "<p>No words found in the database.</p>";
}
?>


    <?php include('footer.inc.php'); ?>
</section>

<!-- Scroll to Top Button -->
<button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
<script src="script.js"></script>

<!-- Audio Player Script -->
<script>
    function playAudio(audioId) {
        const audioPlayer = document.getElementById(audioId);
        if (audioPlayer) {
            audioPlayer.play();
        } else {
            console.error("Audio element not found for ID:", audioId);
        }
    }

	function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

</script>

</body>
</html>
