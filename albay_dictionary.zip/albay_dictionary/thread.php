<?php
include 'config.inc.php';

$thread_id = $_GET['id'];  // Get the thread ID from the URL

// Fetch thread details, including the description
$query_thread = "
    SELECT 
        forum_threads.title, 
        forum_threads.description,  -- Include the description column
        forum_categories.name AS category_name 
    FROM 
        forum_threads 
    JOIN 
        forum_categories 
    ON 
        forum_threads.category_id = forum_categories.id 
    WHERE 
        forum_threads.id = $thread_id";
        
$thread_result = $con->query($query_thread);

// Check if the query was successful and fetch the result
if ($thread_result && $thread_result->num_rows > 0) {
    $thread = $thread_result->fetch_assoc();
} else {
    $thread = null; // Handle case where the thread is not found
}


// Fetch posts for the thread
$query_posts = "SELECT * FROM forum_posts WHERE thread_id = $thread_id ORDER BY created_at DESC";
$posts_result = $con->query($query_posts);

// Function to generate a random avatar URL based on a name
function getAvatarUrl($name) {
    // Updated DiceBear Avatar API endpoint
    $avatar_base_url = "https://api.dicebear.com/6.x/bottts/svg";
    $avatar_url = $avatar_base_url . "?seed=" . urlencode($name); // Name-based avatar
    return $avatar_url;
}

// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_content'])) {
    $guest_name = $_POST['guest_name'] ?? 'Guest';
    $content = $_POST['post_content'];
    $ip_address = $_SERVER['REMOTE_ADDR']; // Get the user's IP address

    // Insert the post along with the IP address
    $query_insert_post = "INSERT INTO forum_posts (thread_id, guest_name, content, ip_address) 
                          VALUES ($thread_id, '$guest_name', '$content', '$ip_address')";
    $con->query($query_insert_post);
    header("Location: thread.php?id=$thread_id");  // Refresh page to show the new post
}

// Handle post deletion
if (isset($_GET['delete_post'])) {
    $post_id = $_GET['delete_post'];
    $ip_address = $_SERVER['REMOTE_ADDR'];  // Get the current user's IP address
    
    // Check if the user is the one who created the post by matching IP address
    $query_check_owner = "SELECT ip_address FROM forum_posts WHERE id = $post_id";
    $result_owner = $con->query($query_check_owner);
    $owner = $result_owner->fetch_assoc();
    
    if ($owner['ip_address'] == $ip_address) {
        // Delete the post if the IP addresses match
        $delete_query = "DELETE FROM forum_posts WHERE id = $post_id";
        $con->query($delete_query);
        header("Location: thread.php?id=$thread_id");  // Refresh after deletion
    } else {
        echo "You are not authorized to delete this post.";
    }
}

// Handle post editing
if (isset($_GET['edit_post'])) {
    $post_id = $_GET['edit_post'];
    $ip_address = $_SERVER['REMOTE_ADDR'];  // Get the current user's IP address
    
    // Fetch the content of the post
    $query_edit = "SELECT content, ip_address FROM forum_posts WHERE id = $post_id";
    $edit_result = $con->query($query_edit);
    $post_data = $edit_result->fetch_assoc();
    
    // If there's no post found or an error, show a message
    if (!$post_data) {
        echo "Post not found or error fetching post.";
        exit;
    }

    $post_content = $post_data['content'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_content'])) {
        $new_content = $_POST['edit_content'];
        
        // Check if the user is the one who created the post by matching IP address
        if ($post_data['ip_address'] == $ip_address) {
            // Update the post content if the IP addresses match
            $update_query = "UPDATE forum_posts SET content = '$new_content' WHERE id = $post_id";
            $con->query($update_query);
            header("Location: thread.php?id=$thread_id");  // Redirect to the thread
        } else {
            echo "You are not authorized to edit this post.";
        }
    }
}

// Handle heart click (like)
if (isset($_POST['like'])) {
    $ip_address = $_SERVER['REMOTE_ADDR']; // Get the user's IP address

    // Check if the user (IP) has already liked this thread
    $query_check_like = "SELECT * FROM forum_likes WHERE thread_id = $thread_id AND ip_address = '$ip_address'";
    $result_check_like = $con->query($query_check_like);

    if ($result_check_like->num_rows == 0) {
        // Insert a new like into the forum_likes table
        $query_insert_like = "INSERT INTO forum_likes (thread_id, ip_address) VALUES ($thread_id, '$ip_address')";
        $con->query($query_insert_like);
    } else {
        echo "<script>alert('You can only like this thread once.');</script>";
    }
}

// Fetch the number of likes for the thread
$query_likes = "SELECT COUNT(*) AS like_count FROM forum_likes WHERE thread_id = $thread_id";
$likes_result = $con->query($query_likes);
$likes = $likes_result->fetch_assoc();
$like_count = $likes['like_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $thread['title'] ?></title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fafafa;
            margin: 0;
            padding: 20px;
        }
        h1, h2, h3 {
            color: #333;
        }
        .thread-title {
            background-color: #B40023;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .posts {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .post {
            display: flex;
            padding-bottom: 20px;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .post img.avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
        }
        .post .content {
            flex-grow: 1;
        }
        .post .content p {
            font-size: 16px;
            margin: 0;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 8px;
        }
        .post .content small {
            color: #777;
        }
        .post .actions {
            display: flex;
            align-items: center;
        }
        .post .actions a {
            margin: 0 10px;
            color: #B40023;
            font-size: 20px;
            text-decoration: none;
        }
        .post .actions a:hover {
            color: #9e001c;
        }
        .form-container {
            background-color: white;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .form-container textarea,
        .form-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        .form-container button {
            background-color: #B40023;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-container button:hover {
            background-color: #9e001c;
        }

        .comment-icon {
            margin-top: 5px; /* Adds some spacing */
        }

        .comment-icon a {
            text-decoration: none;
            color: #007BFF; /* Default color for the icon, can be changed */
        }

        .comment-icon a:hover {
            color: #0056b3; /* Darker shade for hover effect */
        }

        .comment-icon i {
            font-size: 16px; /* Adjust icon size if needed */
        }

        .comment-field form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 8px;
            margin-left:20px;
            font-size:16px;
        }

        .comment-field input[type="text"] {
            flex: 1;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .comment-field input[type="text"]:focus {
            border-color: #007BFF;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            outline: none;
            font-size: 16px;
        }

        .comment-field button {
            padding: 8px 16px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            background-color: #B40023;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .comment-field button:hover {
            background-color: #92001D;
            transform: translateY(-1px);
        }

        .comment-field button:active {
            background-color: #770016;
            transform: translateY(1px);
        }

        .comment-field form {
            max-width: 100%; /* Ensures the form adapts to its container */
        }

        .comments{
            margin-top:10px;
            margin-left:20px;
        }
        .thread-title i, .thread-title + p i {
            margin-right: 8px; /* Add space between the icon and the text */
            color: #fff; /* Color for the icons (same as your theme) */
        }

        .thread-title {
    font-size: 2.2em; /* Larger font for the thread title */
    color: #fff;
    margin-bottom: 10px;
    font-weight: 600;
}

.category-text {
    font-size: 0.7em; /* Smaller font size for the category */
    color: #B7B7B7; /* Light gray color for the category */
    margin-top: 5px;
}

.category-text i {
    margin-right: 8px; /* Space between icon and category name */
    color: #B7B7B7; /* Icon color (same as your theme) */
}

.back-button i {
    margin-right: 8px;
    font-size: 1.4rem;
    color: #B40023;
}

/* Hover Effect */
.back-button:hover {
    background-color: #9b001d;
    transform: scale(1.05);
}

@media (max-width: 600px) {
    .thread-title {
        padding: 10px; /* Reduce padding */
        margin-bottom: 15px; /* Reduce bottom margin */
        font-size: 1.2rem; /* Smaller font size */
    }
    .form-container h3{
        font-size:0.8rem;
    }

    .comment-field form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 8px;
            margin-left:20px;
        }

        .comment-field input[type="text"] {

            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        /* Adjust input and textarea fields */
    .form-container textarea,
    .form-container input[type="text"] {
        padding: 8px; /* Reduce padding for smaller screens */
        font-size: 14px; /* Reduce font size */
        margin-bottom: 8px; /* Reduce bottom margin */
    }

    /* Adjust button styles */
    .form-container button {
        padding: 8px 16px; /* Reduced padding */
        font-size: 14px; /* Reduced font size */
    }
}

@media (max-width: 400px) {
    /* Posts container adjustments */
    .posts {
        padding: 15px; /* Reduced padding */
        margin-top: 10px; /* Reduced margin */
    }

    /* Post adjustments */
    .post {
        flex-direction: column; /* Stack the post content vertically */
        padding-bottom: 10px; /* Reduced padding for smaller screens */
        margin-bottom: 10px; /* Reduced margin */
    }

    /* Comment form adjustments */
    .comment-field form {
        margin-left: 10px; /* Reduced margin */
        gap: 5px; /* Reduced gap between input and button */
    }

    /* Input field adjustments */
    .comment-field input[type="text"] {
        padding: 8px; /* Reduced padding */
        font-size: 12px; /* Smaller font size */
    }
      /* Further reduce padding, margin, and font size */
      .form-container textarea,
    .form-container input[type="text"] {
        padding: 6px; /* Even smaller padding */
        font-size: 12px; /* Smaller font size */
        margin-bottom: 6px; /* Reduced margin */
    }

    .form-container button {
        padding: 6px 12px; /* Further reduced padding */
        font-size: 12px; /* Even smaller font size */
    }
}

.thread-description {
    font-size: 1.1em; /* Slightly larger font for readability */
    color: #444; /* Softer text color for modern look */
    margin-top: 20px; /* Space above the description */
    line-height: 1.8; /* Better line spacing for readability */
    padding: 15px 20px; /* Padding inside the box */
    background: #f9f9f9; /* Light gray background */
    border-radius: 8px; /* Smooth rounded corners */
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    border-left: 5px solid #B40023; /* Decorative left border */
    display: flex; /* Flex layout for icon and text alignment */
    align-items: center; /* Vertically center the icon and text */
}

.thread-description .description-icon {
    color: #B40023; /* Set color to the desired one */
    font-size: 1.5em;
    margin-right: 10px; /* Space between icon and text */
}

/* Optional: Change color on hover */
.thread-description .description-icon:hover {
    color: #9b001d; /* New color when hovered */
}


@media (max-width: 768px) {
    .thread-description {
        font-size: 0.7em; /* Adjust font size for smaller screens */
        padding: 10px 15px; /* Reduce padding */
    }

    .thread-description i {
        font-size: 1.2em; /* Adjust icon size */
        margin-right: 10px; /* Adjust spacing */
    }
}



    </style>
</head>
<body>
<a href="javascript:history.back()" class="back-button"><i class="fas fa-arrow-left"></i></a>
<?php if ($thread): ?>
    <h1 class="thread-title">
        <i class="fas fa-comment-dots"></i> <!-- Icon for thread title -->
        <?= htmlspecialchars($thread['title']) ?>
        <p class="category-text">
            <i class="fas fa-folder"></i> <?= htmlspecialchars($thread['category_name']) ?>
        </p>
    </h1>
    <p class="thread-description">
    <i class="fas fa-info-circle description-icon"></i> 
    <?= htmlspecialchars($thread['description']) ?>
    </p>
  
<?php else: ?>
    <p>Thread not found.</p>
<?php endif; ?>


    <!-- Like button -->
    <form method="POST" style="display: inline;">
        <button type="submit" name="like" style="background: none; border: none; cursor: pointer;">
            <i class="fas fa-heart" style="color: <?= checkUserLiked($thread_id) ? 'red' : '#B40023'; ?>;"></i>
            <span><?= $like_count ?> Likes</span>
        </button>
    </form>
    
    <div class="posts">
    <h2>Posts</h2>
<?php while($post = $posts_result->fetch_assoc()): ?>
    <div class="post">
        <img class="avatar" src="<?= getAvatarUrl($post['guest_name']) ?>" alt="Avatar">
        <div class="content">
            <p><strong><?= $post['guest_name'] ?></strong>: <?= $post['content'] ?></p>
            <small>Posted on <?= $post['created_at'] ?></small>

            <!-- Comment icon and field -->
            <div class="comment-section" id="comment-section-<?= $post['id'] ?>">
                <a href="javascript:void(0);" title="Add a comment" onclick="showCommentField(<?= $post['id'] ?>)">
                    <i class="fas fa-comment"></i>
                </a>
            </div>
            <div class="comment-field" id="comment-field-<?= $post['id'] ?>" style="display: none;">
                <form action="submit_comment.php" method="POST">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <input type="text" name="comment" placeholder="Write a comment..." required>
                    <button type="submit">Post</button>
                </form>
            </div>

            <!-- Display Comments for this post -->
            <div class="comments">
                <?php
                    // Fetch comments for the current post
                    $comments_result = $con->query("SELECT * FROM forum_comments WHERE post_id = {$post['id']} ORDER BY created_at DESC");
                    while($comment = $comments_result->fetch_assoc()):
                ?>
                    <div class="comment">
                        <p><strong><?= $comment['guest_name'] ?>:</strong> <?= $comment['content'] ?></p>
                        <small>Commented on <?= $comment['created_at'] ?></small>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <div class="actions">
            <?php if (isset($_SESSION['user_name']) && $_SESSION['user_name'] == $post['guest_name']): ?>
                <a href="thread.php?id=<?= $thread_id ?>&edit_post=<?= $post['id'] ?>" title="Edit"><i class="fas fa-edit"></i></a>
                <a href="thread.php?id=<?= $thread_id ?>&delete_post=<?= $post['id'] ?>" onclick="return confirm('Are you sure you want to delete this post?')" title="Delete"><i class="fas fa-trash-alt"></i></a>
            <?php endif; ?>
        </div>
    </div>
<?php endwhile; ?>



    <div class="form-container">
        <h3>Reply to this thread</h3>
        <form method="POST">
            <input type="text" name="guest_name" placeholder="Your name (optional)">
            <textarea name="post_content" rows="4" placeholder="Type your reply here..." required></textarea>
            <button type="submit">Post</button>
        </form>
    </div>
</body>
</html>

<script>
    function showCommentField(postId) {
        // Hide the comment icon
        document.getElementById(`comment-section-${postId}`).style.display = 'none';
        // Show the comment input field
        document.getElementById(`comment-field-${postId}`).style.display = 'block';
    }
</script>

<?php
// Function to check if the user has already liked the thread
function checkUserLiked($thread_id) {
    global $con;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $query_check_like = "SELECT * FROM forum_likes WHERE thread_id = $thread_id AND ip_address = '$ip_address'";
    $result_check_like = $con->query($query_check_like);
    return $result_check_like->num_rows > 0; // Return true if liked, false otherwise
}
?>
