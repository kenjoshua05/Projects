    <?php
    require_once('config.inc.php');
    require_once('functions.php');
    // Check if category ID is provided and is numeric
    if (!isset($_GET['category_id']) || !is_numeric($_GET['category_id'])) {
        // Redirect to an error page or show an error message
        header("Location: error.php?message=Invalid Category ID");
        exit();
    }

    // Sanitize category ID
    $category_id = mysqli_real_escape_string($con, $_GET['category_id']);

    // Fetch category name for display
    $category_query = "SELECT name FROM categories WHERE id='$category_id'";
    $category_result = mysqli_query($con, $category_query);

    // Check if the category exists
    if (mysqli_num_rows($category_result) === 0) {
        // Redirect to an error page or show an error message
        header("Location: error.php?message=Category not found");
        exit();
    }

    $category = mysqli_fetch_assoc($category_result);

    // Fetch words from dialect_data table for the given category
    $words_query = "SELECT id, word, english_meaning FROM dialect_data WHERE category_id='$category_id'";
    $words_result = mysqli_query($con, $words_query);

    // Fetch common conversations for the given category
    $common_query = "SELECT id, phrase, example FROM common_conversations WHERE category_id='$category_id'";
    $common_result = mysqli_query($con, $common_query);

    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo htmlspecialchars($category['name']); ?></title>
        <link rel="icon" href="bg/logo4.png" type="image/png">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
        <script src="search.js" defer></script>
    </head>
    <body>
    <style>
            
            @keyframes appear{
                0%{
                    opacity: 0;
                }
                100%{
                    opacity: 1;
                }
            }

            .hide{
                display:none;
            }

            .back-arrow {
                position: relative;
                font-size: 1.2rem;
                color: #00ab66;
                text-decoration: none;
                display: flex;
                align-items: center;
                margin-left:20px;
                margin-top:10px;
            }

            .back-arrow i {
                margin-right: 5px; /* Spacing between icon and text */
            }


    .pri-container{
        width: 90%;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
        position: relative;
    }
   

    /* Word Grid */
    .word-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }

    /* Word Card */
    .word-card {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .word-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .word-card h2 {
        font-size: 1.5rem;
        color: #B40023;
        margin-bottom: 10px;
    }

    .word-card p {
        font-size: 1rem;
        color: #666;
    }

    /* Link styling */
    .word-card-link {
        text-decoration: none; /* Remove underline from links */
        color: inherit; /* Inherit text color */
        display: block; /* Make the link take up the full space of the word-card */
    }

            /* Search Bar */
    .search-bar {
        display: flex;
        justify-content: center;
        margin: 20px 0;
        position: relative;
        width: 100%;
    }

    .search-bar input {
        font-size: 16px;
    }
    
    .search-bar input[type="text"] {
        width: 60%;
        padding: 15px 20px;
        font-size: 1.2rem;
        border: 2px solid #ccc;
        border-radius: 30px;
        outline: none;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    .search-bar input[type="text"]:focus {
        border-color: #B40023;
        box-shadow: 0 4px 12px rgba(180, 0, 35, 0.3);
    }


    .search-bar button {
        position: absolute;
        right: 20%;
        top: 50%;
        transform: translateY(-50%);
        padding: 12px 15px;
        font-size: 1.2rem;
        border: none;
        background-color: #B40023;
        color: white;
        border-radius: 50%;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
        box-shadow: 0 4px 8px rgba(180, 0, 35, 0.4);
    }

    .search-bar button:hover {
        background-color: #a0001e;
        transform: translateY(-50%) scale(1.1);
    }

    .search-bar button i {
        color: white;
    }

    @media (max-width: 768px) {
        .search-bar input[type="text"] {
            width: 90%;
        }

        .search-bar button {
            right: 5%;
        }

        .word-card {
        padding: 15px; /* Less padding on smaller screens */
        max-width: 320px; /* Limit card width on tablets */
    }

    .word-card h2 {
        font-size: 1.6rem; /* Slightly smaller title size */
    }

    .word-card p {
        font-size: 0.6rem; /* Adjust paragraph size for readability */
    }
        
    }


@media (max-width: 480px) {
    .back-button {
        font-size: 0.9rem; /* Smaller font size on mobile */
        padding: 6px 10px;
    }

    .back-button i {
        font-size: 1.1rem; /* Smaller icon size on mobile */
    }
}

    .search-bar-conversation{
        display: flex;
        justify-content: center;
        margin: 20px 0;
        position: relative;
        width: 100%;
    }

    .search-bar-conversation input[type="text"] {
        width: 80%;
        padding: 15px 20px;
        font-size: 1.2rem;
        border: 2px solid #ccc;
        border-radius: 30px;
        outline: none;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    .search-bar-conversation input[type="text"]:focus {
        border-color: #B40023;
        box-shadow: 0 4px 12px rgba(180, 0, 35, 0.3);
    }


    .search-bar-conversation button {
        position: absolute;
        right: 10%;
        top: 50%;
        transform: translateY(-50%);
        padding: 12px 15px;
        font-size: 1.2rem;
        border: none;
        background-color: #B40023;
        color: white;
        border-radius: 50%;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
        box-shadow: 0 4px 8px rgba(180, 0, 35, 0.4);
    }

    .search-bar-conversation button:hover {
        background-color: #a0001e;
        transform: translateY(-50%) scale(1.1);
    }

    .search-bar-conversation button i {
        color: white;
    }

    @media (max-width: 768px) {
        .search-bar-conversation input[type="text"] {
            width: 100%;
        }

        .search-bar-conversation button {
            right: 0%;
        }
    }

            /* Accordion Styles */
    .accordion {
        border-top: 2px solid #B40023;
    }

    .accordion h2 {
        text-align: center;
        color:#00ab66 ;
        margin-bottom: 20px;
        margin-top: 20px;
        font-size: 2rem;
    }

    .accordion-item {
        border-bottom: 1px solid #ccc;
        margin-bottom: 10px;
    }

    .accordion-title {
        cursor: pointer;
        padding: 15px;
        background-color: #f7f7f7;
        color: #333;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background-color 0.3s ease;
        position: relative;
    }

    .accordion-title h3 {
        margin: 0;
        font-size: 1.2rem;
        flex-grow: 1;
    }

    .accordion-title i {
        font-size: 1.2rem;
        position: absolute;
        right: 15px;
        transition: transform 0.3s ease;
    }

    .accordion-title:hover {
        background-color: #00ab66;
    }

    .accordion-content {
        display: none;
        padding: 15px;
        background-color: #fff;
        color: #555;
        border-top: 1px solid #ccc;
    }

    .accordion-content p {
        margin: 5px 0;
    }

    .accordion .accordion-item.active i {
        transform: rotate(360deg); /* Rotate the plus icon to make it look like a minus */
    }

    .accordion .accordion-item.active .accordion-content {
        display: block;
    }

    @media (max-width: 768px) {
        .accordion h2 {
            font-size: 1.5rem;
        }
    }
    /* A-Z Sorting Buttons */
    .sort-buttons {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 10px;
        margin: 20px 0;
    }

    .sort-buttons button {
        padding: 10px 15px;
        font-size: 1.1rem;
        border: 2px solid #B40023;
        border-radius: 5px;
        background-color: white;
        color: #B40023;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .sort-buttons button:hover {
        background-color: #B40023;
        color: white;
        box-shadow: 0 4px 12px rgba(180, 0, 35, 0.3);
    }

    .sort-buttons button:active {
        background-color: #a0001e;
        color: white;
        transform: translateY(2px);
    }

    @media (max-width: 768px) {
        .sort-buttons button {
            padding: 8px 12px;
            font-size: 1rem;
        }
    }

    .secondary-container{
    
        width: 90%;
        max-width: 1200px;
        margin: auto;
        padding: 20px;
    }

        </style>
        <section class="class_1">
            <?php include('header.inc.php'); ?>
            <a href="javascript:history.back()" class="back-arrow">
        <i class="fas fa-arrow-left"></i> 
    </a>
            <div class="categname">
                <h1><?php echo htmlspecialchars($category['name']); ?></h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search for a word...">
                <button><i class="fas fa-search"></i></button>
            </div>  
    </div>
    <div class="pri-container">
        <div class="word-grid" id="wordGrid">
            <?php while ($row = mysqli_fetch_assoc($words_result)) : ?>
                <a href="word.php?id=<?php echo $row['id']; ?>" class="word-card-link">
                    <div class="word-card" data-letter="<?php echo strtoupper($row['word'][0]); ?>">
                        <h2><?php echo htmlspecialchars($row['word']); ?></h2>
                        <?php 
                            $english_meaning = $row['english_meaning'] ?? 'No meaning available';
                            $words = explode(' ', $english_meaning); 
                            $limited_meaning = implode(' ', array_slice($words, 0, 3)); 
                            
                            if (count($words) > 3) {
                                $limited_meaning .= '...';
                            }
                        ?>
                        <p><?php echo htmlspecialchars($limited_meaning); ?></p>
                    </div>
                </a>
            <?php endwhile; ?>
        </div>
        <p id="noWordsMessage" style="display: none;">
            <i class="fas fa-exclamation-circle"></i> No words found
        </p>
    </div>


        
        <div class="secondary-container">
            <h2 style="text-align: center; color: #00ab66; padding-bottom: 10px;">Sort By First Letter</h2>

                <!-- A-Z Sorting Buttons -->
                <div class="sort-buttons">
                    <?php foreach (range('A', 'Z') as $letter): ?>
                        <button class="sort-button" data-letter="<?php echo $letter; ?>"><?php echo $letter; ?></button>
                    <?php endforeach; ?>
                </div>

                <p id="no-words-message" style="display: none; color: red; text-align: center;">No word found starting with this letter.</p>


                <div class="accordion">
                    <h2>Basic Conversations</h2>

                    <div class="search-bar-conversation">
                        <input type="text" placeholder="Search for a conversation..." id="conversationSearch">
                        <button><i class="fas fa-search"></i></button>
                    </div>


                    <?php while ($row = mysqli_fetch_assoc($common_result)) : ?>
                        <div class="accordion-item">
                            <div class="accordion-title">
                                <h3><?php echo htmlspecialchars($row['phrase']); ?><i class="fas fa-plus"></i></h3>
                            </div>
                            <div class="accordion-content">
                                <p><strong><?php echo htmlspecialchars($category['name']); ?>:</strong> <?php echo htmlspecialchars($row['example']); ?></p>
                            </div>
                        </div>
                            <?php endwhile; ?>
                            <p id="noConversationsMessage" style="display: none; color: red;"> <i class="fas fa-exclamation-circle"></i>No conversation found.</p>
                </div>
        </div>
       

        <?php include('footer.inc.php') ?>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <?php include('signup.inc.php') ?>
		<?php include('login.inc.php') ?>
    </section>
    <!-- Scroll to top button -->
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
    <script>
        document.querySelectorAll('.accordion-title').forEach(item => {
    item.addEventListener('click', () => {
        const parent = item.parentNode;
        const icon = item.querySelector('i');

        // Toggle active class
        parent.classList.toggle('active');

        // Toggle icon
        if (parent.classList.contains('active')) {
            icon.classList.replace('fa-plus', 'fa-minus');
        } else {
            icon.classList.replace('fa-minus', 'fa-plus');
        }

        // Close other open accordions
        document.querySelectorAll('.accordion-item').forEach(otherItem => {
            if (otherItem !== parent) {
                otherItem.classList.remove('active');
                otherItem.querySelector('i').classList.replace('fa-minus', 'fa-plus');
            }
        });
    });
});

    </script>
</body>
</html>

<?php
mysqli_close($con);
?>

