<?php
define('APP', true); // Define the APP constant to allow access

session_start();
require_once 'functions.php'; // Include your functions.php file
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <style>
		@keyframes appear{
			0%{
				opacity: 0;
			}
			100%{
				opacity: 1;
			}
		}

		.hide{
			display:none;
		}

        .clickable-boxes {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin: 20px;
        }
        .clickable-box {
            display: flex;
            align-items: center;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            cursor: pointer;
            background-color: #f9f9f9;
            transition: background-color 0.3s ease;
            width: 100%;
            max-width: 300px;
        }
        .clickable-box img {
            margin-right: 15px;
        }
        .clickable-box:hover {
            background-color: #e0e0e0;
        }
        @media (max-width: 600px) {
            .clickable-box {
                flex-direction: column;
                text-align: ;
            }
            .clickable-box img {
                margin-bottom: 10px;
                margin-right: 0;
                height: 20px;
                width: 240px;
            }
            
        }
    </style>
</head>
<body>
    <section class="class_1">
        <header class="class_2">
            <div class="class_3">
                <img src="bg/logo3.png" class="class_4">
            </div>
            <div class="item_class_0 class_5">
                <div class="item_class_1 class_6">
                    <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="m22 16.75c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75zm0-5c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75zm0-5c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75z" fill-rule="nonzero">
                        </path>
                    </svg>
                </div>
                <div class="item_class_2 class_7">
                    <a href="index.html" class="class_8">Home</a>
                    <a href="about.html" class="class_8">About us</a>
                    <a href="dialects.html" class="class_8">Dialects</a>
                    <a href="forum.html" class="class_8">Forum</a>
                </div>
            </div>
            <div class="class_9">
                <img src="assets/images/user.jpg" class="class_10">
                Hi, User
            </div>
        </header>

        <div class="clickable-boxes">
            <div class="clickable-box" onclick="location.href='#';">
                <img src="assets/images/arrowhead.png" alt="Arrowhead">
                <span>Label 1</span>
            </div>
            <div class="clickable-box" onclick="location.href='#';">
                <img src="assets/images/arrowhead.png" alt="Arrowhead">
                <span>Label 2</span>
            </div>
            <div class="clickable-box" onclick="location.href='#';">
                <img src="assets/images/arrowhead.png" alt="Arrowhead">
                <span>Label 3</span>
            </div>
            <div class="clickable-box" onclick="location.href='#';">
                <img src="assets/images/arrowhead.png" alt="Arrowhead">
                <span>Label 4</span>
            </div>
        </div>

        <footer class="footer">
            <ul class="social-icon">
                <li class="social-icon__item"><a class="social-icon__link" href="#"><ion-icon name="logo-facebook"></ion-icon></a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#"><ion-icon name="logo-twitter"></ion-icon></a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#"><ion-icon name="logo-linkedin"></ion-icon></a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#"><ion-icon name="logo-instagram"></ion-icon></a></li>
            </ul>
            <ul class="f-menu">
                <li class="menu__item"><a class="menu__link" href="#">Home</a></li>
                <li class="menu__item"><a class="menu__link" href="about.html">About</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Dialects</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Forum</a></li>
            </ul>
            <p>2024 Albay Dialects | All Rights Reserved</p>
        </footer>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </section>
    <!-- Scroll to top button -->
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
</body>
</html>
