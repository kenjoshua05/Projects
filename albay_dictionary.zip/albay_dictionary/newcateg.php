<?php
define('APP', true); // Define the APP constant to allow access
require('config.inc.php');
require('functions.php');

// Check if category ID is provided
if (!isset($_GET['category_id'])) {
    die("Category ID not provided.");
}

// Sanitize category ID
$category_id = mysqli_real_escape_string($con, $_GET['category_id']);

// Fetch category name for display
$category_query = "SELECT name FROM categories WHERE id='$category_id'";
$category_result = mysqli_query($con, $category_query);
$category = mysqli_fetch_assoc($category_result);

// Handle search functionality
$search_term = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';

// Fetch words from dialect_data table for the given category
$words_query = "SELECT id, word FROM dialect_data WHERE category_id='$category_id' AND word LIKE '%$search_term%' ORDER BY word ASC";
$words_result = mysqli_query($con, $words_query);

// Handle sorting by letter
$sort_letter = isset($_GET['sort']) ? mysqli_real_escape_string($con, $_GET['sort']) : '';

if ($sort_letter) {
    $words_query = "SELECT id, word FROM dialect_data WHERE category_id='$category_id' AND word LIKE '$sort_letter%' ORDER BY word ASC";
    $words_result = mysqli_query($con, $words_query);
}

// Fetch common conversations for the given category
$common_query = "SELECT id, phrase, example FROM common_conversations WHERE category_id='$category_id'";
$common_result = mysqli_query($con, $common_query);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($category['name']); ?></title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <style>
        @keyframes appear{
            0%{
                opacity: 0;
            }
            100%{
                opacity: 1;
            }
        }

        .hide{
            display:none;
        }
    </style>
</head>
<body>
    <section class="class_1">
        <?php include('header.inc.php'); ?>
        <div class="categname">
            <h1><?php echo htmlspecialchars($category['name']); ?></h1>
        </div>
        <div class="search-container">
            <form method="get" action="">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search_term); ?>" placeholder="Search...">
                <input type="hidden" name="category_id" value="<?php echo htmlspecialchars($category_id); ?>">
                <input type="submit" value="Search">
            </form>
        </div>
        <div class="container">
            <div class="word-grid" id="wordGrid">
                <?php if (mysqli_num_rows($words_result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($words_result)) : ?>
                        <div class="word-item" data-letter="<?php echo strtoupper($row['word'][0]); ?>">
                            <a href="word.php?id=<?php echo $row['id']; ?>">
                                <?php echo htmlspecialchars($row['word']); ?>
                            </a>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p id="noWordsMessage" style="color: red;">No words found.</p>
                <?php endif; ?>
            </div>
        </div>

        <h2 style="text-align: center; color: #00ab66; padding-bottom: 10px;">Sort By First Letter</h2>

        <div class="sorting-container">
            <?php foreach (range('A', 'Z') as $letter): ?>
                <a href="?category_id=<?php echo htmlspecialchars($category_id); ?>&sort=<?php echo $letter; ?>" class="sorting-link"><?php echo $letter; ?></a>
            <?php endforeach; ?>
        </div>

        <hr>

        <div class="common">
            <h1>Common Conversations</h1>
            <div class="example">
                <input type="text" id="myInput" name="search_examples" onkeyup="searchExamples()" placeholder="Search for examples..." title="Type in a keyword">
                <?php while ($row = mysqli_fetch_assoc($common_result)) : ?>
                    <div class="accordion-item">
                        <button class="accordion"><?php echo htmlspecialchars($row['phrase']); ?>
                            <img class="arrow" src="bg/down-arrow.png"> <!-- PNG image for arrow -->
                        </button>
                        <div class="panel">
                            <button class="mark-done" onclick="markAsDone(this)">Mark as Done</button>
                            <p><b>Example:</b> <?php echo htmlspecialchars($row['example']); ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <footer class="footer">
            <ul class="social-icon">
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-twitter"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-linkedin"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
            </ul>
            <ul class="f-menu">
                <li class="menu__item"><a class="menu__link" href="#">Home</a></li>
                <li class="menu__item"><a class="menu__link" href="about.html">About</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Dialects</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Forum</a></li>
            </ul>
            <p>2024 Albay Dialects | All Rights Reserved</p>
        </footer>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <?php include('signup.inc.php') ?>
        <?php include('login.inc.php') ?>
    </section>
    <!-- Scroll to top button -->
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
    <script>
        function searchExamples() {
            var input, filter, examples, p, i, txtValue;
            input = document.getElementById('myInput');
            filter = input.value.toUpperCase();
            examples = document.getElementsByClassName('accordion-item');
            
            for (i = 0; i < examples.length; i++) {
                p = examples[i].getElementsByClassName('panel')[0].getElementsByTagName('p')[0];
                txtValue = p.textContent || p.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    examples[i].style.display = "";
                } else {
                    examples[i].style.display = "none";
                }
            }
        }
    </script>
</body>
</html>

<?php
mysqli_close($con);
?>
