<?php
// Start session and include database connection
session_start();
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">' . 
         $_SESSION['success_message'] . 
         '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . 
         '<span aria-hidden="true">&times;</span>' . 
         '</button></div>';
    unset($_SESSION['success_message']); // Clear the message after displaying it
}

if (isset($_SESSION['error_message'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">' . 
         $_SESSION['error_message'] . 
         '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' . 
         '<span aria-hidden="true">&times;</span>' . 
         '</button></div>';
    unset($_SESSION['error_message']); // Clear the message after displaying it
}


// Fetch all categories from the database
$query = "SELECT * FROM categories";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>Admin - Manage Categories</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 30px;
            font-size: 28px;
            font-weight: 600;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .add-new {
            margin-bottom: 20px;
        }

        .add-new a.add-button {
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 14px;
            display: inline-block;
        }

        .add-new a.add-button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .admin-footer {
            margin-top: 30px;
            text-align: center;
        }
        .dashboard-arrow {
            position: relative; /* Use relative positioning */
            top: 0; /* Reset the top positioning */
            left: 0; /* Align to the left */
            font-size: 24px; /* Adjust the icon size */
            color: #007bff; /* Change the icon color */
            text-decoration: none; /* Remove underline */
            transition: color 0.3s;
            margin-bottom: 10px; /* Add space between the button and heading */
        }

        .dashboard-arrow:hover {
            color: #0056b3; /* Darker color on hover */
        }

    </style>
</head>
<body>

    <div class="container">

    <a href="admin_dashboard.php" class="dashboard-arrow">
        <i class="fas fa-arrow-left"></i>
    </a>

        <h1>Manage Categories</h1>
        <div class="add-new">
            <a href="admin_upload_category.php" class="add-button"><i class="fas fa-plus"></i> Add New</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td class="actions">
                            <a href="update_category.php?id=<?php echo urlencode($row['id']); ?>"><i class="fas fa-edit"></i> Edit</a>
                            <a href="delete_category.php?id=<?php echo urlencode($row['id']); ?>" onclick="return confirm('Are you sure you want to delete this category?')"><i class="fas fa-trash-alt"></i> Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <footer class="admin-footer">
            <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>

<?php
// Close database connection
mysqli_close($con);
?>