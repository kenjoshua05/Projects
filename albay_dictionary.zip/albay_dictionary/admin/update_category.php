<?php
// Start the session
session_start();

// Include the functions.php file for database connection and functions
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection (assuming DB_HOST, DB_USER, DB_PASS, DB_NAME are defined in functions.php)
$con = db_connect(); // Function from functions.php to connect to database
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch the category data for the given id
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "Category ID not provided.";
    header('Location: display_categories.php');
    exit;
}

$id = mysqli_real_escape_string($con, $_GET['id']);

$query = "SELECT * FROM categories WHERE id='$id'";
$result = mysqli_query($con, $query);

if (!$result) {
    $_SESSION['error_message'] = "Failed to fetch category data: " . mysqli_error($con);
    header('Location: display_categories.php');
    exit;
}

$category = mysqli_fetch_assoc($result);

if (!$category) {
    $_SESSION['error_message'] = "Category not found.";
    header('Location: display_categories.php');
    exit;
}

// Check if the form is submitted for updating
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $new_name = mysqli_real_escape_string($con, $_POST['name']);

    // Update the category name in the database
    $query = "UPDATE categories SET name='$new_name' WHERE id='$id'";
    $result = mysqli_query($con, $query);

    if ($result) {
        $_SESSION['success_message'] = "Category updated successfully.";
        header('Location: display_categories.php');
        exit;
    } else {
        $_SESSION['error_message'] = "Failed to update category: " . mysqli_error($con);
        header('Location: update_category.php?id=' . urlencode($id));
        exit;
    }
}

// Close database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Category</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .admin-section {
            max-width: 60%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .admin-footer{
            text-align: center;
        }
    </style>
</head>
<body>
    <section class="admin-section">
        <h1>Update Category</h1>
        <form action="update_category.php?id=<?php echo urlencode($id); ?>" method="post">
            <div>
                <label for="name">Category Name:</label>
                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
            </div>
            <div>
                <input type="submit" value="Update">
            </div>
        </form>
    </section>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
