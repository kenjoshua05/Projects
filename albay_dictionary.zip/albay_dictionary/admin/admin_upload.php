<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

// Establish database connection
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch categories
$query = "SELECT id, name FROM categories";
$result = mysqli_query($con, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Store categories in an array
$categories = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row;
}

// Close the database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css"> <!-- Link to your external CSS file -->
    <title>Admin - Upload Dialect Data</title>
    <style>
body {
    margin: 0;
    padding: 0;
    background-color: #f4f6f9;
    color: #333;
}

h1 {
    text-align: center;
    color: #222;
    margin: 30px 0;
    font-size: 2rem;
    font-weight: 600;
}

.admin-section {
    max-width: 800px;
    margin: 30px auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border: 1px solid #e0e0e0;
    transition: box-shadow 0.3s ease-in-out;
    overflow-y: auto; /* Allow vertical scrolling */
    max-height: 80vh; /* Set a maximum height for the container */
}

.admin-section:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
}

form {
    width: 100%;
}

div {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #555;
}

input[type="text"],
textarea,
select {
    width: 100%;
    padding: 14px;
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus,
textarea:focus,
select:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
}

textarea {
    resize: vertical;
}

input[type="file"] {
    margin-top: 10px;
}

input[type="submit"] {
    background-color: #007bff;
    color: #ffffff;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

input[type="submit"]:hover {
    background-color: #0056b3;
    transform: translateY(-2px);
}

input[type="submit"]:active {
    transform: translateY(0);
}

.admin-footer{
    text-align:center;
}

    </style>
</head>
<body>
    <section class="admin-section">
        <h1>Admin Panel - Upload Dialect Data</h1>
        <form id="uploadForm" action="admin_process.php" method="post" enctype="multipart/form-data">
            <div>
                <label for="category_id">Category:</label>
                <select name="category_id" id="category_id" required>
                    <option value="" selected>Select Category</option>
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?php echo htmlspecialchars($category['id']); ?>">
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="audio_file">Upload Audio File:</label>
                <input type="file" name="audio_file" id="audio_file" accept="audio/*">
            </div>
            <div>
                <label for="word">Word:</label>
                <input type="text" name="word" id="word" required>
            </div>
            <div>
                <label for="pronunciation">Pronunciation Guide:</label>
                <textarea name="pronunciation" id="pronunciation"></textarea>
            </div>
            <div>
                <label for="example1">Example 1 (Dialect):</label>
                <textarea name="example1" id="example1"></textarea>
            </div>
            <div>
                <label for="example1_tagalog">Example 1 (Tagalog):</label>
                <textarea name="example1_tagalog" id="example1_tagalog"></textarea>
            </div>
            <div>
                <label for="example1_english">Example 1 (English):</label>
                <textarea name="example1_english" id="example1_english"></textarea>
            </div>
            <div>
                <label for="example2">Example 2 (Dialect):</label>
                <textarea name="example2" id="example2"></textarea>
            </div>
            <div>
                <label for="example2_tagalog">Example 2 (Tagalog):</label>
                <textarea name="example2_tagalog" id="example2_tagalog"></textarea>
            </div>
            <div>
                <label for="example2_english">Example 2 (English):</label>
                <textarea name="example2_english" id="example2_english"></textarea>
            </div>
            <div>
                <label for="tagalog_meaning">Tagalog Meaning:</label>
                <textarea name="tagalog_meaning" id="tagalog_meaning"></textarea>
            </div>
            <div>
                <label for="english_meaning">English Meaning:</label>
                <textarea name="english_meaning" id="english_meaning"></textarea>
            </div>
            <div>
                <input type="submit" value="Upload">
            </div>
        </form>
    </section>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
