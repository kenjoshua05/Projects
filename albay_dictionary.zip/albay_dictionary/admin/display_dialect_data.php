<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

// Initialize variables for sorting, searching, and pagination
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'id'; // Default sort by ID
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC'; // Default order ASC
$search_word = isset($_GET['search_word']) ? $_GET['search_word'] : ''; // Search keyword

// Pagination variables
$limit = 20; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate offset

// Fetch all data from the dialect_data table including category information
$query = "SELECT dd.*, c.name AS category_name 
          FROM dialect_data dd 
          LEFT JOIN categories c ON dd.category_id = c.id";

// Check if category filter is applied
if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $category_id = mysqli_real_escape_string($con, $_GET['category_id']);
    $query .= " WHERE dd.category_id = '$category_id'";
}

// Add search filter if search keyword is provided
if (!empty($search_word)) {
    $search_word = mysqli_real_escape_string($con, $search_word);
    if (strpos($query, 'WHERE') === false) {
        $query .= " WHERE dd.word LIKE '%$search_word%'";
    } else {
        $query .= " AND dd.word LIKE '%$search_word%'";
    }
}

// Add sorting to the query with the correct table alias
$sort = in_array($sort, ['id', 'word', 'category_name']) ? $sort : 'id'; // Sanitize sort column

// Adjust ORDER BY clause based on whether the sort is category_name or another column
if ($sort === 'category_name') {
    $query .= " ORDER BY c.name $order"; // Sort by category name from the categories table
} else {
    $query .= " ORDER BY dd.$sort $order"; // Sort by other fields in the dialect_data table
}


// Get the total number of records for pagination
$total_query = "SELECT COUNT(*) as total_records FROM dialect_data dd";
if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $total_query .= " WHERE dd.category_id = '$category_id'";
}
if (!empty($search_word)) {
    if (strpos($total_query, 'WHERE') === false) {
        $total_query .= " WHERE dd.word LIKE '%$search_word%'";
    } else {
        $total_query .= " AND dd.word LIKE '%$search_word%'";
    }
}
$total_result = mysqli_query($con, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_records = $total_row['total_records'];

// Add pagination limit and offset
$query .= " LIMIT $limit OFFSET $offset";

$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Check if there are no results
$num_rows = mysqli_num_rows($result);

if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
    unset($_SESSION['success_message']); // Clear the message after displaying it
}

if (isset($_SESSION['error_message'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
    unset($_SESSION['error_message']); // Clear the message after displaying it
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Dialect Data</title>
    <style>

.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}

.alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

.alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
}


.table-wrapper {
    width: 100%;
    overflow-x: auto; /* Enables horizontal scrolling */
    margin-top: 20px;
}

                        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .dashboard-arrow {
    position: relative; /* Use relative positioning */
    top: 0; /* Reset the top positioning */
    left: 0; /* Align to the left */
    font-size: 24px; /* Adjust the icon size */
    color: #007bff; /* Change the icon color */
    text-decoration: none; /* Remove underline */
    transition: color 0.3s;
    margin-bottom: 10px; /* Add space between the button and heading */
}

.dashboard-arrow:hover {
    color: #0056b3; /* Darker color on hover */
}


        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .search-controls, .sorting-controls {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .search-controls label, .sorting-controls label {
            margin-right: 10px;
            font-weight: 500;
        }

        .search-controls input[type="text"], .sorting-controls select {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .search-controls input[type="submit"], .sorting-controls input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .search-controls input[type="submit"]:hover, .sorting-controls input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .add-button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            transition: background-color 0.3s;

        }

        .add-button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 1200px;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
            white-space: nowrap; 
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions a {
        color: #007bff;
        text-decoration: none;
        font-size: 16px; /* Adjust the size of icons and text */
        margin-right: 15px; /* Add space between the actions */
        display: flex;
        align-items: center;
    }

.actions a i {
    margin-right: 5px; /* Space between the icon and text */
}

.actions a:hover {
    color: #0056b3;
}

        .no-results {
            text-align: center;
            color: red;
            font-style: italic;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }
        .pagination {
    margin: 20px 0;
    display: flex;
    justify-content: center;
    gap: 5px;
    flex-wrap: wrap; /* Allows the pagination to wrap to the next line if necessary */
    align-items: center; /* Center align the items vertically */
}

.pagination a, .pagination span {
    display: inline-block;
    padding: 10px 15px;
    text-decoration: none;
    color: #007bff;
    border: 1px solid #ddd;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
    font-size: 14px; /* Adjust font size */
}

.pagination a:hover {
    background-color: #f1f1f1;
    color: #0056b3;
}

.pagination .active {
    background-color: #007bff;
    color: #fff;
    border-color: #007bff;
}

.pagination .disabled {
    color: #ddd;
    cursor: not-allowed;
}

/* Media query for small screens */
@media (max-width: 600px) {
    .pagination a, .pagination span {
        padding: 8px 12px; /* Smaller padding on mobile */
        font-size: 12px; /* Smaller font size for mobile */
    }

    /* Ensure items don't overflow on mobile and wrap correctly */
    .pagination {
        justify-content: flex-start; /* Align left on mobile to prevent overflow */
    }
}

/* Prevent pagination from overflowing when it exceeds screen width */
@media (max-width: 768px) {
    .pagination {
        justify-content: space-between; /* Spread out items when screen width is limited */
    }

    .pagination a, .pagination span {
        white-space: nowrap; /* Prevent the text from wrapping inside the button */
    }
}

       

        .admin-footer{
            margin-top:30px;
        }
        .admin-footer p{
            text-align:center;
        }
    </style>
</head>
<body>

<div class="container">
<a href="admin_dashboard.php" class="dashboard-arrow">
    <i class="fas fa-arrow-left"></i>
</a>
            <h1>Dialect Data</h1>
            <!-- Search controls -->
            <div class="search-controls">
                <form action="display_dialect_data.php" method="get">
                    <label for="search_word">Search Word:</label>
                    <input type="text" name="search_word" id="search_word" value="<?php echo htmlspecialchars($search_word); ?>">
                    <input type="submit" value="Search">
                </form>
            </div>

            <!-- Sorting controls -->
            <div class="sorting-controls">
                <form action="display_dialect_data.php" method="get">
                    <label for="sort">Sort by:</label>
                    <select name="sort" id="sort">
                        <option value="id" <?php echo ($sort === 'id') ? 'selected' : ''; ?>>ID</option>
                        <option value="word" <?php echo ($sort === 'word') ? 'selected' : ''; ?>>Word</option>
                        <option value="category_name" <?php echo ($sort === 'category_name') ? 'selected' : ''; ?>>Category</option>
                    </select>
                    <label for="order">Order:</label>
                    <select name="order" id="order">
                        <option value="ASC" <?php echo ($order === 'ASC') ? 'selected' : ''; ?>>Ascending</option>
                        <option value="DESC" <?php echo ($order === 'DESC') ? 'selected' : ''; ?>>Descending</option>
                    </select>
                    <input type="submit" value="Apply Sorting">
                </form>
            </div>

            <div class="add-new">
        <a href="admin_upload.php" class="add-button"><i class="fas fa-plus"></i> Add New</a>
            </div>
            <!-- Table displaying dialect data -->

            <div class="table-wrapper">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Audio File</th>
                    <th>Word</th>
                    <th>Pronunciation Guide</th>
                    <th>Example 1 (Dialect)</th>
                    <th>Example 1 (Tagalog)</th>
                    <th>Example 1 (English)</th>
                    <th>Example 2 (Dialect)</th>
                    <th>Example 2 (Tagalog)</th>
                    <th>Example 2 (English)</th>
                    <th>Tagalog Meaning</th>
                    <th>English Meaning</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
                <?php if ($num_rows === 0) : ?>
                    <tr>
                        <td colspan="14" class="no-results">No results found.</td>
                    </tr>
                <?php else : ?>
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                        
                            <td>
                                <?php if (!empty($row['audio_file'])): ?>
                                    <audio controls>
                                        <source src="<?php echo htmlspecialchars($row['audio_file']); ?>" type="audio/mpeg">
                                        Your browser does not support the audio element.
                                    </audio>
                                <?php else: ?>
                                    No audio available
                                <?php endif; ?>
                            </td>


                            <td><?php echo htmlspecialchars($row['word']); ?></td>
                            <td title="<?php echo htmlspecialchars($row['pronunciation']); ?>">
                                <?php echo strlen($row['pronunciation']) > 20 ? substr($row['pronunciation'], 0, 20) . '...' : $row['pronunciation']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example1']); ?>">
                                <?php echo strlen($row['example1']) > 20 ? substr($row['example1'], 0, 20) . '...' : $row['example1']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example1_tagalog']); ?>">
                                <?php echo strlen($row['example1_tagalog']) > 20 ? substr($row['example1_tagalog'], 0, 20) . '...' : $row['example1_tagalog']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example1_english']); ?>">
                                <?php echo strlen($row['example1_english']) > 20 ? substr($row['example1_english'], 0, 20) . '...' : $row['example1_english']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example2']); ?>">
                                <?php echo strlen($row['example2']) > 20 ? substr($row['example2'], 0, 20) . '...' : $row['example2']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example2_tagalog']); ?>">
                                <?php echo strlen($row['example2_tagalog']) > 20 ? substr($row['example2_tagalog'], 0, 20) . '...' : $row['example2_tagalog']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['example2_english']); ?>">
                                <?php echo strlen($row['example2_english']) > 20 ? substr($row['example2_english'], 0, 20) . '...' : $row['example2_english']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['tagalog_meaning']); ?>">
                                <?php echo strlen($row['tagalog_meaning']) > 20 ? substr($row['tagalog_meaning'], 0, 20) . '...' : $row['tagalog_meaning']; ?>
                            </td>
                            <td title="<?php echo htmlspecialchars($row['english_meaning']); ?>">
                                <?php echo strlen($row['english_meaning']) > 20 ? substr($row['english_meaning'], 0, 20) . '...' : $row['english_meaning']; ?>
                            </td>

                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                            <td class="actions">
                            <a href="view_dialect_data.php?id=<?php echo $row['id']; ?>" title="View">
                                <i class="fas fa-eye"></i> View
                            </a>
                                <a href="update_dialect_data.php?id=<?php echo $row['id']; ?>" title="Edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="delete_dialect_data.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this data?');" title="Delete">
                                    <i class="fas fa-trash-alt"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </table>
            </div>

            <!-- Pagination controls -->
            <div class="pagination">
                <?php
                $total_pages = ceil($total_records / $limit);
                $current_page = $page;

                if ($current_page > 1) {
                    echo '<a href="?page=' . ($current_page - 1) . '&sort=' . $sort . '&order=' . $order . '&search_word=' . htmlspecialchars($search_word) . '">Previous</a>';
                } else {
                    echo '<span class="disabled">Previous</span>';
                }

                for ($i = 1; $i <= $total_pages; $i++) {
                    if ($i == $current_page) {
                        echo '<span class="active">' . $i . '</span>';
                    } else {
                        echo '<a href="?page=' . $i . '&sort=' . $sort . '&order=' . $order . '&search_word=' . htmlspecialchars($search_word) . '">' . $i . '</a>';
                    }
                }

                if ($current_page < $total_pages) {
                    echo '<a href="?page=' . ($current_page + 1) . '&sort=' . $sort . '&order=' . $order . '&search_word=' . htmlspecialchars($search_word) . '">Next</a>';
                } else {
                    echo '<span class="disabled">Next</span>';
                }
                ?>
            </div>
        </div>
    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

</body>
</html>

<?php
// Close the database connection
mysqli_close($con);
?>