<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Dialect Data</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
            color: #333;
        }
        
        h1 {
            text-align: center;
            color: #222;
            margin: 30px 0;
            font-size: 2rem;
            font-weight: 600;
        }
        
        form {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #e0e0e0;
            transition: box-shadow 0.3s ease-in-out;
        }

        form:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        div {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 14px;
            border: 1px solid #dcdcdc;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="text"]:focus,
        textarea:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
        }

        textarea {
            resize: vertical;
        }

        input[type="file"] {
            margin-top: 10px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        input[type="submit"]:active {
            transform: translateY(0);
        }

        a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .message {
            margin: 20px auto;
            max-width: 800px;
            padding: 15px;
            border-radius: 8px;
            color: #fff;
            font-weight: 500;
            text-align: center;
            background-color: #dc3545;
        }

        .message.success {
            background-color: #28a745;
        }

        .message.error {
            background-color: #dc3545;
        }

        .admin-footer{
            text-align:center;
        }
    </style>
</head>
<body>
    <h1>Update Dialect Data</h1>
    <?php
    // Start the session
    session_start();

    // Include the functions.php file for database connection
    require_once 'functions.php';

    if (!isset($_SESSION['ADMIN'])) {
        header("Location:admin_login.php");
        exit;
    }
    
    $admin = $_SESSION['ADMIN'];

    // Establish database connection (assuming DB_HOST, DB_USER, DB_PASS, DB_NAME are defined in functions.php)
    $con = db_connect(); // Function from functions.php to connect to database
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch the data for the given id
    if (!isset($_GET['id'])) {
        header('Location: display_dialect_data.php');
        exit;
    }

    $id = mysqli_real_escape_string($con, $_GET['id']);

    $query = "SELECT * FROM dialect_data WHERE id='$id'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($con));
    }

    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        header('Location: display_dialect_data.php');
        exit;
    }

    // Fetch all categories from the categories table
    $query_categories = "SELECT id, name FROM categories";
    $result_categories = mysqli_query($con, $query_categories);

    if (!$result_categories) {
        die("Query failed: " . mysqli_error($con));
    }

    // Check if the form is submitted for updating
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve and sanitize form data
        $id = mysqli_real_escape_string($con, trim($_POST['id']));
        $word = mysqli_real_escape_string($con, trim($_POST['word']));
        $pronunciation = mysqli_real_escape_string($con, trim($_POST['pronunciation']));
        $example1 = mysqli_real_escape_string($con, trim($_POST['example1']));
        $example1_tagalog = mysqli_real_escape_string($con, trim($_POST['example1_tagalog']));
        $example1_english = mysqli_real_escape_string($con, trim($_POST['example1_english']));
        $example2 = mysqli_real_escape_string($con, trim($_POST['example2']));
        $example2_tagalog = mysqli_real_escape_string($con, trim($_POST['example2_tagalog']));
        $example2_english = mysqli_real_escape_string($con, trim($_POST['example2_english']));
        $tagalog_meaning = mysqli_real_escape_string($con, trim($_POST['tagalog_meaning']));
        $english_meaning = mysqli_real_escape_string($con, trim($_POST['english_meaning']));
        $category_id = mysqli_real_escape_string($con, trim($_POST['category_id']));

        // Handle audio file upload if a new file is uploaded
        $audio_file = $data['audio_file']; // Default to current audio file
        if ($_FILES['audio_file']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            $upload_file = $upload_dir . basename($_FILES['audio_file']['name']);
            if (move_uploaded_file($_FILES['audio_file']['tmp_name'], $upload_file)) {
                $audio_file = $upload_file;
            } else {
                $_SESSION['error_message'] = "Failed to upload audio file.";
                header('Location: update_dialect_data.php?id=' . urlencode($id));
                exit;
            }
        }

        // Update the data in the database
        $query = "UPDATE dialect_data SET 
            word='$word',
            pronunciation='$pronunciation',
            example1='$example1',
            example1_tagalog='$example1_tagalog',
            example1_english='$example1_english',
            example2='$example2',
            example2_tagalog='$example2_tagalog',
            example2_english='$example2_english',
            tagalog_meaning='$tagalog_meaning',
            english_meaning='$english_meaning',
            category_id='$category_id',
            audio_file='$audio_file'
            WHERE id='$id'";

        $result = mysqli_query($con, $query);

        if ($result) {
            $_SESSION['success_message'] = "Data updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update data.";
        }

        // Redirect back to display page
        header('Location: display_dialect_data.php');
        exit;
    }
    ?>
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="message error">
            <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
        </div>
    <?php endif; ?>
    <form action="update_dialect_data.php?id=<?php echo urlencode($id); ?>" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($data['id']); ?>">
        <div>
            <label for="word">Word:</label>
            <input type="text" name="word" id="word" value="<?php echo htmlspecialchars($data['word']); ?>" required>
        </div>
        <div>
            <label for="pronunciation">Pronunciation:</label>
            <textarea name="pronunciation" id="pronunciation"><?php echo htmlspecialchars($data['pronunciation']); ?></textarea>
        </div>
        <div>
            <label for="example1">Example 1 (Dialect):</label>
            <textarea name="example1" id="example1"><?php echo htmlspecialchars($data['example1']); ?></textarea>
        </div>
        <div>
            <label for="example1_tagalog">Example 1 (Tagalog):</label>
            <textarea name="example1_tagalog" id="example1_tagalog"><?php echo htmlspecialchars($data['example1_tagalog']); ?></textarea>
        </div>
        <div>
            <label for="example1_english">Example 1 (English):</label>
            <textarea name="example1_english" id="example1_english"><?php echo htmlspecialchars($data['example1_english']); ?></textarea>
        </div>
        <div>
            <label for="example2">Example 2 (Dialect):</label>
            <textarea name="example2" id="example2"><?php echo htmlspecialchars($data['example2']); ?></textarea>
        </div>
        <div>
            <label for="example2_tagalog">Example 2 (Tagalog):</label>
            <textarea name="example2_tagalog" id="example2_tagalog"><?php echo htmlspecialchars($data['example2_tagalog']); ?></textarea>
        </div>
        <div>
            <label for="example2_english">Example 2 (English):</label>
            <textarea name="example2_english" id="example2_english"><?php echo htmlspecialchars($data['example2_english']); ?></textarea>
        </div>
        <div>
            <label for="tagalog_meaning">Tagalog Meaning:</label>
            <textarea name="tagalog_meaning" id="tagalog_meaning"><?php echo htmlspecialchars($data['tagalog_meaning']); ?></textarea>
        </div>
        <div>
            <label for="english_meaning">English Meaning:</label>
            <textarea name="english_meaning" id="english_meaning"><?php echo htmlspecialchars($data['english_meaning']); ?></textarea>
        </div>
        <div>
            <label for="category_id">Category:</label>
            <select name="category_id" id="category_id">
                <?php while ($row = mysqli_fetch_assoc($result_categories)): ?>
                    <option value="<?php echo htmlspecialchars($row['id']); ?>" <?php echo $row['id'] == $data['category_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($row['name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div>
            <label for="audio_file">Audio File:</label>
            <input type="file" name="audio_file" id="audio_file" accept="audio/*">
            <small>Leave this field empty if you don't want to change the audio file.</small>
        </div>
        <div>
            <input type="submit" value="Update Data">
        </div>
    </form>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
