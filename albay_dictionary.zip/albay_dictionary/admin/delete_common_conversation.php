<?php
// Start the session
session_start();

// Include database connection parameters and functions
require_once 'functions.php';

// Establish database connection
$con = db_connect();
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if id parameter exists
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid request. No ID specified.";
    header('Location: display_common_conversations.php');
    exit;
}

$id = mysqli_real_escape_string($con, $_GET['id']);

// Delete the conversation from the database
$query = "DELETE FROM common_conversations WHERE id='$id'";
$result = mysqli_query($con, $query);

if ($result) {
    $_SESSION['success_message'] = "Common conversation deleted successfully.";
} else {
    $_SESSION['error_message'] = "Failed to delete common conversation.";
}

// Close database connection
mysqli_close($con);

// Redirect back to display page
header('Location: display_common_conversations.php');
exit;
?>
