<?php
include 'functions.php';
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Retrieve posted data
$title = $_POST['title'];
$description = $_POST['description'];
$category_id = $_POST['category'];
$max_attempts = $_POST['max_attempts']; // Get maximum attempts
$questions = $_POST['questions'];

// Validate and insert quiz
$con = db_connect();
$insertQuizQuery = "INSERT INTO quizzes (title, description, category_id, max_attempts) VALUES (?, ?, ?, ?)";
$stmt = $con->prepare($insertQuizQuery);
$stmt->bind_param('ssii', $title, $description, $category_id, $max_attempts); // Bind max_attempts
$stmt->execute();
$quiz_id = $stmt->insert_id;

// Insert questions and choices
foreach ($questions as $question_data) {
    $question_text = $question_data['text'];
    $insertQuestionQuery = "INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)";
    $stmt = $con->prepare($insertQuestionQuery);
    $stmt->bind_param('is', $quiz_id, $question_text);
    $stmt->execute();
    $question_id = $stmt->insert_id;

    foreach ($question_data['choices'] as $index => $choice_text) {
        $is_correct = ($index == $question_data['correct_choice']) ? 1 : 0;
        $insertChoiceQuery = "INSERT INTO choices (question_id, choice_text, is_correct) VALUES (?, ?, ?)";
        $stmt = $con->prepare($insertChoiceQuery);
        $stmt->bind_param('isi', $question_id, $choice_text, $is_correct);
        $stmt->execute();
    }
}

db_close($con);
header("Location: admin_quiz_list.php"); // Redirect to a page showing list of quizzes
?>
