<?php
require_once 'functions.php';
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="styles.css"> <!-- Link to your external CSS file -->
</head>
<body>
    <div class="dashboard-container">
    <div class="toggle-sidebar">
    <i class="fas fa-bars"></i> Menu
</div>

<aside class="sidebar">
    <a href="admin_profile.php">
        <img src="<?php echo $_SESSION['ADMIN']['profile_image'] ?? 'profile_pics/default_profile.jpg'; ?>" 
            alt="Profile Picture" class="profile-picture">
    </a>
    <h1 class="logo">Admin Panel</h1>
    <nav class="nav">
        <a href="display_common_conversations.php" class="nav-item">
            <i class="fas fa-comments"></i>
            Conversations
        </a>
        <a href="display_dialect_data.php" class="nav-item">
            <i class="fas fa-book"></i>
            Words
        </a>
        <a href="display_categories.php" class="nav-item">
            <i class="fas fa-th-list"></i>
            Categories
        </a>
        <a href="logout.php" class="nav-item">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </nav>
</aside>

        <main class="main-content">
            <div class="cards-container">
                <a href="admin_upload.php" class="card">
                    <i class="fas fa-plus-circle"></i>
                    Add Word
                </a>
                <a href="display_dialect_data.php" class="card">
                    <i class="fas fa-edit"></i>
                    Edit Word
                </a>
                <a href="admin_upload_category.php" class="card">
                    <i class="fas fa-folder-plus"></i>
                    Add Category
                </a>
                <a href="display_categories.php" class="card">
                    <i class="fas fa-folder-open"></i>
                    Edit Category
                </a>
                <a href="admin_upload_conversation.php" class="card">
                    <i class="fas fa-comments"></i>
                    Add Conversation
                </a>
                <a href="display_common_conversations.php" class="card">
                    <i class="fas fa-comment-dots"></i>
                    Edit Conversation
                </a>
               
                <a href="add_admin.php" class="card">
                    <i class="fas fa-user-plus"></i>
                    Add New Admin
                </a>
                <a href="manage_admins.php" class="card">
                    <i class="fas fa-users"></i>
                    View Admins
                </a>
            </div>

            <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

        </main>
    </div>

    <script>
    document.querySelector('.toggle-sidebar').addEventListener('click', function () {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('visible');
    });
</script>

</body>
</html>
