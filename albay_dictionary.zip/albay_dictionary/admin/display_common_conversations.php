<?php
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Check for success or error messages
if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
    unset($_SESSION['success_message']); // Clear the message after displaying it
}

if (isset($_SESSION['error_message'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
    unset($_SESSION['error_message']); // Clear the message after displaying it
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin - Manage Common Conversations</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .search-controls, .sorting-controls {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .search-controls label, .sorting-controls label {
            margin-right: 10px;
            font-weight: 500;
        }

        .search-controls input[type="text"], .sorting-controls select {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            appearance: none;
            -webkit-appearance: none;
            background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%27http%3A//www.w3.org/2000/svg%27%20viewBox%3D%270%200%2024%2024%27%20fill%3D%27%23007bff%27%3E%3Cpath%20d%3D%27M12%2016.5l4-4H8z%27/%3E%3C/svg%3E');
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 12px 12px;
        }

        .search-controls select {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            appearance: none; /* Remove default arrow */
            -webkit-appearance: none; /* For WebKit browsers */
            background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%27http%3A//www.w3.org/2000/svg%27%20viewBox%3D%270%200%2024%2024%27%20fill%3D%27%23007bff%27%3E%3Cpath%20d%3D%27M12%2016.5l4-4H8z%27/%3E%3C/svg%3E'); /* Custom arrow */
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 12px 12px;
        }


        .search-controls select {
            padding-right: 30px;
        }

        .search-controls input[type="submit"], .sorting-controls input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .search-controls input[type="submit"]:hover, .sorting-controls input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto; /* Enables horizontal scrolling */
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .no-results {
            text-align: center;
            color: red;
            font-style: italic;
        }

        .actions a {
            color: #007bff;
            text-decoration: none;
            font-size: 16px; /* Adjust the size of icons and text */
            margin-right: 15px; /* Add space between the actions */
            display: flex;
            font-weight: 500;
            align-items: center;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .pagination-controls {
            margin-top: 20px;
            text-align: center;
        }

        .pagination-controls a {
            display: inline-block;
            margin: 0 5px;
            padding: 10px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .pagination-controls a:hover {
            background-color: #0056b3;
        }

        .pagination-controls a.active {
            background-color: #0056b3;
            pointer-events: none;
        }

        .admin-section a.add-button {
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 14px;
            display: inline-block;
            margin-bottom: 20px;
        }

        .admin-section a.add-button:hover {
            background-color: #0056b3;
        }
                

        .dashboard-button-fixed:active {
            transform: translateY(2px);
        }

        .admin-footer{
            margin-top:30px;
        }
        .admin-footer p{
            text-align:center;
        }
        .dashboard-arrow {
            position: relative; /* Use relative positioning */
            top: 0; /* Reset the top positioning */
            left: 0; /* Align to the left */
            font-size: 24px; /* Adjust the icon size */
            color: #007bff; /* Change the icon color */
            text-decoration: none; /* Remove underline */
            transition: color 0.3s;
            margin-bottom: 10px; /* Add space between the button and heading */
        }

        .dashboard-arrow:hover {
            color: #0056b3; /* Darker color on hover */
        }
    </style>
</head>
<body>

<div class="container">
    <a href="admin_dashboard.php" class="dashboard-arrow">
            <i class="fas fa-arrow-left"></i>
    </a>
    <section class="admin-section">
        <h1>Manage Common Conversations</h1>


        <div class="add-new">
            <a href="admin_upload_conversation.php" class="add-button"><i class="fas fa-plus"></i> Add New</a>
        </div>
        <form action="display_common_conversations.php" method="get" class="search-controls">
            <div>
                <label for="category_id">Sort by Category:</label>
                <select name="category_id" id="category_id">
                    <option value="">All Categories</option>
                    <?php
                    // Include database connection parameters and functions
                    require_once 'functions.php';

                    // Establish database connection
                    $con = db_connect();
                    if (!$con) {
                        die("Connection failed: " . mysqli_connect_error());
                    }

                    // Fetch categories from the database
                    $query = "SELECT id, name FROM categories";
                    $result = mysqli_query($con, $query);

                    if (!$result) {
                        die("Query failed: " . mysqli_error($con));
                    }

                    // Display categories in dropdown
                    while ($row = mysqli_fetch_assoc($result)) {
                        $selected = (isset($_GET['category_id']) && $_GET['category_id'] == $row['id']) ? 'selected' : '';
                        echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                    }

                    // Close database connection
                    mysqli_close($con);
                    ?>
                </select>
                <input type="submit" value="Sort">
            </div>
            <div>
                <label for="search">Search Phrase:</label>
                <input type="text" name="search" id="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <input type="submit" value="Search">
            </div>
        </form>
        <br>

        <?php
        // Establish database connection
        $con = db_connect();
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }

// Initialize query with basic data retrieval
$query = "SELECT cc.id, cat.name AS category, cc.phrase, cc.example 
          FROM common_conversations cc
          JOIN categories cat ON cc.category_id = cat.id";

// Check if category filter is applied (except when 'All Categories' is selected)
$conditions = [];

if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $category_id = mysqli_real_escape_string($con, $_GET['category_id']);
    $conditions[] = "cc.category_id = '$category_id'";
}

// Check if search query is provided
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($con, $_GET['search']);
    $conditions[] = "(cc.phrase LIKE '%$search%' OR cc.example LIKE '%$search%')";
}

// If there are conditions, add them to the query
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Pagination setup
$results_per_page = 10; // Number of results per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $results_per_page;

// Add LIMIT and OFFSET to the query
$query .= " LIMIT $results_per_page OFFSET $offset";

// Execute query
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Display data in table rows or show message if no results
echo "<div class='table-wrapper'>";  // Start the div wrapper
echo "<table>";
echo "<tr>
        <th>ID</th>
        <th>Category</th>
        <th>Phrase</th>
        <th>Example</th>
        <th>Actions</th>
      </tr>";

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['category']}</td>
                <td>{$row['phrase']}</td>
                <td>{$row['example']}</td>
                <td class='actions'>
                    <a href='update_common_conversation.php?id={$row['id']}'><i class='fas fa-edit'></i> Edit</a>
                    <a href='delete_common_conversation.php?id={$row['id']}' onclick='return confirm(\"Are you sure?\");'><i class='fas fa-trash-alt'></i> Delete</a>
                </td>
              </tr>";
    }
    echo "</table>";
    echo "</div>";  // Close the div wrapper

    // Get total number of records for pagination
    $total_query = "SELECT COUNT(*) as total FROM common_conversations cc";
    if (count($conditions) > 0) {
        $total_query .= " WHERE " . implode(" AND ", $conditions);
    }

    $total_result = mysqli_query($con, $total_query);
    $total_row = mysqli_fetch_assoc($total_result);
    $total_records = $total_row['total'];
    $total_pages = ceil($total_records / $results_per_page);

    // Display pagination controls
    echo "<div class='pagination-controls'>";
    for ($i = 1; $i <= $total_pages; $i++) {
        $active_class = ($i == $page) ? 'active' : '';
        echo "<a href='?page=$i" . (isset($_GET['category_id']) ? "&category_id=" . urlencode($_GET['category_id']) : '') . (isset($_GET['search']) ? "&search=" . urlencode($_GET['search']) : '') . "' class='$active_class'>$i</a>";
    }
    echo "</div>";
} else {
    echo "<tr><td colspan='5' class='no-results'>No results found.</td></tr>";
}


        // Close database connection
        mysqli_close($con);
        ?>
</div>
<footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

    </section>
</body>
</html>
