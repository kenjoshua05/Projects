<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

// Fetch the user ID from the query parameter
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch user details
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = mysqli_query($con, $user_query);
$user = mysqli_fetch_assoc($user_result);

// Fetch user's quiz results
$quiz_query = "SELECT uqr.*, q.title, c.name AS category_name, 
               (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) AS total_questions 
               FROM user_quiz_results uqr 
               JOIN quizzes q ON uqr.quiz_id = q.id 
               JOIN categories c ON q.category_id = c.id 
               WHERE uqr.user_id = $user_id";
$quiz_result = mysqli_query($con, $quiz_query);

if (!$user_result || !$quiz_result) {
    die("Query failed: " . mysqli_error($con));
}

// Prepare data for the chart
$chart_data_query = "SELECT q.title AS quiz_title, 
                             DATE(uqr.taken_at) AS quiz_date, 
                             uqr.score, 
                             (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) AS total_questions,
                             (SELECT COUNT(*) FROM user_quiz_answers uqa 
                              JOIN choices c ON uqa.selected_choice_id = c.id 
                              WHERE uqa.question_id IN (SELECT id FROM questions WHERE quiz_id = q.id) 
                                AND uqa.user_id = uqr.user_id 
                                AND c.is_correct = 0 
                                AND uqa.attempt_id = uqr.attempt_id) AS wrong_answers
                     FROM user_quiz_results uqr 
                     JOIN quizzes q ON uqr.quiz_id = q.id 
                     WHERE uqr.user_id = $user_id 
                     ORDER BY uqr.taken_at";

$chart_data_result = mysqli_query($con, $chart_data_query);
$chart_data = [];
while ($row = mysqli_fetch_assoc($chart_data_result)) {
    $chart_data[] = $row;
}
$chart_data_json = json_encode($chart_data);

// Prepare data for the pie chart
$quiz_count_query = "SELECT q.title AS quiz_title, COUNT(*) AS quiz_count 
                     FROM user_quiz_results uqr 
                     JOIN quizzes q ON uqr.quiz_id = q.id 
                     WHERE uqr.user_id = $user_id 
                     GROUP BY q.title";
$quiz_count_result = mysqli_query($con, $quiz_count_query);
$quiz_count_data = [];
while ($row = mysqli_fetch_assoc($quiz_count_result)) {
    $quiz_count_data[] = $row;
}
$quiz_count_data_json = json_encode($quiz_count_data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .no-results {
            text-align: center;
            color: red;
            font-style: italic;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .back-link:hover {
            color: #0056b3;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .chart-container {
            margin-top: 30px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .chart-wrapper {
            display: flex;
            justify-content: space-between;
        }

        .chart-line {
            width: 70%;
        }

        .chart-pie {
            width: 30%;
        }

        .admin-footer {
            margin-top: 40px;
        }

        .admin-footer p {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>User Details</h1>
    <div class="user-details">
        <?php if ($user): ?>
            <p><span>User ID:</span> <?php echo htmlspecialchars($user['id']); ?></p>
            <p><span>Username:</span> <?php echo htmlspecialchars($user['username']); ?></p>
            <p><span>Email:</span> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><span>Total Quizzes Taken:</span> <?php echo htmlspecialchars($user['total_quizzes_taken']); ?></p>
            <p><span>Total Correct Answers:</span> <?php echo htmlspecialchars($user['total_correct_answers']); ?></p>
        <?php else: ?>
            <p>No details found for this user.</p>
        <?php endif; ?>
    </div>

    <h2>Quiz Results</h2>
    <table>
        <tr>
            <th>Quiz ID</th>
            <th>Quiz Title</th>
            <th>Category</th>
            <th>Score</th>
            <th>Taken At</th>
            <th>Actions</th>
        </tr>
        <?php if (mysqli_num_rows($quiz_result) === 0): ?>
            <tr>
                <td colspan="6" class="no-results">No quiz results found for this user.</td>
            </tr>
        <?php else: ?>
            <?php while ($row = mysqli_fetch_assoc($quiz_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['quiz_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['score'] . ' out of ' . $row['total_questions']); ?></td>
                    <td><?php echo htmlspecialchars($row['taken_at']); ?></td>
                    <td class="actions">
                        <a href="view_answers2.php?result_id=<?php echo $row['id']; ?>"><i class="fas fa-eye"></i> View Answers</a>
                        <a href="delete_quiz_result2.php?id=<?php echo $row['id']; ?>&user_id=<?php echo $row['user_id']; ?>" onclick="return confirm('Are you sure you want to delete this result?');">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php endif; ?>
    </table>

    <h2>Quiz Score Trends</h2>

    <div class="chart-wrapper">
        <div class="chart-container chart-line">
            <canvas id="scoreTrendChart"></canvas>
        </div>
        <div class="chart-container chart-pie">
            <canvas id="quizFrequencyChart"></canvas>
        </div>
    </div>

    <a href="manage_users.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to User List</a>

    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
    const scoreCtx = document.getElementById('scoreTrendChart').getContext('2d');
    const frequencyCtx = document.getElementById('quizFrequencyChart').getContext('2d');
    const chartData = <?php echo $chart_data_json; ?>;
    const quizCountData = <?php echo $quiz_count_data_json; ?>;

    const scoreLabels = chartData.map(data => `${data.quiz_date} (${data.quiz_title})`);
    const scoreData = chartData.map(data => data.score);
    const totalQuestionsData = chartData.map(data => data.total_questions);
    const wrongAnswersData = chartData.map(data => data.wrong_answers);

    new Chart(scoreCtx, {
        type: 'line',
        data: {
            labels: scoreLabels,
            datasets: [
                {
                    label: 'Score',
                    data: scoreData,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Total Questions',
                    data: totalQuestionsData,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Wrong Answers',
                    data: wrongAnswersData,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const frequencyLabels = quizCountData.map(data => data.quiz_title);
    const frequencyData = quizCountData.map(data => data.quiz_count);

    // Function to generate random colors
    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    new Chart(frequencyCtx, {
        type: 'pie',
        data: {
            labels: frequencyLabels,
            datasets: [{
                label: 'Quiz Frequency',
                data: frequencyData,
                backgroundColor: frequencyLabels.map(() => getRandomColor()), // Apply random colors
                borderColor: frequencyLabels.map(() => '#fff'),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                }
            }
        }
    });
});

    </script>
</body>
</html>
