<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

// Get the result ID from the URL
$result_id = isset($_GET['result_id']) ? (int)$_GET['result_id'] : 0;

// Fetch the result details including attempt_id
$result_query = "
    SELECT uqr.*, u.username, q.title 
    FROM user_quiz_results uqr 
    JOIN users u ON uqr.user_id = u.id 
    JOIN quizzes q ON uqr.quiz_id = q.id 
    WHERE uqr.id = $result_id
";
$result_details = mysqli_query($con, $result_query);
if (!$result_details) {
    die("Query failed: " . mysqli_error($con));
}
$result_row = mysqli_fetch_assoc($result_details);

// Fetch questions and choices with attempt_id
$questions_query = "
    SELECT q.id AS question_id, q.question_text, c.id AS choice_id, c.choice_text, c.is_correct, 
           COALESCE(ua.selected_choice_id, 0) AS user_choice_id
    FROM questions q
    JOIN choices c ON q.id = c.question_id
    LEFT JOIN user_quiz_answers ua 
        ON ua.question_id = q.id 
        AND ua.user_id = {$result_row['user_id']}
        AND ua.attempt_id = {$result_row['attempt_id']}
    WHERE q.quiz_id = {$result_row['quiz_id']}
    ORDER BY q.id, c.id
";
$questions_result = mysqli_query($con, $questions_query);
if (!$questions_result) {
    die("Query failed: " . mysqli_error($con));
}

// Organize questions and choices
$questions = [];
while ($row = mysqli_fetch_assoc($questions_result)) {
    $question_id = $row['question_id'];
    if (!isset($questions[$question_id])) {
        $questions[$question_id] = [
            'question_text' => $row['question_text'],
            'choices' => [],
            'user_choice_id' => 0
        ];
    }
    // Collect choices
    $questions[$question_id]['choices'][] = [
        'choice_id' => $row['choice_id'],
        'choice_text' => $row['choice_text'],
        'is_correct' => $row['is_correct']
    ];
    if ($row['user_choice_id']) {
        $questions[$question_id]['user_choice_id'] = $row['user_choice_id'];
    }
}

db_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Answers</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .result-info {
            margin-bottom: 20px;
        }

        .result-info p {
            margin: 0;
            padding: 5px 0;
            font-size: 16px;
            border-bottom: 1px solid #ddd;
        }

        .question {
            font-weight: 600;
            margin-top: 20px;
            font-size: 18px;
        }

        .choice {
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
        }

        .correct {
            background-color: #d4edda; /* Light green for correct answers */
            color: #155724;
        }

        .incorrect {
            background-color: #f8d7da; /* Light red for incorrect answers */
            color: #721c24;
        }

        a.back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            padding: 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        a.back-link:hover {
            background-color: #007bff;
            color: #fff;
        }
        .admin-footer{
            margin-top:40px;
        }

        .admin-footer p{
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>View Answers for Quiz: <?php echo htmlspecialchars($result_row['title']); ?></h1>
        <div class="result-info">
            <p>User: <?php echo htmlspecialchars($result_row['username']); ?></p>
            <p>Score: <?php echo htmlspecialchars($result_row['score']); ?></p>
            <p>Taken At: <?php echo htmlspecialchars($result_row['taken_at']); ?></p>
        </div>

        <?php foreach ($questions as $question_id => $question_data) : ?>
            <div class="question"><?php echo htmlspecialchars($question_data['question_text']); ?></div>
            <?php 
                $user_choice_id = $question_data['user_choice_id'];
                $choices = $question_data['choices'];

                foreach ($choices as $choice) :
                    $class = '';
                    if ($choice['is_correct'] && $choice['choice_id'] == $user_choice_id) {
                        $class = 'correct'; // User selected the correct choice
                    } elseif ($choice['choice_id'] == $user_choice_id) {
                        $class = 'incorrect'; // User selected an incorrect choice
                    } elseif ($choice['is_correct']) {
                        $class = 'correct'; // Correct choice but not selected by user
                    }
            ?>
                <div class="choice <?php echo $class; ?>">
                    <?php echo htmlspecialchars($choice['choice_text']); ?>
                </div>
            <?php endforeach; ?>
        <?php endforeach; ?>

        <a href="admin_quiz_results.php" class="back-link">Back to Results</a>
    </div>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

</body>
</html>
