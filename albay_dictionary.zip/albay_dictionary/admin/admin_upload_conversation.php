<?php
require_once 'functions.php';
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];
$categories = fetch_categories(); // Fetch categories using the new function
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Upload Common Conversations</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
           body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .admin-section {
            max-width: 60%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        select, input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .admin-footer{
            text-align: center;
        }
    </style>
</head>
<body>
    <section class="admin-section">
        <h1>Admin Panel - Upload Common Conversations</h1>
        <form action="admin_process_conversation.php" method="post">
            <div>
                <label for="category_id">Category:</label>
                <select name="category_id" id="category_id" required>
                    <?php if ($categories): ?>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= htmlspecialchars($category['id']); ?>">
                                <?= htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="">No categories available</option>
                    <?php endif; ?>
                </select>
            </div>
            <div>
                <label for="phrase">Phrase:</label>
                <input type="text" name="phrase" id="phrase" required>
            </div>
            <div>
                <label for="example">Example:</label>
                <textarea name="example" id="example" required></textarea>
            </div>
            <div>
                <input type="submit" value="Upload">
            </div>
        </form>
    </section>
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
    </footer>
</body>
</html>
