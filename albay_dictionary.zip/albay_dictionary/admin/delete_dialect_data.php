<?php
// Start the session
session_start();

// Include the functions.php file for reusable functions
require_once 'functions.php';

// Check if the `id` is set in the URL
if (!isset($_GET['id'])) {
    header('Location: display_dialect_data.php');
    exit;
}

// Establish database connection using reusable function
$con = db_connect();

// Sanitize the `id` parameter from the URL
$id = mysqli_real_escape_string($con, $_GET['id']);

// Delete the data for the given id
$query = "DELETE FROM dialect_data WHERE id='$id'";
if (mysqli_query($con, $query)) {
    $_SESSION['success_message'] = "Data deleted successfully.";
} else {
    $_SESSION['error_message'] = "Failed to delete data: " . mysqli_error($con);
}

// Close database connection
db_close($con);

// Redirect back to the display page
header('Location: display_dialect_data.php');
exit;
?>
