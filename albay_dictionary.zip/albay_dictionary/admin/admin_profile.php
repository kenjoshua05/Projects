<?php
// Start session and include database connection
session_start();
require_once 'functions.php';

// Ensure the user is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

// Retrieve admin information from the session
$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

// Handle form submission for updating profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the update profile button was clicked
    if (isset($_POST['update_profile'])) {
        $username = mysqli_real_escape_string($con, $_POST['username']);
        
        // Update admin details
        $update_query = "UPDATE admins SET username = '$username' WHERE id = " . $admin['id'];
        $update_result = mysqli_query($con, $update_query);
        
        if ($update_result) {
            // Update the session data
            $_SESSION['ADMIN']['username'] = $username;
            // Redirect to the same page to avoid re-submission
            header("Location: admin_profile.php");
            exit;
        } else {
            die("Error updating admin: " . mysqli_error($con));
        }
    }

    // Handle password update separately
    if (isset($_POST['change_password'])) {
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];

        if (empty($password)) {
            $error = "New password cannot be empty.";
        } elseif ($password !== $password_confirm) {
            $error = "Passwords do not match.";
        } else {
            // Hash the new password
            $password_hash = password_hash($password, PASSWORD_BCRYPT);

            // Update admin password
            $update_query = "UPDATE admins SET password_hash = '$password_hash' WHERE id = " . $admin['id'];
            $update_result = mysqli_query($con, $update_query);
            
            if ($update_result) {
                // Password updated successfully
                // Redirect to the same page to avoid re-submission
                header("Location: admin_profile.php");
                exit;
            } else {
                die("Error updating password: " . mysqli_error($con));
            }
        }
    }

    // Handle profile image upload only if confirmed
    if (isset($_POST['confirm_image_upload']) && isset($_FILES['profile_image'])) {
        $fileError = $_FILES['profile_image']['error'];
        
        // Check for file upload errors
        if ($fileError === UPLOAD_ERR_OK) {
            $target_dir = "profile_pics/";
            $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
            $uploadOk = 1;

            // Check file size
            if ($_FILES["profile_image"]["size"] > 500000) {
                $uploadOk = 0;
                $error_message = "Sorry, your file is too large.";
            }

            // Allow certain file formats
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                $uploadOk = 0;
                $error_message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            }

            // Check if everything is ok to upload
            if ($uploadOk) {
                if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
                    // Update the database with the new image path
                    $update_query = "UPDATE admins SET profile_image = '$target_file' WHERE id = " . $admin['id'];
                    $update_result = mysqli_query($con, $update_query);
                    
                    if ($update_result) {
                        // Update session data to reflect the new image
                        $_SESSION['ADMIN']['profile_image'] = $target_file;
                        // Redirect to the same page to avoid re-submission
                        header("Location: admin_profile.php");
                        exit;
                    } else {
                        $error_message = "Error updating profile image: " . mysqli_error($con);
                    }
                } else {
                    $error_message = "Sorry, there was an error uploading your file.";
                }
            } else {
                $error_message = isset($error_message) ? $error_message : "File upload failed.";
            }
        } else {
            $error_message = "File upload error code: " . $fileError;
        }
    }
}

// Close connection before displaying the form
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin Profile</title>
    <style>

body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #ddd;
        }

        .profile-pic img {
            width: 100%;
            height: auto;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 15px;
            font-size: 16px;
            width: 100%;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error {
            color: #dc3545;
            margin-top: 10px;
            font-size: 14px;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
            font-size: 16px;
        }

        a:hover {
            text-decoration: underline;
        }
        .profile-pic {
            cursor: pointer; /* Indicate that the image is clickable */
            margin-bottom: 20px;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Profile</h1>
        <div class="profile-pic" onclick="document.getElementById('profileImageInput').click();">
            <img src="<?php echo htmlspecialchars($admin['profile_image'] ?? 'profile_pics/default_profile.jpg'); ?>" alt="Profile Picture" id="profileImage">
            <form id="imageUploadForm" method="post" enctype="multipart/form-data" style="display: none;">
                <input type="file" name="profile_image" id="profileImageInput" accept="image/*" onchange="confirmUpload();">
                <input type="hidden" name="confirm_image_upload" value="1"> <!-- Hidden field to indicate confirmation -->
            </form>
        </div>
        <form method="post">
            <h2>Update Profile</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
        </form>

        <form method="post">
            <h2>Change Password</h2>
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password">
            
            <label for="password_confirm">Confirm Password:</label>
            <input type="password" id="password_confirm" name="password_confirm">
            
            <button type="submit" name="change_password">Change Password</button>
            <?php if (isset($error)) : ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </form>
        
        <!-- Display error messages -->
        <?php if (isset($error_message)) : ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>

    <script>
        // Confirm before uploading the selected image
        function confirmUpload() {
            const fileInput = document.getElementById('profileImageInput');
            const file = fileInput.files[0];
            if (file) {
                const confirmation = confirm("Are you sure you want to upload this image: " + file.name + "?");
                if (confirmation) {
                    // If confirmed, submit the upload form
                    document.getElementById('imageUploadForm').submit();
                } else {
                    // If canceled, clear the input
                    fileInput.value = '';
                }
            }
        }
    </script>
</body>
</html>
