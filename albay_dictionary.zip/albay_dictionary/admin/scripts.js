document.addEventListener('DOMContentLoaded', function () {
    let questionIndex = 1;

    // Function to add a new question
    function addQuestion() {
        questionIndex++;
        const newQuestion = document.createElement('div');
        newQuestion.className = 'question';
        newQuestion.id = `question_${questionIndex}`;
        newQuestion.innerHTML = `
            <label for="question_text_${questionIndex}">Question ${questionIndex}:</label>
            <input type="text" id="question_text_${questionIndex}" name="questions[${questionIndex}][text]" required>
            <div class="choices">
                <label>Choices:</label>
                ${generateChoices(questionIndex, 4)}
            </div>
            <button type="button" onclick="addChoice(${questionIndex})">Add Choice</button>
        `;
        document.getElementById('questions_container').appendChild(newQuestion);
    }

    // Function to generate choices for a given question
    function generateChoices(questionId, count) {
        let choicesHtml = '';
        for (let i = 0; i < count; i++) {
            choicesHtml += `
                <div class="choice-container">
                    <input type="text" name="questions[${questionId}][choices][]" required>
                    <input type="radio" name="questions[${questionId}][correct_choice]" value="${i}"> Correct
                </div>
            `;
        }
        return choicesHtml;
    }

    // Function to add a new choice to a specific question
    function addChoice(questionId) {
        const questionElement = document.getElementById(`question_${questionId}`);
        const choicesContainer = questionElement.querySelector('.choices');
        const choiceCount = choicesContainer.querySelectorAll('.choice-container').length;

        if (choiceCount < 10) { // Limit to 10 choices for example
            const newChoiceIndex = choiceCount; // Zero-based index

            const newChoice = document.createElement('div');
            newChoice.className = 'choice-container';
            newChoice.innerHTML = `
                <input type="text" name="questions[${questionId}][choices][]" required>
                <input type="radio" name="questions[${questionId}][correct_choice]" value="${newChoiceIndex}"> Correct
            `;
            choicesContainer.appendChild(newChoice);
        } else {
            alert('Maximum of 10 choices allowed');
        }
    }

    // Add event listener to the button for adding new questions
    document.getElementById('add_question').addEventListener('click', addQuestion);

    // Make the addChoice function available globally
    window.addChoice = addChoice;
});
