<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Common Conversation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .admin-section {
            max-width: 60%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        select, input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .admin-footer{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="admin-section">
        <h1>Update Common Conversation</h1>
        <?php
        // Start the session
        session_start();

        // Include database connection parameters and functions
        require_once 'functions.php';

        if (!isset($_SESSION['ADMIN'])) {
            header("Location:admin_login.php");
            exit;
        }
        
        $admin = $_SESSION['ADMIN'];

        // Establish database connection
        $con = db_connect();
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch the data for the given id
        if (!isset($_GET['id'])) {
            header('Location: display_common_conversations.php');
            exit;
        }

        $id = mysqli_real_escape_string($con, $_GET['id']);

        $query = "SELECT * FROM common_conversations WHERE id='$id'";
        $result = mysqli_query($con, $query);

        if (!$result) {
            die("Query failed: " . mysqli_error($con));
        }

        $data = mysqli_fetch_assoc($result);

        if (!$data) {
            header('Location: display_common_conversations.php');
            exit;
        }

        // Fetch all categories from the categories table
        $query_categories = "SELECT id, name FROM categories";
        $result_categories = mysqli_query($con, $query_categories);

        if (!$result_categories) {
            die("Query failed: " . mysqli_error($con));
        }

        // Check if the form is submitted for updating
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve and sanitize form data
            $id = mysqli_real_escape_string($con, $_POST['id']);
            $category_id = mysqli_real_escape_string($con, $_POST['category_id']);
            $phrase = mysqli_real_escape_string($con, $_POST['phrase']);
            $example = mysqli_real_escape_string($con, $_POST['example']);

            // Update the data in the database
            $query = "UPDATE common_conversations SET 
                category_id='$category_id',
                phrase='$phrase',
                example='$example'
                WHERE id='$id'";

            $result = mysqli_query($con, $query);

            if ($result) {
                $_SESSION['success_message'] = "Common conversation updated successfully.";
            } else {
                $_SESSION['error_message'] = "Failed to update common conversation.";
            }

            // Redirect back to display page
            header('Location: display_common_conversations.php');
            exit;
        }
        ?>
        <form action="update_common_conversation.php?id=<?php echo urlencode($id); ?>" method="post">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($data['id']); ?>">
            <div>
                <label for="category_id">Category:</label>
                <select name="category_id" id="category_id">
                    <?php while ($category = mysqli_fetch_assoc($result_categories)) : ?>
                        <option value="<?php echo $category['id']; ?>" <?php if ($category['id'] == $data['category_id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label for="phrase">Phrase:</label>
                <input type="text" name="phrase" id="phrase" value="<?php echo htmlspecialchars($data['phrase']); ?>">
            </div>
            <div>
                <label for="example">Example:</label>
                <textarea name="example" id="example"><?php echo htmlspecialchars($data['example']); ?></textarea>
            </div>
            <div>
                <input type="submit" value="Update">
            </div>
        </form>
    </div>
    <?php mysqli_close($con); ?>
    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
