<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Dialect Data</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <h1>Upload Dialect Data</h1>
    <?php
    session_start();

    if (!isset($_SESSION['ADMIN'])) {
        header("Location:admin_login.php");
        exit;
    }
    
    $admin = $_SESSION['ADMIN'];
    
    if (isset($_SESSION['success_message'])) {
        echo '<p style="color: green;">' . $_SESSION['success_message'] . '</p>';
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo '<p style="color: red;">' . $_SESSION['error_message'] . '</p>';
        unset($_SESSION['error_message']);
    }
    ?>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="audio">Upload Audio File:</label>
            <input type="file" name="audio" id="audio" accept="audio/*" required>
        </div>
        <div>
            <label for="dialect">Dialect:</label>
            <input type="text" name="dialect" id="dialect" required>
        </div>
        <div>
            <label for="word">Word:</label>
            <input type="text" name="word" id="word" required>
        </div>
        <div>
            <label for="antonym">Antonym:</label>
            <input type="text" name="antonym" id="antonym">
        </div>
        <div>
            <label for="pronunciation">Pronunciation Guide:</label>
            <textarea name="pronunciation" id="pronunciation" required></textarea>
        </div>
        <div>
            <label for="example1">Example 1 (Dialect):</label>
            <input type="text" name="example1" id="example1" required>
        </div>
        <div>
            <label for="example1_tagalog">Example 1 (Tagalog):</label>
            <input type="text" name="example1_tagalog" id="example1_tagalog" required>
        </div>
        <div>
            <label for="example1_english">Example 1 (English):</label>
            <input type="text" name="example1_english" id="example1_english" required>
        </div>
        <div>
            <label for="example2">Example 2 (Dialect):</label>
            <input type="text" name="example2" id="example2">
        </div>
        <div>
            <label for="example2_tagalog">Example 2 (Tagalog):</label>
            <input type="text" name="example2_tagalog" id="example2_tagalog">
        </div>
        <div>
            <label for="example2_english">Example 2 (English):</label>
            <input type="text" name="example2_english" id="example2_english">
        </div>
        <div>
            <label for="tagalog_meaning">Tagalog Meaning:</label>
            <textarea name="tagalog_meaning" id="tagalog_meaning" required></textarea>
        </div>
        <div>
            <label for="english_meaning">English Meaning:</label>
            <textarea name="english_meaning" id="english_meaning" required></textarea>
        </div>
        <input type="submit" name="submit" value="Upload">
    </form>
</body>
</html>
