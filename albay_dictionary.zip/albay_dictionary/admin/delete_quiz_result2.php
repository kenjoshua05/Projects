<?php
require('functions.php');

// Check if ID and user_id are set
if (isset($_GET['id']) && isset($_GET['user_id'])) {
    $result_id = (int)$_GET['id'];
    $user_id = (int)$_GET['user_id']; // Get the user ID

    // Function to delete a result by ID
    function delete_result($result_id) {
        $con = db_connect(); // Establish database connection
        $query = "DELETE FROM user_quiz_results WHERE id = $result_id";
        $result = mysqli_query($con, $query);
        db_close($con); // Close database connection

        return $result;
    }

    // Perform delete operation
    if (delete_result($result_id)) {
        header("Location: view_user.php?id=$user_id"); // Redirect back to the specific user
        exit;
    } else {
        echo "Error deleting result.";
    }
} else {
    echo "No result ID or user ID specified.";
}
?>
