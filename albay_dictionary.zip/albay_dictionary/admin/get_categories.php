<?php
// Start the session
session_start();

// Include the functions.php file for reusable functions
require_once 'functions.php';

// Check if the admin is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection using reusable function
$con = db_connect();

// Fetch categories from the database
$query = "SELECT id, name FROM categories";
$result = mysqli_query($con, $query);

$options = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['id'];
        $name = htmlspecialchars($row['name']);
        $options[] = ["id" => $id, "name" => $name];
    }
} else {
    $options[] = ["id" => "", "name" => "No categories found"];
}

// Close database connection
db_close($con);

// Output options as JSON
header('Content-Type: application/json');
echo json_encode($options);
