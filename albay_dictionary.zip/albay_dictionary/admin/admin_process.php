<?php
session_start();
require_once 'functions.php'; // Include functions for database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $con = db_connect(); // Use the reusable db_connect function

    // Sanitize and assign form fields with default values
    $category_id = !empty($_POST['category_id']) ? mysqli_real_escape_string($con, trim($_POST['category_id'])) : '1';
    $word = !empty($_POST['word']) ? mysqli_real_escape_string($con, trim($_POST['word'])) : 'N/A';
    $pronunciation = !empty($_POST['pronunciation']) ? mysqli_real_escape_string($con, trim($_POST['pronunciation'])) : 'No pronunciation provided';
    $example1 = !empty($_POST['example1']) ? mysqli_real_escape_string($con, trim($_POST['example1'])) : 'No example';
    $example1_tagalog = !empty($_POST['example1_tagalog']) ? mysqli_real_escape_string($con, trim($_POST['example1_tagalog'])) : 'No example in Tagalog';
    $example1_english = !empty($_POST['example1_english']) ? mysqli_real_escape_string($con, trim($_POST['example1_english'])) : 'No example in English';
    $example2 = !empty($_POST['example2']) ? mysqli_real_escape_string($con, trim($_POST['example2'])) : 'No example';
    $example2_tagalog = !empty($_POST['example2_tagalog']) ? mysqli_real_escape_string($con, trim($_POST['example2_tagalog'])) : 'No example in Tagalog';
    $example2_english = !empty($_POST['example2_english']) ? mysqli_real_escape_string($con, trim($_POST['example2_english'])) : 'No example in English';
    $tagalog_meaning = !empty($_POST['tagalog_meaning']) ? mysqli_real_escape_string($con, trim($_POST['tagalog_meaning'])) : 'No meaning in Tagalog';
    $english_meaning = !empty($_POST['english_meaning']) ? mysqli_real_escape_string($con, trim($_POST['english_meaning'])) : 'No meaning in English';

    // File upload handling
    $target_dir = "uploads/";
    $default_audio = "nodata.wav";
    $audio_file_path = $target_dir . $default_audio; // Default file path

    if (!empty($_FILES['audio_file']['name'])) {
        $file_type = mime_content_type($_FILES['audio_file']['tmp_name']);
        
        // Validate audio file type (basic check for common types)
        if (in_array($file_type, ['audio/mpeg', 'audio/wav', 'audio/ogg'])) {
            $target_file = $target_dir . basename($_FILES['audio_file']['name']);
            
            if (move_uploaded_file($_FILES['audio_file']['tmp_name'], $target_file)) {
                $audio_file_path = $target_file;
            } else {
                $_SESSION['error_message'] = "Failed to upload audio file.";
            }
        } else {
            $_SESSION['error_message'] = "Invalid audio file type.";
        }
    }

    // Insert data into the database
    $query = "INSERT INTO dialect_data (audio_file, category_id, word, pronunciation, example1, example1_tagalog, example1_english, example2, example2_tagalog, example2_english, tagalog_meaning, english_meaning)
              VALUES ('$audio_file_path', '$category_id', '$word', '$pronunciation', '$example1', '$example1_tagalog', '$example1_english', '$example2', '$example2_tagalog', '$example2_english', '$tagalog_meaning', '$english_meaning')";

    if (mysqli_query($con, $query)) {
        $_SESSION['success_message'] = "Dialect data uploaded successfully.";
    } else {
        $_SESSION['error_message'] = "Failed to upload dialect data: " . mysqli_error($con);
    }

    db_close($con); // Close the database connection
}

// Redirect back to the upload page or display dialect data page
header('Location: display_dialect_data.php');
exit;
?>
