<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

// Establish database connection
$con = db_connect();

// Initialize variables for sorting and searching
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'user_id'; // Default sort by user_id
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC'; // Default order ASC
$search_user_id = isset($_GET['search_user_id']) ? $_GET['search_user_id'] : ''; // Search user ID
$search_username = isset($_GET['search_username']) ? $_GET['search_username'] : ''; // Search username
$search_quiz_id = isset($_GET['search_quiz_id']) ? $_GET['search_quiz_id'] : ''; // Search quiz ID

// Initialize query for user quiz results
$query = "SELECT uqr.*, u.username, q.title, c.name AS category_name, 
          (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) AS total_questions 
          FROM user_quiz_results uqr 
          JOIN users u ON uqr.user_id = u.id 
          JOIN quizzes q ON uqr.quiz_id = q.id 
          JOIN categories c ON q.category_id = c.id";

// Add search filters if search terms are provided
$conditions = [];
if (!empty($search_user_id)) {
    $search_user_id = mysqli_real_escape_string($con, $search_user_id);
    $conditions[] = "uqr.user_id = '$search_user_id'";
}
if (!empty($search_username)) {
    $search_username = mysqli_real_escape_string($con, $search_username);
    $conditions[] = "u.username LIKE '%$search_username%'";
}
if (!empty($search_quiz_id)) {
    $search_quiz_id = mysqli_real_escape_string($con, $search_quiz_id);
    $conditions[] = "uqr.quiz_id = '$search_quiz_id'";
}

// Apply search conditions to the query
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Count total records for pagination
$count_query = "SELECT COUNT(*) AS total FROM ($query) AS count_table";
$count_result = mysqli_query($con, $count_query);
$count_row = mysqli_fetch_assoc($count_result);
$total_records = $count_row['total'];

// Pagination setup
$limit = 10; // Records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Update query with LIMIT and OFFSET for pagination
$query .= " ORDER BY $sort $order LIMIT $limit OFFSET $offset";

// Execute query
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Calculate total pages
$total_pages = ceil($total_records / $limit);

// Check if there are no results
$num_rows = mysqli_num_rows($result);

// Fetch data for the chart
$chart_data_query = "SELECT q.title, COUNT(*) AS attempts, AVG(uqr.score) AS average_score
                     FROM user_quiz_results uqr
                     JOIN quizzes q ON uqr.quiz_id = q.id
                     GROUP BY q.title";
$chart_data_result = mysqli_query($con, $chart_data_query);

$chart_data = [];
while ($row = mysqli_fetch_assoc($chart_data_result)) {
    $chart_data[] = $row;
}

$chart_data_json = json_encode($chart_data);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Quiz Results</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Add your existing CSS styles here */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .search-controls, .sorting-controls {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .search-controls label, .sorting-controls label {
            margin-right: 10px;
            font-weight: 500;
        }

        .search-controls input[type="text"], .sorting-controls select {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .search-controls input[type="submit"], .sorting-controls input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .search-controls input[type="submit"]:hover, .sorting-controls input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .no-results {
            text-align: center;
            color: red;
            font-style: italic;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .pagination-controls {
            margin-top: 20px;
            text-align: center;
        }

        .pagination-controls a {
            display: inline-block;
            margin: 0 5px;
            padding: 10px 15px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .pagination-controls a:hover {
            background-color: #0056b3;
        }

        .pagination-controls a.active {
            background-color: #0056b3;
            pointer-events: none;
        }

        .actions i {
            margin-right: 5px; /* Adjust the value as needed for spacing */
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .dashboard-button-fixed {
            position: fixed;
            top: 10%;
            right: 20px;
            transform: translateY(-50%);
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #6495ed;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
        }

        .dashboard-button-fixed i {
            margin-right: 10px;
            font-size: 18px;
        }

        .dashboard-button-fixed:hover {
            background-color: #365eaa;
            transform: translateY(-50%) scale(1.05);
            text-decoration: none;
        }

    </style>
</head>
<body>
    <h1>User Quiz Results</h1>

    <div class="search-controls">
        <form method="GET" action="">
            <label for="search_user_id">User ID:</label>
            <input type="text" name="search_user_id" id="search_user_id" value="<?php echo htmlspecialchars($search_user_id); ?>">
            <label for="search_username">Username:</label>
            <input type="text" name="search_username" id="search_username" value="<?php echo htmlspecialchars($search_username); ?>">
            <label for="search_quiz_id">Quiz ID:</label>
            <input type="text" name="search_quiz_id" id="search_quiz_id" value="<?php echo htmlspecialchars($search_quiz_id); ?>">
            <input type="submit" value="Search">
        </form>
    </div>

    <div class="sorting-controls">
        <form method="GET" action="">
            <input type="hidden" name="search_user_id" value="<?php echo htmlspecialchars($search_user_id); ?>">
            <input type="hidden" name="search_username" value="<?php echo htmlspecialchars($search_username); ?>">
            <input type="hidden" name="search_quiz_id" value="<?php echo htmlspecialchars($search_quiz_id); ?>">
            <label for="sort">Sort by:</label>
            <select name="sort" id="sort">
                <option value="user_id" <?php if ($sort === 'user_id') echo 'selected'; ?>>User ID</option>
                <option value="username" <?php if ($sort === 'username') echo 'selected'; ?>>Username</option>
                <option value="quiz_id" <?php if ($sort === 'quiz_id') echo 'selected'; ?>>Quiz ID</option>
                <option value="score" <?php if ($sort === 'score') echo 'selected'; ?>>Score</option>
                <option value="date_taken" <?php if ($sort === 'date_taken') echo 'selected'; ?>>Date Taken</option>
            </select>
            <select name="order" id="order">
                <option value="ASC" <?php if ($order === 'ASC') echo 'selected'; ?>>Ascending</option>
                <option value="DESC" <?php if ($order === 'DESC') echo 'selected'; ?>>Descending</option>
            </select>
            <input type="submit" value="Sort">
        </form>
    </div>

    <?php if ($num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Quiz ID</th>
                    <th>Quiz Title</th>
                    <th>Category</th>
                    <th>Score</th>
                    <th>Total Questions</th>
                    <th>Date Taken</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['quiz_id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['category_name']; ?></td>
                        <td><?php echo $row['score']; ?></td>
                        <td><?php echo $row['total_questions']; ?></td>
                        <td><?php echo htmlspecialchars($row['taken_at']); ?></td>
                        <td class="actions">
                        <a href="view_answers.php?result_id=<?php echo $row['id']; ?>">   <i class="fas fa-eye"></i>View Answers</a>
                        <a href="delete_quiz_result.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this result?');">  <i class="fas fa-trash-alt"></i>Delete</a>
                    </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="pagination-controls">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&sort=<?php echo $sort; ?>&order=<?php echo $order; ?>&search_user_id=<?php echo $search_user_id; ?>&search_username=<?php echo $search_username; ?>&search_quiz_id=<?php echo $search_quiz_id; ?>" class="<?php if ($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
    <?php else: ?>
        <p class="no-results">No results found.</p>
    <?php endif; ?>

    <!-- Add the chart canvas -->
    <h2>Quiz Performance Overview</h2>
    <canvas id="quizChart" width="400" height="200"></canvas>

    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Chart.js script to render the chart -->
    <script>
        // Parse the chart data from PHP
        var chartData = <?php echo $chart_data_json; ?>;
        
        // Prepare the data for Chart.js
        var labels = chartData.map(data => data.title);
        var attempts = chartData.map(data => data.attempts);
        var averageScores = chartData.map(data => data.average_score);

        // Create the chart
        var ctx = document.getElementById('quizChart').getContext('2d');
        var quizChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Attempts',
                    data: attempts,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }, {
                    label: 'Average Score',
                    data: averageScores,
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <a href="admin_dashboard.php" class="dashboard-button-fixed">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>
</body>
</html>

<?php
// Close the database connection
mysqli_close($con);
?>
