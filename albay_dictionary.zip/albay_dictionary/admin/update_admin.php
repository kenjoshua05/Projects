<?php
// Start session and include database connection
session_start();
require_once 'functions.php';

// Ensure the user is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

// Establish database connection
$con = db_connect();

// Check if an ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid admin ID.");
}

$admin_id = intval($_GET['id']);

// Fetch admin details
$query = "SELECT * FROM admins WHERE id = $admin_id";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

$admin = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    
    if (empty($username) || empty($password)) {
        $error = "Username and password cannot be empty.";
    } elseif ($password !== $password_confirm) {
        $error = "Passwords do not match.";
    } else {
        // Hash the new password
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        
        // Update admin details
        $update_query = "UPDATE admins SET username = '$username', password_hash = '$password_hash' WHERE id = $admin_id";
        $update_result = mysqli_query($con, $update_query);
        
        if ($update_result) {
            mysqli_close($con); // Close connection after update is successful
            header("Location: manage_admins.php");
            exit;
        } else {
            mysqli_close($con); // Ensure connection is closed even if there's an error
            die("Error updating admin: " . mysqli_error($con));
        }
    }
}

// Close connection before displaying the form
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin - Update Admin</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 15px;
            font-size: 16px;
            width: 100%;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error {
            color: #dc3545;
            margin-top: 10px;
            font-size: 14px;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
            font-size: 16px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Admin</h1>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
            
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" required>
            
            <label for="password_confirm">Confirm Password:</label>
            <input type="password" id="password_confirm" name="password_confirm" required>
            
            <button type="submit">Update</button>
            <?php if (isset($error)) : ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </form>
        <a href="manage_admins.php"><i class="fas fa-arrow-left"></i> Back to Admin List</a>
    </div>
</body>
</html>
