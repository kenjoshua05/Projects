<?php
require('config.inc.php');
require('functions.php');

// Check if category ID is provided
if (!isset($_GET['category_id'])) {
    die("Category ID not provided.");
}

// Sanitize category ID
$category_id = mysqli_real_escape_string($con, $_GET['category_id']);

// Fetch category name for display
$category_query = "SELECT name FROM categories WHERE id='$category_id'";
$category_result = mysqli_query($con, $category_query);
$category = mysqli_fetch_assoc($category_result);

// Fetch words from dialect_data table for the given category
$words_query = "SELECT id, word FROM dialect_data WHERE category_id='$category_id'";
$words_result = mysqli_query($con, $words_query);

// Fetch common conversations for the given category
$common_query = "SELECT id, phrase, example FROM common_conversations WHERE category_id='$category_id'";
$common_result = mysqli_query($con, $common_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category['name']); ?></title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        /* Advanced CSS for Modern Design */
        body {
            font-family: 'Arial', sans-serif;
            background: #f0f2f5;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .header, .footer {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .categname h1 {
            text-align: center;
            color: #007BFF;
            font-size: 2.5rem;
        }
        .search-container {
            text-align: center;
            margin: 20px 0;
        }
        .search-container input {
            width: 80%;
            padding: 10px;
            font-size: 1.2rem;
        }
        .word-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
        }
        .word-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .word-item a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }
        .word-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }
        .sorting-container {
            text-align: center;
            margin: 20px 0;
        }
        .sorting-link {
            display: inline-block;
            margin: 0 5px;
            padding: 10px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .sorting-link:hover {
            background: #0056b3;
        }
        .common {
            background: white;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .accordion {
            background: #007BFF;
            color: white;
            cursor: pointer;
            padding: 15px;
            width: 100%;
            text-align: left;
            border: none;
            outline: none;
            transition: background 0.3s;
            border-radius: 5px;
            margin-top: 10px;
        }
        .accordion:hover {
            background: #0056b3;
        }
        .panel {
            padding: 15px;
            display: none;
            background: white;
            border-top: 1px solid #ccc;
            border-radius: 0 0 5px 5px;
        }
        .panel p {
            margin: 0;
        }
        .mark-done {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .mark-done:hover {
            background: #218838;
        }
        .footer {
            margin-top: 20px;
        }
        .social-icon__link {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }
        .f-menu {
            list-style: none;
            padding: 0;
        }
        .f-menu__item {
            display: inline-block;
            margin: 0 10px;
        }
        .f-menu__link {
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <section class="class_1">
        <div class="header">
            <?php include('header.inc.php'); ?>
        </div>
        <div class="categname">
            <h1><?php echo htmlspecialchars($category['name']); ?></h1>
        </div>
        <div class="search-container">
            <input type="text" id="searchInput" onkeyup="searchWords()" placeholder="Search...">
        </div>
        <div class="container">
            <div class="word-grid" id="wordGrid">
                <?php while ($row = mysqli_fetch_assoc($words_result)) : ?>
                    <div class="word-item" data-letter="<?php echo strtoupper($row['word'][0]); ?>">
                        <a href="word.php?id=<?php echo $row['id']; ?>">
                            <?php echo htmlspecialchars($row['word']); ?>
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>
            <p id="noWordsMessage" style="display: none; color: red;">No words found starting with this letter.</p>
        </div>

        <h2 style="text-align: center; color: #007BFF; padding-bottom: 10px;">Sort By First Letter</h2>

        <div class="sorting-container">
            <!-- Sorting links -->
            <?php foreach (range('A', 'Z') as $letter) : ?>
                <a href="#" class="sorting-link" onclick="sortAlphabetically('<?php echo $letter; ?>')"><?php echo $letter; ?></a>
            <?php endforeach; ?>
        </div>

        <hr>

        <div class="common">
            <h1>Common Conversations</h1>
            <div class="example">
                <input type="text" id="myInput" onkeyup="searchExamples()" placeholder="Search for examples..." title="Type in a keyword">
                <?php while ($row = mysqli_fetch_assoc($common_result)) : ?>
                    <div class="accordion-item">
                        <button class="accordion"><?php echo htmlspecialchars($row['phrase']); ?>
                            <img class="arrow" src="bg/down-arrow.png"> <!-- PNG image for arrow -->
                        </button>
                        <div class="panel">
                            <button class="mark-done" onclick="markAsDone(this)">Mark as Done</button>
                            <p><b>Example:</b> <?php echo htmlspecialchars($row['example']); ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <footer class="footer">
            <ul class="social-icon">
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-twitter"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-linkedin"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
            </ul>
            <ul class="f-menu">
                <li class="f-menu__item"><a class="f-menu__link" href="#">Home</a></li>
                <li class="f-menu__item"><a class="f-menu__link" href="about.html">About</a></li>
                <li class="f-menu__item"><a class="f-menu__link" href="#">Dialects</a></li>
                <li class="f-menu__item"><a class="f-menu__link" href="#">Forum</a></li>
                <li class="f-menu__item"><a class="f-menu__link" href="contact.html">Contact</a></li>
            </ul>
        </footer>
    </section>
    <script>
        // JavaScript for searching words and examples
        function searchWords() {
            var input, filter, wordGrid, wordItems, a, i, txtValue;
            input = document.getElementById('searchInput');
            filter = input.value.toUpperCase();
            wordGrid = document.getElementById("wordGrid");
            wordItems = wordGrid.getElementsByClassName('word-item');

            var noWordsFound = true; // To check if no words are found

            for (i = 0; i < wordItems.length; i++) {
                a = wordItems[i].getElementsByTagName("a")[0];
                txtValue = a.textContent || a.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    wordItems[i].style.display = "";
                    noWordsFound = false;
                } else {
                    wordItems[i].style.display = "none";
                }
            }

            document.getElementById('noWordsMessage').style.display = noWordsFound ? '' : 'none';
        }

        function sortAlphabetically(letter) {
            var wordGrid, wordItems, i, letterValue;
            wordGrid = document.getElementById("wordGrid");
            wordItems = wordGrid.getElementsByClassName('word-item');

            var noWordsFound = true; // To check if no words are found

            for (i = 0; i < wordItems.length; i++) {
                letterValue = wordItems[i].getAttribute("data-letter");
                if (letterValue === letter) {
                    wordItems[i].style.display = "";
                    noWordsFound = false;
                } else {
                    wordItems[i].style.display = "none";
                }
            }

            document.getElementById('noWordsMessage').style.display = noWordsFound ? '' : 'none';
        }

        function searchExamples() {
            var input, filter, exampleContainer, accordions, panels, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            exampleContainer = document.getElementsByClassName("example")[0];
            accordions = exampleContainer.getElementsByClassName("accordion");
            panels = exampleContainer.getElementsByClassName("panel");

            for (i = 0; i < accordions.length; i++) {
                txtValue = accordions[i].textContent || accordions[i].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    accordions[i].style.display = "";
                    panels[i].style.display = "none"; // Hide panel initially
                } else {
                    accordions[i].style.display = "none";
                }
            }
        }

        // JavaScript for accordion functionality
        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.display === "block") {
                    panel.style.display = "none";
                } else {
                    panel.style.display = "block";
                }
            });
        }

        function markAsDone(button) {
            button.innerText = "Done!";
            button.disabled = true;
            button.style.background = "#6c757d";
        }
    </script>
</body>
</html>
