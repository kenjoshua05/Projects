<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

defined('APP') or die('Direct script access denied!');

function authenticate($row)
{
    $_SESSION['USER'] = $row;
}

function query($query, $types = "", $params = [])
{
    global $con;

    $stmt = mysqli_prepare($con, $query);
    if ($stmt === false) {
        return false;
    }

    if (!empty($types) && !empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    $result = mysqli_stmt_execute($stmt);
    if ($result) {
        $result = mysqli_stmt_get_result($stmt);
        if ($result && mysqli_num_rows($result) > 0) {
            $data = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
            mysqli_stmt_close($stmt);
            return $data;
        }
    }

    mysqli_stmt_close($stmt);
    return false;
}

function logged_in()
{
    return !empty($_SESSION['USER']);
}

function logout()
{
    if (!empty($_SESSION['USER'])) {
        unset($_SESSION['USER']);
    }
}

function get_image($path)
{
    return !empty($path) && file_exists($path) ? $path : 'assets/images/user.jpg';
}

function i_own_post($post)
{
    $current_user_id = $_SESSION['USER']['id'] ?? 0;
    return $post['user_id'] == $current_user_id;
}

function db_connect() {
    global $con;
    return $con;
}
?>
