<?php
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
if (!logged_in()) {
    header('Location: login.php'); // Redirect to login page
    exit;
}

// Fetch the logged-in user's ID
$user_id = $_SESSION['USER']['id']; // Adjust if needed to match your session data structure

// Get the quiz ID from the URL
$quiz_id = isset($_GET['quiz_id']) ? (int)$_GET['quiz_id'] : 0;

if ($quiz_id == 0) {
    echo "Invalid quiz ID.";
    exit;
}

// Fetch the quiz details
$query = "SELECT * FROM quizzes WHERE id = $quiz_id";
$quiz = query($query);
if (!$quiz) {
    echo "Quiz not found.";
    exit;
}
$quiz = $quiz[0];

// Fetch the latest result for the logged-in user
$query = "
    SELECT id
    FROM user_quiz_results
    WHERE user_id = $user_id
    AND quiz_id = $quiz_id
    ORDER BY taken_at DESC
    LIMIT 1
";
$result = query($query);
if (!$result) {
    echo "No results found or query error.";
    exit;
}

if (empty($result)) {
    echo "No results found.";
    exit;
}

$result_id = $result[0]['id'];

// Fetch the latest answers for each question for the latest result
$query = "
    SELECT uqa.*, q.question_text, c.choice_text, c.is_correct
    FROM user_quiz_answers uqa
    JOIN questions q ON uqa.question_id = q.id
    JOIN choices c ON uqa.selected_choice_id = c.id
    JOIN (
        SELECT question_id, MAX(id) as max_id
        FROM user_quiz_answers
        WHERE user_id = $user_id
        AND question_id IN (
            SELECT question_id
            FROM questions
            WHERE quiz_id = $quiz_id
        )
        GROUP BY question_id
    ) latest ON uqa.id = latest.max_id
    WHERE uqa.user_id = $user_id
    AND q.quiz_id = $quiz_id
";
$answers = query($query);

if (!$answers) {
    echo "No answers found or query error.";
    exit;
}

// Organize answers by question
$organized_answers = [];
foreach ($answers as $answer) {
    $organized_answers[$answer['question_id']]['question_text'] = $answer['question_text'];
    $organized_answers[$answer['question_id']]['answers'][] = [
        'choice_text' => $answer['choice_text'],
        'is_correct' => $answer['is_correct'],
        'selected_choice_id' => $answer['selected_choice_id']
    ];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Quiz Answers</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="scripts.js" defer></script>
    <style>
        @keyframes appear {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .hide {
            display: none;
        }

        h1 {
            color: #007BFF;
            margin-bottom: 20px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0 auto;
            max-width: 800px;
            width: 100%;
        }

        li {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        li:hover {
            background-color: #f1f3f5;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .correct {
            background-color: #d4edda;
            padding: 5px;
            border-radius: 4px;
            font-weight: bold;
        }

        .incorrect {
            background-color: #f8d7da;
            padding: 5px;
            border-radius: 4px;
            font-weight: bold;
        }

        .highlight {
            font-weight: bold;
            color: #007BFF;
        }

        .review-link {
            display: inline-block;
            margin: 20px auto;
            padding: 10px 20px;
            font-size: 16px;
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            text-align: center;
        }

        .review-link:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .link-container {
            text-align: center;
            margin: 20px auto;
        }

        strong {
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <?php include('header.inc.php'); ?>

    <h1>Review Quiz Answers for <?= htmlspecialchars($quiz['title']) ?></h1>

    <?php if ($organized_answers): ?>
        <ul>
            <?php foreach ($organized_answers as $question_id => $data): ?>
                <li>
                    <strong>Question:</strong> <?= htmlspecialchars($data['question_text']) ?><br>
                    <ul>
                        <?php
                        // Fetch correct choices for this question
                        $query = "
                            SELECT choice_text
                            FROM choices
                            WHERE question_id = $question_id
                            AND is_correct = 1
                        ";
                        $correct_answers = query($query);
                        if (!$correct_answers) {
                            echo "Error fetching correct answers.";
                            exit;
                        }
                        $correct_answers_texts = array_column($correct_answers, 'choice_text');
                        ?>
                        <?php foreach ($data['answers'] as $answer): ?>
                            <li>
                                <strong>Your Answer:</strong> 
                                <span class="<?= in_array($answer['choice_text'], $correct_answers_texts) ? 'correct' : 'incorrect' ?>">
                                    <?= htmlspecialchars($answer['choice_text']) ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                        <li>
                            <strong>Correct Answer(s):</strong>
                            <span class="highlight">
                                <?= implode(', ', $correct_answers_texts) ?>
                            </span>
                        </li>
                    </ul>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No answers found for this quiz.</p>
    <?php endif; ?>

    <div class="link-container">
        <a href="available_quizzes.php" class="review-link">Back to Available Quizzes</a>
    </div>

    <?php include('signup.inc.php'); ?>
    <?php include('login.inc.php'); ?>
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
</body>
</html>
