<?php
require('config.inc.php');
require('functions.php');

if (isset($_GET['id'])) {
    $word_id = intval($_GET['id']);

    // Query to retrieve word details including category
    $query = "SELECT d.*, c.name AS category_name FROM dialect_data d
              LEFT JOIN categories c ON d.category_id = c.id
              WHERE d.id = $word_id";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $word_data = mysqli_fetch_assoc($result);

        // Fetch similar words based on the English meaning
        $english_meaning = mysqli_real_escape_string($con, $word_data['english_meaning']);
        $similar_query = "SELECT * FROM dialect_data WHERE english_meaning = '$english_meaning' AND id != $word_id";
        $similar_result = mysqli_query($con, $similar_query);
    } else {
        echo "Word not found.";
        exit;
    }
} else {
    echo "No word ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Word Details</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
</head>
<body>
    <style>
        		@keyframes appear{
			0%{
				opacity: 0;
			}
			100%{
				opacity: 1;
			}
		}

		.hide{
			display:none;
		}

          .back-arrow {
                position: relative;
                font-size: 1.5rem;
                color: #00ab66;
                text-decoration: none;
                display: flex;
                align-items: center;
                margin-left:20px;
                margin-top:10px;
            }

            .back-arrow i {
                margin-right: 5px; /* Spacing between icon and text */
            }
/* Accordion Styles */
.accordion {
    margin: 40px 0;
    padding: 20px;
    border-top: 2px solid #B40023;
    border-radius: 8px;
    background-color: #f9f9f9;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.accordion h2 {
    text-align: center;
    color: #B40023;
    margin-bottom: 20px;
    font-size: 2rem;
    font-weight: 600;
}

.accordion-item {
    border-bottom: 1px solid #ccc;
    margin-bottom: 10px;
    border-radius: 8px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.accordion-title {
    cursor: pointer;
    padding: 15px;
    background-color: #f7f7f7;
    color: #333;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    position: relative;
    border-radius: 8px;
}

.accordion-title h3 {
    margin: 0;
    font-size: 1.2rem;
    flex-grow: 1;
}

.accordion-title i {
    font-size: 1.2rem;
    position: absolute;
    right: 15px;
    transition: transform 0.3s ease;
    color: #B40023;
}

.accordion-title:hover {
    background-color: #e7e7e7;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.accordion-content {
    display: none;
    padding: 15px;
    background-color: #fff;
    color: #555;
    border-top: 1px solid #ccc;
    border-radius: 0 0 8px 8px;
    line-height: 1.6;
    transition: max-height 0.3s ease;
}

.accordion-content p {
    margin: 10px 0;
}

.accordion .accordion-item.active i {
    transform: rotate(180deg); /* Rotate the plus icon to make it look like a minus */
}

.accordion .accordion-item.active .accordion-content {
    display: block;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .accordion h2 {
        font-size: 1.5rem;
    }

    .accordion-title h3 {
        font-size: 1rem;
    }

    .accordion-title i {
        font-size: 1rem;
        right: 10px;
    }

    .accordion-content {
        padding: 10px;
    }
}

.similar-words-section {
    max-width: 950px;
    width: 90%;
    margin: 20px auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.similar-words-section h3 {
    color: #333;
    margin-bottom: 15px;
}

.similar-words-list {
    display: flex;
    flex-wrap: wrap; /* Allow wrapping to the next line */
    justify-content: flex-start; /* Align items to the start */
    gap: 15px; /* Space between items */
}

.similar-words-list a {
    flex: 1 1 calc(25% - 15px); /* Take 25% width minus gap */
    text-align: center; /* Center text in each item */
    padding: 10px;
    background-color: #f4f6f9; /* Light background for each word */
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    text-decoration: none;
    color: #B40023;
    transition: color 0.3s ease, background-color 0.3s ease;
}

.similar-words-list a:hover {
    color: #ffffff;
    background-color: #B40023; /* Change background color on hover */
}
    </style>
    <section class="class_1">
        <?php include('header.inc.php') ?>

        <div class="primary-container">
        <a href="javascript:history.back()" class="back-arrow">
        <i class="fas fa-arrow-left"></i>
    </a>
           <div class="res">
                <h1><?php echo htmlspecialchars($word_data['word']); ?></h1>
                <!-- Sound Icon -->
                <div class="sound-icon" onclick="toggleSound()">
                    <ion-icon name="volume-high-outline"></ion-icon>
                </div>
                <div style="width: 100%; display: flex; align-items: center;">
                    <h3 style="margin: 0; padding: 0 10px 0 0; color: rgb(98, 96, 96);">Dialect:</h3>
                    <h2 style="margin: 0; padding: 0;"><?php echo htmlspecialchars($word_data['category_name']); ?></h2>
                </div>
          </div>

            <div class="pronounce">
                <h3 style="color: rgb(98, 96, 96);">Pronunciation</h3>
                <h4><?php echo htmlspecialchars($word_data['pronunciation']); ?></h4>
            </div>
            <div class="similar-words-section">
                <h3>Similar Words:</h3>
                <div class="similar-words-list">
                    <?php
                    // Query to get similar words with their category names
                    $similar_query = "SELECT d.id, d.word, c.name AS category_name 
                                    FROM dialect_data d
                                    LEFT JOIN categories c ON d.category_id = c.id
                                    WHERE d.english_meaning = '" . mysqli_real_escape_string($con, $word_data['english_meaning']) . "' 
                                    AND d.id != $word_id";
                    $similar_result = mysqli_query($con, $similar_query);

                    if ($similar_result && mysqli_num_rows($similar_result) > 0) {
                        while ($similar_word = mysqli_fetch_assoc($similar_result)) {
                            echo '<a href="word.php?id=' . htmlspecialchars($similar_word['id']) . '">' . htmlspecialchars($similar_word['word']) . ' (' . htmlspecialchars($similar_word['category_name']) . ')</a>';
                        }
                    } else {
                        echo '<p>No similar words found.</p>';
                    }
                    ?>
                </div>
            </div>


            <div class="example">
                <h3 style="color: rgb(98, 96, 96);">Examples</h3>
                <div class="accordion-item">
                    <div class="accordion-title">
                        <h3><?php echo htmlspecialchars($word_data['example1']); ?><i class="fas fa-plus"></i></h3>
                    </div>
                    <div class="accordion-content">
                    <p><b>Tagalog:</b> <?php echo htmlspecialchars($word_data['example1_tagalog']); ?></p>
                    <p><b>English:</b> <?php echo htmlspecialchars($word_data['example1_english']); ?></p>
                    </div>
                </div>

                <div class="accordion-item">
                    <div class="accordion-title">
                        <h3><?php echo htmlspecialchars($word_data['example2']); ?><i class="fas fa-plus"></i></h3>
                    </div>
                    <div class="accordion-content">
                    <p><b>Tagalog:</b> <?php echo htmlspecialchars($word_data['example2_tagalog']); ?></p>
                    <p><b>English:</b> <?php echo htmlspecialchars($word_data['example2_english']); ?></p>
                    </div>
                </div>
            </div>

            <audio id="audioPlayer" controls>
                <source src="<?php echo htmlspecialchars('admin/' . $word_data['audio_file']); ?>" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>

            <div class="meaning">
                <h4>Tagalog Description</h4>
                <p><?php echo htmlspecialchars($word_data['tagalog_meaning']); ?></p>
            </div>

            <div class="meaning">
                <h4>English Description</h4>
                <p><?php echo htmlspecialchars($word_data['english_meaning']); ?></p>
            </div>

        </div>
            
            <?php include('footer.inc.php') ?>
                
        <script>
document.querySelectorAll('.accordion-item').forEach(item => {
    const title = item.querySelector('.accordion-title');
    const content = item.querySelector('.accordion-content');
    const icon = title.querySelector('i');

    title.addEventListener('click', () => {
        // Toggle the 'active' class on the accordion item
        item.classList.toggle('active');

        // Toggle the display of the content
        if (item.classList.contains('active')) {
            content.style.display = "block";
            icon.classList.remove('fa-plus');
            icon.classList.add('fa-minus');
        } else {
            content.style.display = "none";
            icon.classList.remove('fa-minus');
            icon.classList.add('fa-plus');
        }
    });
});

function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

    
    </script>
        <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <script src="script.js"></script>
    </section>
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
</body>
</html>
