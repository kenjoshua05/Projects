document.addEventListener("DOMContentLoaded", function() {
  hideExcessWords();
  filterExamples(); // Initial filtering to show only five examples

  // Get all elements with class="accordion" and loop through them
  var accordions = document.getElementsByClassName("accordion");
  for (var i = 0; i < accordions.length; i++) {
      // Add click event listener to each accordion
      accordions[i].addEventListener("click", function() {
          // Toggle active class to highlight clicked accordion button
          this.classList.toggle("active");

          // Toggle the arrow rotation
          var arrow = this.querySelector('.arrow');
          if (arrow) {
              arrow.classList.toggle('rotate');
          }

          // Toggle the panel visibility using nextElementSibling property
          var panel = this.nextElementSibling;
          if (panel) {
              if (panel.style.display === "block") {
                  panel.style.display = "none";
              } else {
                  panel.style.display = "block";
              }
          }
      });
  }




   // JavaScript for scroll to top button
   window.onscroll = function() {
    scrollFunction();
};

function scrollFunction() {
    var scrollBtn = document.getElementById("scrollBtn");
    if (scrollBtn) {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            scrollBtn.classList.add("show");
        } else {
            scrollBtn.classList.remove("show");
        }
    }
}

var scrollBtn = document.getElementById("scrollBtn");
if (scrollBtn) {
    scrollBtn.addEventListener("click", function() {
        window.scrollTo({
            top: 0, // Scroll to the top
            behavior: 'smooth' // Enable smooth scrolling
        });
    });
}

  // Dummy function for hideExcessWords
  function hideExcessWords() {
      // Your logic for hiding excess words
      console.log("hideExcessWords function called");
  }

  function filterExamples() {
      // Your logic for filtering examples
      console.log("filterExamples function called");
  }
});

  // Sound
function toggleSound() {
    var audioPlayer = document.getElementById('audioPlayer');
    if (audioPlayer.paused) {
        audioPlayer.play();
    } else {
        audioPlayer.pause();
    }
}



function searchWords() {
    var input, filter, wordGrid, wordItems, word, i;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    wordGrid = document.getElementById('wordGrid');
    wordItems = wordGrid.getElementsByClassName('word-item');

    for (i = 0; i < wordItems.length; i++) {
        word = wordItems[i].getElementsByTagName('a')[0];
        if (word.textContent.toUpperCase().indexOf(filter) > -1) {
            wordItems[i].style.display = "";
        } else {
            wordItems[i].style.display = "none";
        }
    }
}


function searchExamples() {
    var input, filter, exampleContainer, examples, phrase, i;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    exampleContainer = document.getElementsByClassName('example')[0];
    examples = exampleContainer.getElementsByClassName('accordion-item');

    for (i = 0; i < examples.length; i++) {
        phrase = examples[i].getElementsByClassName('accordion')[0];
        if (phrase.textContent.toUpperCase().indexOf(filter) > -1) {
            examples[i].style.display = "";
        } else {
            examples[i].style.display = "none";
        }
    }
}

function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}
