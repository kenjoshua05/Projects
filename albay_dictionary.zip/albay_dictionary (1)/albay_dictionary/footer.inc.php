<?php defined('APP') or die('direct script access denied!'); ?>
<footer>
  <div class="custom-footer-container">
    <div class="custom-footer-section custom-about-us">
      <h3 class="custom-footer-title custom-about-title">About Us</h3>
      <p class="custom-footer-description">
      Explore Albay's vibrant linguistic landscape, where dialects showcase its rich cultural heritage. 
      From melodic Bicolano to rhythmic Legazpi, each dialect reflects the region's history and traditions.
    </p>
    </div>

    <div class="custom-footer-section custom-quick-links">
      <h3 class="custom-footer-title">Quick Links</h3>
      <ul class="custom-footer-list">
        <li class="custom-footer-item"><a href="#"><i class="bi bi-house"></i> Home</a></li>
        <li class="custom-footer-item"><a href="#"><i class="bi bi-info-circle"></i> About Us</a></li>
        <li class="custom-footer-item"><a href="#"><i class="bi bi-book"></i> Dialects</a></li>
        <li class="custom-footer-item"><a href="#"><i class="bi bi-pencil-square"></i> Quiz</a></li>
        <li class="custom-footer-item"><a href="#"><i class="bi bi-chat-dots"></i> Forum</a></li>
      </ul>
    </div>

    <div class="custom-footer-section custom-contact-info">
      <h3 class="custom-footer-title">Contact Us</h3>
      <ul class="custom-footer-list">
        <li class="custom-footer-item"><i class="bi bi-telephone"></i> +123-456-7890</li>
        <li class="custom-footer-item"><i class="bi bi-envelope"></i> albaydialects@gmail.com</li>
        <li class="custom-footer-item"><i class="bi bi-geo-alt"></i> 123 Street, City, Country</li>
      </ul>
    </div>

    <div class="custom-footer-section custom-social-media">
      <h3 class="custom-footer-title">Follow Us</h3>
      <div class="custom-social-links">
        <a href="#" class="custom-social-icon"><i class="bi bi-facebook"></i></a>
        <a href="#" class="custom-social-icon"><i class="bi bi-twitter"></i></a>
        <a href="#" class="custom-social-icon"><i class="bi bi-instagram"></i></a>
        <a href="#" class="custom-social-icon"><i class="bi bi-linkedin"></i></a>
      </div>
    </div>
  </div>
  <div class="custom-footer-bottom">
    <p>&copy; 2024 Albay Dialects | Designed by Albay Dialects</p>
  </div>
</footer>