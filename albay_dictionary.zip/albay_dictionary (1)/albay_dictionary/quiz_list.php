<?php
require('config.inc.php');
require('functions.php');

// Fetch all categories from the database
$query = "SELECT id, name FROM categories";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Quiz Category</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <style>
		
		@keyframes appear{
			0%{
				opacity: 0;
			}
			100%{
				opacity: 1;
			}
		}

		.hide{
			display:none;
		}

	</style>
</head>
<body>
<section class="class_1">
    <?php include('header.inc.php'); ?>

    <div class="h1">
        <h1>Select Quiz Category</h1>
    </div>

    <div class="clickable-boxes">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="clickable-box" style="background-color: #fff;" onclick="location.href='quiz_category.php?category_id=<?php echo $row['id']; ?>';">
                <span><?php echo htmlspecialchars($row['name']); ?></span>
                <img src="assets/images/arowss.png" alt="Arrowhead">
            </div>
        <?php endwhile; ?>
    </div>

    <footer class="footer">
        <div class="waves">
            <div class="wave" id="wave1"></div>
            <div class="wave" id="wave2"></div>
            <div class="wave" id="wave3"></div>
            <div class="wave" id="wave4"></div>
        </div>
        <ul class="social-icon">
            <li class="social-icon__item"><a class="social-icon__link" href="#">
                <ion-icon name="logo-facebook"></ion-icon>
            </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="#">
                <ion-icon name="logo-twitter"></ion-icon>
            </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="#">
                <ion-icon name="logo-linkedin"></ion-icon>
            </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="#">
                <ion-icon name="logo-instagram"></ion-icon>
            </a></li>
        </ul>
        <ul class="f-menu">
            <li class="menu__item"><a class="menu__link" href="#">Home</a></li>
            <li class="menu__item"><a class="menu__link" href="about.html">About</a></li>
            <li class="menu__item"><a class="menu__link" href="#">Dialects</a></li>
            <li class="menu__item"><a class="menu__link" href="#">Forum</a></li>
        </ul>
        <p>2024 Albay Dialects | All Rights Reserved</p>
    </footer>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <?php include('signup.inc.php'); ?>
    <?php include('login.inc.php'); ?>
</section>
<button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
<script src="script.js"></script>
</body>
</html>

<?php
// Close database connection (if you need to close explicitly)
mysqli_close($con);
?>
