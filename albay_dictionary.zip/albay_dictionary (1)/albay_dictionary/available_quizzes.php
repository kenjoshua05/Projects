<?php
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
$loggedIn = logged_in();

// Get the category filter from the URL
$categoryFilter = isset($_GET['category']) ? intval($_GET['category']) : 0;

// Fetch categories from the database
$categoryQuery = "SELECT * FROM categories";
$categories = query($categoryQuery);

// Fetch quizzes from the database with optional category filter
$query = "SELECT quizzes.*, categories.name AS category_name
          FROM quizzes
          JOIN categories ON quizzes.category_id = categories.id";
if ($categoryFilter) {
    $query .= " WHERE quizzes.category_id = " . mysqli_real_escape_string($con, $categoryFilter);
}
$quizzes = query($query);

// Function to check if the maximum number of attempts is reached
function is_max_attempt_reached($quiz_id, $user_id, $con) {
    // Fetch maximum attempts for the quiz
    $query = "SELECT max_attempts FROM quizzes WHERE id = $quiz_id";
    $result = query($query);
    if (!$result) {
        return false;
    }
    $max_attempts = $result[0]['max_attempts'];

    // Fetch number of attempts already made by the user
    $query = "SELECT COUNT(*) AS attempts FROM user_quiz_results WHERE quiz_id = $quiz_id AND user_id = $user_id";
    $result = query($query);
    if (!$result) {
        return false;
    }
    $attempts = $result[0]['attempts'];

    return $attempts >= $max_attempts;
}

$user_id = $loggedIn ? $_SESSION['USER']['id'] : 0; // Assuming user ID is stored in the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Quizzes</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="scripts.js" defer></script>
    <style>
        .warning-container {
            display: <?= !$loggedIn ? 'flex' : 'none' ?>;
            align-items: center;
            justify-content: center;
            background-color: #00ab66;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            margin: 20px auto;
            text-align: center;
            max-width: 800px;
        }

        .warning-message {
            flex-grow: 1;
            text-align: center;
        }

        .warning-icon {
            margin-left: 10px;
            margin-right: 10px;
            max-width: 30px;
        }

        .warning-close {
            background: none;
            border: none;
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }

        .hide {
            display: none;
        }

        button, .quiz-link {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .disabled {
            background-color: #6c757d;
            cursor: not-allowed;
            pointer-events: none; /* Disable click events */
        }

        .sort-container {
            display: flex;
            justify-content: flex-end;
            margin: 20px;
        }

        .sort-button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            position: relative;
            font-family: "DM Sans", sans-serif;
        }

        .sort-button:hover {
            background-color: #0056b3;
        }

        .sort-dropdown {
            position: relative;
            display: inline-block;
        }

        .sort-dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            right: 0;
        }

        .sort-dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .sort-dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .sort-dropdown:hover .sort-dropdown-content {
            display: block;
        }

        /* Styles for Available Quizzes Section */
        ul {
            list-style: none;
            padding: 0;
            margin: 20px auto;
            max-width: 800px;
        }

        li {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        li:hover {
            background-color: #e9ecef;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        h2 {
            font-size: 1.5em;
            color: #007BFF;
            margin: 0 0 10px;
        }

        p {
            margin: 0 0 15px;
            color: #555;
        }

        .quiz-link {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .quiz-link:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .disabled {
            background-color: #6c757d;
            cursor: not-allowed;
            pointer-events: none; /* Disable click events */
        }
    </style>
</head>
<body>
<?php include('header.inc.php'); ?>

 <!-- Sorting Button Section -->
 <div class="sort-container">
        <div class="sort-dropdown">
            <button class="sort-button">Sort by Category</button>
            <div class="sort-dropdown-content">
                <a href="available_quizzes.php">All Dialects</a>
                <?php foreach ($categories as $category): ?>
                    <a href="available_quizzes.php?category=<?= urlencode($category['id']) ?>">
                        <?= htmlspecialchars($category['name']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Warning Message for Non-Logged-In Users -->
    <?php if (!$loggedIn): ?>
        <h1>Available Quizzes</h1>
    <div id="warningContainer" class="warning-container">
        <img src="assets/images/warning.png" alt="Warning" class="warning-icon">
        <span class="warning-message">You need to log in to take this quiz.</span>
        <button class="warning-close" onclick="closeWarning()">×</button>
    </div>
    <?php endif; ?>

    <?php if ($quizzes): ?>
        <ul>
            <?php foreach ($quizzes as $quiz): ?>
                <?php $disabled = $loggedIn && is_max_attempt_reached($quiz['id'], $user_id, $con) ? 'disabled' : ''; ?>
                <li>
                    <h2><?= htmlspecialchars($quiz['title']) ?></h2>
                    <p><?= htmlspecialchars($quiz['description']) ?></p>
                    <p>Category: <?= htmlspecialchars($quiz['category_name']) ?></p>
                    <a href="take_quiz.php?id=<?= $quiz['id'] ?>" class="quiz-link <?= $disabled ?>" <?= $disabled ? '' : 'onclick="checkLogin(event)"' ?>>
                        <?= $loggedIn ? ($disabled ? 'Maximum Attempt Reached' : 'Take Quiz') : 'Login to take quiz' ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No quizzes available at the moment.</p>
    <?php endif; ?>

    <!-- Include your signup and login modals here -->
    <?php include('signup.inc.php'); ?>
    <?php include('login.inc.php'); ?>

    <script>
    function closeWarning() {
        document.getElementById('warningContainer').style.display = 'none';
    }

    function checkLogin(e) {
        <?php if (!$loggedIn): ?>
        e.preventDefault();
        login.show();
        <?php endif; ?>
    }
    </script>

    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
</body>
</html>
