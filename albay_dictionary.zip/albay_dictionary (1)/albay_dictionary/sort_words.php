<?php
require_once('config.inc.php');
require_once('functions.php');

// Ensure the session is started

// Check if category_id is provided and valid
if (isset($_GET['category_id']) && is_numeric($_GET['category_id'])) {
    $_SESSION['category_page_url'] = "prevcategory.php?category_id=" . $_GET['category_id'];
}

// Check if category ID is provided and is numeric
if (!isset($_GET['category_id']) || !is_numeric($_GET['category_id'])) {
    // Redirect to an error page or show an error message
    header("Location: error.php?message=Invalid Category ID");
    exit();
}

// Sanitize category ID
$category_id = mysqli_real_escape_string($con, $_GET['category_id']);

// Get the selected letter (if any)
$selected_letter = isset($_GET['letter']) ? mysqli_real_escape_string($con, $_GET['letter']) : '';

// Fetch category name for display
$category_query = "SELECT name FROM categories WHERE id='$category_id'";
$category_result = mysqli_query($con, $category_query);

// Check if the category exists
if (mysqli_num_rows($category_result) === 0) {
    // Redirect to an error page or show an error message
    header("Location: error.php?message=Category not found");
    exit();
}

$category = mysqli_fetch_assoc($category_result);

// Fetch words from dialect_data table for the given category, optionally filtered by the selected letter
$words_query = "SELECT id, word, english_meaning FROM dialect_data WHERE category_id='$category_id'";

if (!empty($selected_letter)) {
    $words_query .= " AND word LIKE '$selected_letter%'";
}

$words_result = mysqli_query($con, $words_query);

// Define the number of items per page
$items_per_page = 10; // Adjust this as needed

// Get the current page number from the URL, defaulting to 1
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $items_per_page;

// Add pagination
$words_query .= " LIMIT $items_per_page OFFSET $offset";

// Execute the query with pagination
$words_result = mysqli_query($con, $words_query);

// Fetch total words for pagination
$total_query = "SELECT COUNT(*) as total FROM dialect_data WHERE category_id='$category_id'";
if (!empty($selected_letter)) {
    $total_query .= " AND word LIKE '$selected_letter%'";
}

$total_result = mysqli_query($con, $total_query);
$total_words = mysqli_fetch_assoc($total_result)['total'];

// Calculate the total number of pages
$total_pages = ceil($total_words / $items_per_page);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sort</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
</head>
<body> 


<style>

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap');

/* Container for back button and sort buttons */

/* Remove text decoration from links */
a {
    text-decoration: none; /* Removes the underline */
}

/* Optionally, add a hover effect to make links stand out */
a:hover {
    text-decoration: none; /* Ensure no underline on hover */
    color: #B40023; /* You can change the color on hover if you like */
}

.container {
    font-family: "DM Sans", sans-serif;
    max-width: 1200px;
    margin: 0 auto;
    padding: 30px;
    background-color: #f9f9f9; /* Soft background color */
    border-radius: 8px; /* Rounded corners for a more modern feel */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); /* Soft shadow for a clean effect */
}

/* Back button */
.back-button {
    margin-bottom: 30px;
}

.back-button a {
    font-size: 16px;
    color: #B40023;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: color 0.3s ease;
}

.back-button a:hover {
    color: #8c0025;
}

.back-button a i {
    margin-right: 10px;
}

/* Sort buttons (A-Z) */
.sort-buttons {
    margin-bottom: 30px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
}

.sort-button {
    padding: 12px 18px;
    font-size: 18px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.sort-button:hover {
    background-color: #B40023;
    color: white;
    transform: scale(1.1);
}

.sort-button:focus {
    outline: none;
}

/* Word grid container */
.pri-container {
    margin-top: 30px;
}

.word-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 30px;
}

/* Word card */
.word-card {
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.word-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.word-card h2 {
    margin: 0 0 15px;
    font-size: 22px;
    color: #333;
}

.word-card p {
    color: #666;
    font-size: 14px;
}

/* No words found message */
#noWordsMessage {
    text-align: center;
    color: #B40023;
    font-size: 16px;
    padding: 20px;
    background-color: #f9e5e5;
    border-radius: 5px;
    display: inline-block;
}

/* Pagination */
.pagination {
    margin-top: 30px;
    text-align: center;
}

.pagination a {
    padding: 12px 18px;
    background-color: #f1f1f1;
    border: 1px solid #ccc;
    color: #333;
    text-decoration: none;
    margin: 0 5px;
    border-radius: 4px;
    transition: background-color 0.3s ease;
}

.pagination a:hover {
    background-color: #B40023;
    color: white;
}

.pagination .active {
    background-color: #B40023;
    color: white;
}

/* Media query for smaller screens */
@media (max-width: 768px) {
    /* Adjust sort buttons to display horizontally in smaller screens */
    .sort-buttons {
        flex-direction: row; /* Align buttons horizontally */
        justify-content: space-between; /* Spread out the buttons */
        gap: 5px;
    }

    .sort-button {
        font-size: 14px; /* Reduce button text size on smaller screens */
        padding: 10px 14px; /* Adjust padding for smaller screens */
    }
}

</style>



<div class="container">
 

<div class="back-button">
<a href="<?php echo isset($_SESSION['category_page_url']) ? $_SESSION['category_page_url'] : 'default_page.php'; ?>">
    <i class="fas fa-arrow-left"></i> Back
</a>
</div>


    <!-- Sort buttons -->
    <div class="sort-buttons">
    <?php 
    // Custom array with the desired letters only
    $letters = ['A', 'B', 'K', 'D', 'G', 'H', 'L', 'M', 'N', 'P', 'S', 'T', 'W', 'Y'];
    foreach ($letters as $letter): ?>
        <button class="sort-button" onclick="window.location.href='sort_words.php?category_id=<?php echo $category_id; ?>&letter=<?php echo $letter; ?>'">
            <?php echo $letter; ?>
        </button>
    <?php endforeach; ?>
</div>


    <!-- Words display grid -->
    <div class="pri-container">
        <div class="word-grid" id="wordGrid">
            <?php if (mysqli_num_rows($words_result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($words_result)) : ?>
                    <a href="word.php?id=<?php echo $row['id']; ?>" class="word-card-link">
                        <div class="word-card" data-letter="<?php echo strtoupper($row['word'][0]); ?>">
                            <h2><?php echo htmlspecialchars($row['word']); ?></h2>
                            <?php 
                                $english_meaning = $row['english_meaning'] ?? 'No meaning available';
                                $words = explode(' ', $english_meaning); 
                                $limited_meaning = implode(' ', array_slice($words, 0, 3)); 

                                if (count($words) > 3) {
                                    $limited_meaning .= '...';
                                }
                            ?>
                            <p><?php echo htmlspecialchars($limited_meaning); ?></p>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p id="noWordsMessage">
                    <i class="fas fa-exclamation-circle"></i> No words found for this letter.
                </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Pagination -->
    <div class="pagination">
        <?php if ($current_page > 1): ?>
            <a href="?category_id=<?php echo $category_id; ?>&letter=<?php echo $selected_letter; ?>&page=<?php echo $current_page - 1; ?>">&laquo; Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?category_id=<?php echo $category_id; ?>&letter=<?php echo $selected_letter; ?>&page=<?php echo $i; ?>" class="<?php if ($i == $current_page) echo 'active'; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>

        <?php if ($current_page < $total_pages): ?>
            <a href="?category_id=<?php echo $category_id; ?>&letter=<?php echo $selected_letter; ?>&page=<?php echo $current_page + 1; ?>">Next &raquo;</a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
