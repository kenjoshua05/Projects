<?php
require('config.inc.php');
require('functions.php');

// Fetch all categories from the database
$query = "SELECT id, name FROM categories";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dialects</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <style>
@keyframes popIn {
    0% {
        transform: scale(0.8);
        opacity: 0;
    }
    100% {
        transform: scale(1);
        opacity: 1;
    }
}

/* Header Styles */
.h1 {
    margin: 70px 40px 40px 140px;
}

.h1 h1 {
    text-align: start;
    font-weight: bolder;
    font-size: 4.1em;
    background: linear-gradient(90deg, #00ab66, #007BFF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.1);
    margin: 0;
    padding: 10px 0;
    animation: popIn 0.6s ease forwards; /* Adding pop-in animation */
}

/* Modern CSS styles */
.clickable-boxes {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Space between boxes */
    justify-content: center; /* Center boxes */
    padding: 20px; /* Add padding to the container */
}

.clickable-box {
    display: flex; /* Enable flexbox */
    align-items: center; /* Center content vertically */
    justify-content: flex-start; /* Align items to the start (left) */
    background: linear-gradient(145deg, #ffffff, #f2f2f2);
    border-radius: 15px;
    padding: 20px 20px 20px 60px; /* Add extra padding on the left for the icon */
    width: 300px;
    height: 120px;
    text-align: left; /* Align text to the left */
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); /* Increased shadow for depth */
    transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    cursor: pointer;
    position: relative; /* Needed for absolute positioning of the icon */
    overflow: hidden; /* Hide overflow content */
}

.clickable-box::before {
    content: "\f1ab"; /* Font Awesome unicode for language icon */
    font-family: "Font Awesome 5 Free"; /* Ensure it's using Font Awesome */
    font-weight: 900; /* Adjust icon weight */
    font-size: 150px; /* Adjust icon size to fit better */
    color: #00ab66; /* Icon color */
    position: absolute;
    top: 50%; /* Center the icon vertically */
    left: 150px; /* Adjust the icon position to the left */
    transform: translateY(-50%) rotate(60deg); /* Rotate the icon 60 degrees */
    opacity: 0.6; /* Make the icon more visible */
}

.clickable-box:hover {
    transform: translateY(-5px) scale(1.05); /* Lift effect and slight scale on hover */
    background: linear-gradient(145deg, #00ab66, #008751); /* Gradient background on hover */
    color: #fff; /* Text color changes on hover */
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3); /* Darker shadow on hover */
}


.clickable-box:hover span {
    transform: translateY(-5px); /* Move text up slightly on hover */
}



/* Animation to fade in clickable boxes */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px); /* Move up slightly */
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}


.clickable-box:hover::before {
    color: #ffffff; /* Change icon color on hover */
    opacity: 0.3; /* Slightly increase opacity on hover */
}

.icon {
    font-size: 2.5em; /* Larger icon size for prominence */
    color: #00ab66; /* Primary color for icon */
    margin-bottom: 10px; /* Space between icon and text */
    transition: color 0.3s ease; /* Smooth color transition */
}

.clickable-box span {
    display: block; /* Ensures span takes full width */
    font-weight: bold; /* Bold text */
    color: #333; /* Dark text color */
    font-size: 1.4em; /* Slightly larger font size */
    z-index: 100;
    text-align: center; /* Center text */
    padding: 5px 5px 5px 5px; /* Add vertical padding for spacing */
    transition: color 0.3s ease, transform 0.3s ease; /* Smooth transitions */
    border-radius: 8px; /* Rounded corners for a softer look */
    background: rgba(255, 255, 255, 0.8); /* Light background for contrast */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow for elevation */
}

.clickable-box:hover span {
    color: #ffffff; /* Change text color on hover */
    transform: translateY(-5px); /* Lift effect on hover */
    background: rgba(0, 171, 102, 0.9); /* Darker background on hover for contrast */
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2); /* Increase shadow on hover */
}


/* Hover styles for icon */
.clickable-box:hover .icon {
    color: #ffffff; /* Change icon color on hover */
}

/* Styles for mobile screens */
@media (max-width: 600px) {
    .h1 {
        text-align: start;
        margin: 0 20px;
    }

    .h1 h1 {
        font-size: 2.5em; /* Adjusted font size for smaller screens */
        padding: 5px 0; /* Reduced padding for smaller screens */
    }

    .clickable-box span {
        font-size: 1.5em; /* Slightly smaller font size */
    }

    .clickable-box img {
        height: 20px;
        width: 20px;
        margin-bottom: 0;
        margin-left: 10px;
    }
}


    </style>
</head>
<body>
<section class="class_1">
    <?php include('header.inc.php'); ?>

    <div class="h1">
        <h1>Dialects</h1>
    </div>

    <div class="clickable-boxes">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="clickable-box" onclick="location.href='prevcategory.php?category_id=<?php echo $row['id']; ?>';">
              
                <span><?php echo htmlspecialchars($row['name']); ?></span>
            </div>
        <?php endwhile; ?>
    </div>

<?php include('footer.inc.php') ?>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</section>

<!-- Scroll to top button -->
<button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
<script src="script.js"></script>
<script>
    function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

</script>
</body>
</html>

<?php
// Close database connection (if you need to close explicitly)
mysqli_close($con);
?>
