<?php
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
if (!logged_in()) {
    header('Location: login.php'); // Redirect to login page
    exit;
}

// Get the quiz ID and score from the URL
$quiz_id = isset($_GET['quiz_id']) ? (int)$_GET['quiz_id'] : 0;
$score = isset($_GET['score']) ? (int)$_GET['score'] : 0;
$total_questions = isset($_GET['total_questions']) ? (int)$_GET['total_questions'] : 0;

if ($quiz_id == 0) {
    echo "Invalid quiz ID.";
    exit;
}

// Fetch the quiz details
$query = "SELECT * FROM quizzes WHERE id = $quiz_id";
$quiz = query($query);
if (!$quiz) {
    echo "Quiz not found.";
    exit;
}
$quiz = $quiz[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Result</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="scripts.js" defer></script>
    <style>
        @keyframes appear {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .hide {
            display: none;
        }
        h1 {
            margin-bottom: 20px;
            color: #007BFF;
            text-align: center;
        }

        p {
            margin-bottom: 20px;
            color: #555;
            text-align: center;
        }

      .result-container {
    max-width: 800px;
    margin: 150px auto 20px; /* Added margin-top */
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
}

        .result-container a {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            border-radius: 5px;
            margin: 10px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .result-container a:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <!-- Include your header here -->
    <?php include('header.inc.php'); ?>

    <div class="result-container">
        <h1>Quiz Result for <?= htmlspecialchars($quiz['title']) ?></h1>
        <p>You scored <?= $score ?> out of <?= $total_questions ?>.</p>
        <a href="available_quizzes.php">Back to Available Quizzes</a>
        <a href="review_quiz.php?quiz_id=<?= $quiz_id ?>">Review Your Answers</a> <!-- Add this line to include the review button -->
    </div>

    <!-- Include your signup and login modals here -->
    <?php include('signup.inc.php'); ?>
    <?php include('login.inc.php'); ?>
</body>
</html>
