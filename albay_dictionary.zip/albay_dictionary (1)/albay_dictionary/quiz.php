<?php
session_start();
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
function logged_in() {
    return isset($_SESSION['USER']);
}

// Redirect to login popup if not logged in
if (!logged_in()) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'User not logged in.']);
    exit();
}

$quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
if ($quiz_id <= 0) {
    die('Invalid quiz ID.');
}

// Fetch quiz details
$query = "SELECT * FROM quizzes WHERE id = $quiz_id LIMIT 1";
$quiz = query($query);
if (!$quiz) {
    die('Quiz not found.');
}
$quiz = $quiz[0];

// Fetch questions for the quiz
$query = "SELECT * FROM questions WHERE quiz_id = $quiz_id";
$questions = query($query);

// Fetch choices for each question
$questions_with_choices = [];
foreach ($questions as $question) {
    $question_id = $question['id'];
    $query = "SELECT * FROM choices WHERE question_id = $question_id";
    $choices = query($query);
    $question['choices'] = $choices;
    $questions_with_choices[] = $question;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz: <?php echo htmlspecialchars($quiz['title']); ?></title>
    <link rel="stylesheet" href="style.css"> <!-- Include your CSS file -->
    <script>
        // Function to show the login popup
        function showLoginPopup() {
            if (typeof login !== 'undefined') {
                login.show(); // Trigger the login popup
            } else {
                alert('Login function is not defined');
            }
        }

        // Check if the user is logged in using AJAX
        document.addEventListener('DOMContentLoaded', function() {
            fetch('quiz.php?check_login=true')
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        showLoginPopup(); // Show the login popup if the user is not logged in
                    }
                })
                .catch(error => {
                    alert('Error checking login status.');
                });
        });
    </script>
</head>
<body>
    <header class="class_2">
        <div class="class_3">
            <img src="bg/logo4.png" class="class_4">
        </div>
        <div class="item_class_0 class_5">
            <div class="item_class_1 class_6">
                <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="m22 16.75c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75zm0-5c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75zm0-5c0-.414-.336-.75-.75-.75h-18.5c-.414 0-.75.336-.75.75s.336.75.75.75h18.5c.414 0 .75-.336.75-.75z" fill-rule="nonzero">
                    </path>
                </svg>
            </div>
            <div class="item_class_2 class_7">
                <a href="index.php" class="class_8">Home</a>
                <a href="about.php" class="class_8">About us</a>
                <a href="categories.php" class="class_8">Dialects</a>
                <a href="quiz_list.php" class="class_8">Quiz</a>
                <a href="forum.php" class="class_8">Forum</a>
            </div>
        </div>
        <div class="class_9" style="display:flex;align-items: center;justify-content: center;">
            <?php if(logged_in()): ?>
                <a href="profile.php">
                    <img src="<?= get_image($_SESSION['USER']['image']) ?>" class="class_10">
                </a>
                <a href="profile.php">
                    <span>Hi, <?= $_SESSION['USER']['username'] ?></span>
                </a>
            <?php else: ?>
                <span style="cursor:pointer;" onclick="showLoginPopup()">Login</span>
            <?php endif; ?>
        </div>
    </header>

    <h1><?php echo htmlspecialchars($quiz['title']); ?></h1>
    <form id="quiz-form" method="post">
        <?php foreach ($questions_with_choices as $question): ?>
            <fieldset>
                <legend><?php echo htmlspecialchars($question['question_text']); ?></legend>
                <?php foreach ($question['choices'] as $choice): ?>
                    <label>
                        <input type="radio" name="question_<?php echo $question['id']; ?>" value="<?php echo $choice['id']; ?>">
                        <?php echo htmlspecialchars($choice['choice_text']); ?>
                    </label><br>
                <?php endforeach; ?>
            </fieldset>
        <?php endforeach; ?>
        <button type="submit">Submit Answers</button>
    </form>

    <script>
        document.getElementById('quiz-form').addEventListener('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            formData.append('data_type', 'submit_quiz');
            formData.append('quiz_id', <?php echo $quiz_id; ?>);
            fetch('ajax.inc.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) {
                        // Optionally redirect or update the page
                        window.location.href = 'quiz_results.php?quiz_id=<?php echo $quiz_id; ?>';
                    }
                })
                .catch(error => {
                    alert('Error submitting quiz.');
                });
        });
    </script>

    <!-- Include the login popup HTML -->
    <div id="loginPopup" style="display:none;">
        <!-- Your login form here -->
        <form id="loginForm" method="post" action="login_process.php">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Login</button>
            <button type="button" onclick="document.getElementById('loginPopup').style.display='none'">Close</button>
        </form>
    </div>
</body>
</html>
