<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error - Invalid Action</title>
    <style>
        body {
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .error-container {
            border: 3px solid #ff0000;
            padding: 50px;
            background-color: #111;
            box-shadow: 0 0 15px #ff0000;
            max-width: 600px;
            width: 90%;
        }
        h1 {
            font-size: 3em;
            color: #ff0000;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        p {
            font-size: 1.2em;
            margin: 20px 0;
            font-weight: bold;
        }
        .warning {
            font-size: 1.5em;
            background-color: #ff0000;
            color: #fff;
            padding: 15px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }
        a {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            color: #fff;
            background-color: #B40023;
            text-decoration: none;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        a:hover {
            background-color: #ff0000;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>Stop Right There!</h1>
        <p><?php echo htmlspecialchars($_GET['message']); ?></p>
        <div class="warning">This action is NOT allowed!</div>
        <a href="index.php">Go Back to Safety</a>
    </div>
</body>
</html>
