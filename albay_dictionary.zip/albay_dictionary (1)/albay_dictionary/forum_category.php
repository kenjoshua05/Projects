<?php
include 'config.inc.php';

$category_id = $_GET['id'];  // Get the category ID from the URL

// Fetch the category name
$query_category = "SELECT name FROM forum_categories WHERE id = $category_id";
$category_result = $con->query($query_category);

// Check if the category exists
if ($category_result->num_rows > 0) {
    $category = $category_result->fetch_assoc();
    $category_name = htmlspecialchars($category['name']);
} else {
    $category_name = "Unknown Category"; // Default if no category found
}

// Fetch threads for the category
$query_threads = "SELECT * FROM forum_threads WHERE category_id = $category_id";
$threads_result = $con->query($query_threads);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Threads</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <!-- Google Font (Roboto) -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <style>
        /* General Body and Background */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            position: relative;
            overflow-x: hidden;
            background-color: #f4f4f4; /* Soft background color */
        }

        /* Random Shapes Background */
        .random-shapes {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none; /* Ensure shapes do not interfere with user interaction */
            z-index: -1;
        }

        .shape {
            position: absolute;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.2);
            opacity: 0.5;
            animation: randomMovement 10s infinite ease-in-out;
        }

        /* Random Movement for Shapes */
        @keyframes randomMovement {
            0% { transform: translate(0, 0); }
            25% { transform: translate(300px, 300px); }
            50% { transform: translate(-300px, -200px); }
            75% { transform: translate(200px, -400px); }
            100% { transform: translate(100px, 200px); }
        }

/* Header Styling */
h1 {
    text-align: center;
    margin-top: 40px;
    font-size: 2.5em;
    text-transform: uppercase;
    letter-spacing: 2px;
    font-weight: 700;
    color: #B40023;
}

/* Added margin for separation between h2 and li */
h2 {
    margin-bottom: 20px; /* Adjust the value as needed */
}

/* Back Button Styling */
.back-button {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #B40023;
    color: white;
    text-decoration: none;
    font-weight: 500;
    border-radius: 6px;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.back-button:hover {
    background-color: #1a62c2;
    transform: translateY(-3px);
}

/* Content Background */
.content {
    background-color: white;
    padding: 30px;
    margin: 20px auto;
    max-width: 900px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

/* List Styles */
ul {
    list-style: none;
    padding: 0;
    margin: 20px 0;
    font-size: 1.3em;
    color: #333;
}

li {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 15px;
    transition: background 0.3s ease, transform 0.3s ease;
    display: flex;
    align-items: center;
    font-size: 1.1em; /* Bigger font for li */
    font-weight: 500;
}

li:hover {
    background: rgba(255, 255, 255, 1);
    transform: translateY(-5px);
}

li a {
    color: #333;
    text-decoration: none;
    display: flex;
    align-items: center;
    font-weight: 600;
    flex: 1;
}

li a:hover {
    color: #2575fc;
}

li a i {
    margin-right: 12px;
}


        /* Footer Styles */
        footer {
            text-align: center;
            margin-top: 40px;
            font-size: 0.9em;
        }

        footer i {
            color: #333;
            margin-left: 5px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            h1 {
                font-size: 1.4em;
            }

            ul {
                max-width: 90%;
            }

            li {
                font-size: 0.7em;
            }

            .content {
                padding: 20px;
                margin: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Random Color Shapes in the Background -->
    <div class="random-shapes">
        <div class="shape" style="background-color: rgba(255, 99, 71, 0.5);"></div>
        <div class="shape" style="background-color: rgba(60, 179, 113, 0.5); width: 150px; height: 150px;"></div>
        <div class="shape" style="background-color: rgba(255, 215, 0, 0.5); width: 120px; height: 120px;"></div>
        <div class="shape" style="background-color: rgba(255, 99, 71, 0.5); width: 130px; height: 130px;"></div>
        <div class="shape" style="background-color: rgba(30, 144, 255, 0.5); width: 140px; height: 140px;"></div>
    </div>

    <div class="content">
        <!-- Back Button to Index -->
        <a href="new_forum.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Forum</a>
        
        <h1><i class="fas fa-folder-open"></i> Threads in <?= $category_name ?></h1>

        <ul>
            <?php while($thread = $threads_result->fetch_assoc()): ?>
                <li><a href="thread.php?id=<?= $thread['id'] ?>"><i class="fas fa-comments"></i><?= htmlspecialchars($thread['title']) ?></a></li>
            <?php endwhile; ?>
        </ul>
    </div>

    <footer>
        <p>&copy; 2024 Albay Dialects</i></p>
    </footer>
</body>
</html>
