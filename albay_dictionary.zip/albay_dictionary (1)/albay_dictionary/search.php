<?php
require('config.inc.php');
require('functions.php');

// Initialize variables for search
$searchResults = [];
$searchQuery = '';
$category = 'all';
$errorMessage = ''; // Variable to store error messages

// Check if the form is submitted via GET
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['query'])) {
    $searchQuery = trim($_GET['query']);
    $category = $_GET['category'] ?? 'all';

    // Validate search query
    if (empty($searchQuery)) {
        $errorMessage = "Please enter a search term."; // Set error message
    } else {
 // Prepare the SQL statement based on the selected category
$sql = "SELECT d.*, c.name AS category_name FROM dialect_data d
LEFT JOIN categories c ON d.category_id = c.id WHERE ";

$conditions = [];

// Check the selected category and build conditions accordingly
if ($category === 'words') {
$conditions[] = "d.word LIKE ?";
} elseif ($category === 'example') {
$conditions[] = "(d.example1 LIKE ? OR d.example2 LIKE ?)";
} elseif ($category === 'meaning') {
$conditions[] = "(d.tagalog_meaning LIKE ? OR d.english_meaning LIKE ?)";
} elseif ($category === 'all') {
$conditions[] = "(d.word LIKE ? 
            OR d.example1 LIKE ? 
            OR d.example2 LIKE ? 
            OR d.tagalog_meaning LIKE ? 
            OR d.english_meaning LIKE ?)";
}

// Join conditions and complete the SQL query
if (!empty($conditions)) {
$sql .= implode(' OR ', $conditions);
} else {
$sql .= "1"; // Fallback to return all if no category selected
}

// Prepare and execute the query with placeholders
$stmt = $con->prepare($sql);
$searchTerm = '%' . $searchQuery . '%';
if ($category === 'words') {
$stmt->bind_param('s', $searchTerm);
} elseif ($category === 'example') {
$stmt->bind_param('ss', $searchTerm, $searchTerm);
} elseif ($category === 'meaning') {
$stmt->bind_param('ss', $searchTerm, $searchTerm);
} elseif ($category === 'all') {
$stmt->bind_param('sssss', $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
}

// Execute the prepared statement
$stmt->execute();
$result = $stmt->get_result();

// Fetch results
while ($row = $result->fetch_assoc()) {
// Highlight the matched search query
foreach ($row as $key => $value) {
$row[$key] = highlightMatch($value, $searchQuery);
}
$searchResults[] = $row; // Store results in an array
}

        // Check if there are no results found
        if (empty($searchResults)) {
            $errorMessage = "No results found."; // Set message if no results
        }

        $stmt->close(); // Close statement
    }
}

function highlightMatch($text, $searchQuery) {
    // Just return the original text without any highlighting
    return $text; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Bar</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        /* Add styles for error messages */
        .error-message {
            color: red;
            font-weight: bold;
            margin: 10px 0;
        }

        .searchbg {
        padding-top: 100px;
        background-color: #f7f7f7;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
        flex-direction: column; /* Added for vertical stacking */
    }

    .back-arrow {
        align-self: flex-start; /* Align to the start */
        margin-bottom: 10px; /* Space between the arrow and search bar */
        font-size: 20px; /* Size of the icon */
        color: #B40023; /* Color of the icon */
        cursor: pointer; /* Change cursor to pointer */
    }

    .search-container1 {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #ffffff;
        padding: 15px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        width: 100%;
        max-width: 900px;
    }

    /* Remaining CSS remains unchanged */
    #search-form {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        width: 100%;
    }

/* Modern Dropdown Styling */
.dropdown-container {
    position: relative;
    width: 10%; /* Super small width for dropdown */
    min-width: 60px; /* Minimum width to show the text fully */
}

#category {
    width: 100%;
    padding: 12px 30px 12px 12px; /* Add padding to ensure space for icon */
    border-radius: 5px;
    border: 1px solid #ddd;
    font-size: 16px;
    color: #333;
    background-color: #f9f9f9;
    appearance: none;
    cursor: pointer;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    min-height: 40px; /* Minimum height to ensure visibility of the selected option */
}

#category:hover,
#category:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}

.dropdown-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    color: #777;
    font-size: 16px;
    margin-left: 5px; /* Add a tiny space to the left of the icon */
}

/* Search Input */
#search-input {
    flex-grow: 1;
    padding: 12px;
    margin-left: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

#search-input:hover,
#search-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}

#search-input::placeholder {
    color: #aaa;
}

/* Search Button */
#search-button {
    padding: 12px 20px;
    background-color: #B40023;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-left: 10px;
    transition: background-color 0.3s ease;
}

#search-button:hover {
    background-color: #d63447;
}

/* Media Queries for Responsiveness */

/* Tablets and Larger Screens */
@media (max-width: 768px) {
    #search-form {
        flex-wrap: nowrap; /* Prevent wrapping */
    }

    .dropdown-container {
        width: 10%; /* Super small width for dropdown */
        min-width: 60px; /* Minimum width to show the text fully */
    }

    #search-input {
        width: 70%; /* Adjust width for better fit */
        margin-left: 10px;
    }

    #search-button {
        width: 20%; /* Adjust width for better fit */
        margin-left: 10px;
    }
}

/* Mobile Devices */
@media (max-width: 576px) {
    #search-form {
        flex-wrap: nowrap; /* Prevent wrapping */
    }

    .dropdown-container {
        width: 10%; /* Super small width for dropdown */
        min-width: 60px; /* Minimum width to show the text fully */
    }

    #search-input {
        width: 70%; /* 70% width for input */
    }

    #search-button {
        width: 20%; /* 20% width for button */
    }
}

/* Search Results Container */
.search-results {
    margin: 20px auto; /* Center the search results */
    max-width: 800px; /* Limit the width of the results */
    padding: 20px; /* Padding for the container */
    border-radius: 12px; /* Rounded corners */
    background: linear-gradient(to bottom right, #ffffff, #f8f8f8); /* Gradient background */
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Deeper shadow for a modern look */
}

/* Heading Style */
.search-results h2 {
    color: #B40023; /* Use the same color as your buttons */
    font-size: 26px; /* Larger heading size */
    margin-bottom: 15px; /* Space below heading */
    font-weight: bold; /* Bold font for emphasis */
    text-align: center; /* Center the heading */
    border-bottom: 2px solid #B40023; /* Underline for added emphasis */
    padding-bottom: 10px; /* Padding below heading */
}

/* List Style */
.search-results ul {
    list-style-type: none; /* Remove bullets */
    padding: 0; /* Remove padding */
}

/* Individual Result Item Style */
.search-results li {
    padding: 15px; /* Padding for each result item */
    border: 1px solid #ddd; /* Light border around each item */
    border-radius: 8px; /* Rounded corners for items */
    margin-bottom: 15px; /* Space between items */
    background-color: #ffffff; /* White background for items */
    transition: transform 0.3s, box-shadow 0.3s; /* Smooth transition for effects */
}

/* Hover Effect for Result Items */
.search-results li:hover {
    transform: translateY(-2px); /* Lift effect on hover */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); /* Deeper shadow on hover */
}

/* Word Style */
.search-results .word {
    font-size: 2.5em; /* Larger font size for the word */
    font-weight: bold; /* Bold font for emphasis */
    color: #00ab66; /* Optional: Change color to match heading */
}

/* Meaning Section */
.meaning {
    font-style: italic; /* Italicize meaning text */
    color: #555; /* Gray color for meaning text */
}

#autocomplete-container {
    position: absolute;
    top: 130px; /* Adjust this to the height of your search bar */
    left: 50%;
    transform: translateX(-50%);
    background-color: white;
    border: 1px solid #ddd;
    border-radius: 5px;
    max-height: 200px;
    overflow-y: auto;
    width: 50%;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

.autocomplete-suggestion {
    padding: 10px;
    cursor: pointer;
}

.autocomplete-suggestion:hover {
    background-color: #f0f0f0;
}

    </style>
</head>
<body>
    <div class="searchbg">  
        <a href="index.php" class="back-arrow"><i class="fas fa-arrow-left"></i></a>
        <div class="search-container1">
<form id="search-form" method="GET">
    <div class="dropdown-container">
        <select id="category" name="category">
            <option value="all" <?php if ($category == 'all') echo 'selected'; ?>>All</option>
            <option value="words" <?php if ($category == 'words') echo 'selected'; ?>>Words</option>
            <option value="example" <?php if ($category == 'example') echo 'selected'; ?>>Examples</option>
            <option value="meaning" <?php if ($category == 'meaning') echo 'selected'; ?>>Meaning</option>
        </select>
        <i class="fas fa-caret-down dropdown-icon"></i>
    </div>
    <input type="text" id="search-input" name="query" placeholder="Search..." value="<?php echo htmlspecialchars($searchQuery); ?>">
    <button type="submit" id="search-button"><i class="fas fa-search"></i></button>
</form>
<div id="autocomplete-container"></div> <!-- Autocomplete suggestions container -->

        </div>
        <?php if ($errorMessage): ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
    </div>

    <div class="search-results">
    <?php if (!empty($searchResults)): ?>
        <h2>Search Results:</h2>
        <ul>
        <?php foreach ($searchResults as $result): ?>
    <li>
        <a href="word.php?id=<?php echo htmlspecialchars($result['id']); ?>" style="text-decoration: none; color: inherit;">
            <span class="word"><?php echo htmlspecialchars($result['word']); ?></span><br>
            
            <!-- Display the category of the word -->
            <strong style="color: grey;">Category:</strong> <span style="color: #B40023;"><?php echo htmlspecialchars($result['category_name']); ?></span><br>
            
            <strong style="color: grey;">Example 1:</strong> <span style="color: grey;"><?php echo htmlspecialchars($result['example1']); ?></span><br>
            <strong style="color: grey;">Example 2:</strong> <span style="color: grey;"><?php echo htmlspecialchars($result['example2']); ?></span><br>
            <strong style="color: grey;">Tagalog Meaning:</strong> <span style="color: grey;"><?php echo htmlspecialchars($result['tagalog_meaning']); ?></span><br>
            <strong style="color: grey;">English Meaning:</strong> <span style="color: grey;"><?php echo htmlspecialchars($result['english_meaning']); ?></span><br>
        </a>
    </li>
<?php endforeach; ?>

        </ul>
    <?php endif; ?>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $("#search-input").on("input", function() {
        var query = $(this).val(); // Get the value of the search input
        var category = $("#category").val(); // Get the selected category

        if (query.length >= 2) { // Trigger autocomplete after typing at least 2 characters
            $.ajax({
                url: 'autocomplete.php', // PHP script that returns the suggestions
                method: 'GET',
                data: { query: query, category: category },
                success: function(data) {
                    var suggestions = JSON.parse(data); // Parse the returned JSON data
                    var suggestionsHtml = '';

                    // Loop through suggestions and display them in a dropdown
                    if (suggestions.length > 0) {
                        suggestions.forEach(function(suggestion) {
                            suggestionsHtml += '<div class="autocomplete-suggestion">' + suggestion + '</div>';
                        });
                        $('#autocomplete-container').html(suggestionsHtml).show(); // Show the suggestions
                    } else {
                        $('#autocomplete-container').empty().hide(); // Hide the container if no suggestions
                    }
                }
            });
        } else {
            $('#autocomplete-container').empty().hide(); // Hide the container if query is too short
        }
    });

    // Handle suggestion click
    $(document).on("click", ".autocomplete-suggestion", function() {
        var selectedSuggestion = $(this).text();
        $('#search-input').val(selectedSuggestion); // Set input field to selected suggestion
        $('#autocomplete-container').empty().hide(); // Hide suggestions after selection
    });

    // Close suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest('#autocomplete-container, #search-input').length) {
            $('#autocomplete-container').empty().hide();
        }
    });
});
</script>


</body>
</html>
