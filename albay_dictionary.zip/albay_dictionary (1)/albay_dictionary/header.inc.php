<?php defined('APP') or die('direct script access denied!'); ?>

<header class="header-container">
    <div class="logo-container">
        <img src="bg/logo4.png" class="logo-image" alt="Logo">
    </div>
    <div class="nav-container">
        <!-- Navigation Links for all screen sizes -->
        <div id="nav-menu" class="nav-links">
            <a href="index.php" class="nav-item"><i class="fas fa-home"></i></a>
            <a href="categories.php" class="nav-item"><i class="fas fa-language"></i></a>
            <a href="new_forum.php" class="nav-item"><i class="fas fa-comments"></i></a>
        </div>
    </div>
</header>
