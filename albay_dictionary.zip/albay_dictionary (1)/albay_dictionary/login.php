<?php
require('config.inc.php');
require('functions.php');

// Check if the user is already logged in
if (logged_in()) {
    header('Location: available_quizzes.php'); // Redirect to quizzes page if already logged in
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <script src="scripts.js" defer></script>
</head>

<style>
		
		@keyframes appear{
			0%{
				opacity: 0;
			}
			100%{
				opacity: 1;
			}
		}

		.hide{
			display:none;
		}

	</style>
<body>
    <h1>Login</h1>
    <p>To access the quizzes, please log in:</p>
    <button onclick="login.show()">Login</button>
    
    <!-- Include your login modal here -->
    <?php include('login.inc.php'); ?>

    <!-- Include your signup modal here -->
    <?php include('signup.inc.php'); ?>
</body>
</html>
