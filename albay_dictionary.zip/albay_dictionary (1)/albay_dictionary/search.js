document.addEventListener('DOMContentLoaded', () => {
    const conversationInput = document.getElementById('conversationSearch');
    const accordionItems = document.querySelectorAll('.accordion-item'); // Select all accordion items
    const noConversationsMessage = document.getElementById('noConversationsMessage'); // Message for no results

    // Filter conversations based on input
    conversationInput.addEventListener('input', () => {
        const filter = conversationInput.value.toLowerCase();
        let hasVisible = false;

        accordionItems.forEach(item => {
            const phraseText = item.querySelector('.accordion-title h3').textContent.toLowerCase();
            if (phraseText.includes(filter)) {
                item.style.display = ''; // Show item
                hasVisible = true;
            } else {
                item.style.display = 'none'; // Hide item
            }
        });

        // Show message if no conversations are found
        noConversationsMessage.style.display = hasVisible ? 'none' : 'block';
    });
});


