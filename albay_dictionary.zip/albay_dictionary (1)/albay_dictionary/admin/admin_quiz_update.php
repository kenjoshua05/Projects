<?php
// Include necessary files
require_once 'functions.php';

// Establish database connection
$con = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quiz_id = $_POST['quiz_id'];
    $quiz_title = $_POST['quiz_title'];
    $questions = $_POST['questions'];
    $choices = $_POST['choices'];

    // Update quiz title
    $query = "UPDATE quizzes SET title = '$quiz_title' WHERE id = '$quiz_id'";
    mysqli_query($con, $query);

    // Update questions
    foreach ($questions as $question_id => $question_data) {
        $question_text = $question_data['text'];
        $query = "UPDATE questions SET text = '$question_text' WHERE id = '$question_id'";
        mysqli_query($con, $query);

        // Update choices
        if (isset($choices[$question_id])) {
            foreach ($choices[$question_id] as $choice_id => $choice_data) {
                $choice_text = $choice_data['text'];
                $is_correct = isset($choice_data['is_correct']) ? 1 : 0;
                $query = "UPDATE choices SET text = '$choice_text', is_correct = '$is_correct' WHERE id = '$choice_id'";
                mysqli_query($con, $query);
            }
        }
    }

    echo "Quiz updated successfully!";
}
?>
