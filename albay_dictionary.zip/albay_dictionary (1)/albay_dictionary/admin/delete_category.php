<?php
// Start the session
session_start();

// Include the functions.php file for database connection and functions
require_once 'functions.php';

// Establish database connection (assuming DB_HOST, DB_USER, DB_PASS, DB_NAME are defined in functions.php)
$con = db_connect(); // Function from functions.php to connect to database
if (!$con) {
    $_SESSION['error_message'] = "Failed to connect to database.";
    header('Location: display_categories.php');
    exit;
}

// Check if category ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "Category ID not provided.";
    header('Location: display_categories.php');
    exit;
}

// Sanitize category ID
$id = mysqli_real_escape_string($con, $_GET['id']);

// Delete associated records in common_conversations table
$query_common = "DELETE FROM common_conversations WHERE category_id='$id'";
$result_common = mysqli_query($con, $query_common);

// Delete associated records in dialect_data table
$query_dialect = "DELETE FROM dialect_data WHERE category_id='$id'";
$result_dialect = mysqli_query($con, $query_dialect);

// Delete the category from the categories table
$query = "DELETE FROM categories WHERE id='$id'";
$result = mysqli_query($con, $query);

if ($result) {
    $_SESSION['success_message'] = "Category deleted successfully.";
} else {
    $_SESSION['error_message'] = "Failed to delete category: " . mysqli_error($con);
}

// Close database connection
mysqli_close($con);

// Redirect back to categories display page
header('Location: display_categories.php');
exit;
?>
