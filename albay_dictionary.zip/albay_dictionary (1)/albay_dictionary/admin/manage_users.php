<?php
// Start session and include database connection
session_start();
require_once 'functions.php';

// Ensure the user is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

// Establish database connection
$con = db_connect();

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_query = "DELETE FROM users WHERE id = $delete_id";
    if (mysqli_query($con, $delete_query)) {
        header("Location: manage_users.php");
        exit;
    } else {
        die("Error deleting user: " . mysqli_error($con));
    }
}

// Pagination variables
$results_per_page = 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $results_per_page;

// Calculate total pages
$total_query = "SELECT COUNT(*) AS total FROM users";
$total_result = mysqli_query($con, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_users = $total_row['total'];
$total_pages = ceil($total_users / $results_per_page);

// Fetch users for the current page
$query = "SELECT * FROM users LIMIT $offset, $results_per_page";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Close connection before displaying the form
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin - Manage Users</title>
    <style>
        /* Add modern, responsive styles here */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .dashboard-arrow {
            position: relative; /* Use relative positioning */
            top: 0; /* Reset the top positioning */
            left: 0; /* Align to the left */
            font-size: 24px; /* Adjust the icon size */
            color: #007bff; /* Change the icon color */
            text-decoration: none; /* Remove underline */
            transition: color 0.3s;
            margin-bottom: 10px; /* Add space between the button and heading */
        }

        .dashboard-arrow:hover {
            color: #0056b3; /* Darker color on hover */
        }


        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .add-new {
            margin-bottom: 20px;
        }

        .add-new a.add-button {
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 14px;
            display: inline-block;
        }

        .add-new a.add-button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .no-results {
            text-align: center;
            padding: 20px;
            color: #777;
        }
                .table-wrapper {
            width: 100%;
            overflow-x: auto; /* Enables horizontal scrolling */
            margin-top: 20px;
        }

        .pagination {
            margin-top: 20px;
            text-align: center;
        }

        .pagination a {
            margin: 0 5px;
            padding: 8px 16px;
            text-decoration: none;
            color: #007bff;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .pagination a:hover {
            background-color: #f1f1f1;
        }

        .pagination .active {
            background-color: #007bff;
            color: #fff;
            border: 1px solid #007bff;
        }

        .admin-footer{
            margin-top:50px;
        }

        .admin-footer p{
            text-align:center;
        }
    </style>
</head>
<body>

<div class="container">
<a href="admin_dashboard.php" class="dashboard-arrow">
    <i class="fas fa-arrow-left"></i>
</a>

    <h1>Admin Panel - Manage Users</h1>
    <div class="table-wrapper">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Date Joined</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td class="actions">
                            <a href="view_user.php?id=<?php echo urlencode($row['id']); ?>"><i class="fas fa-eye"></i> View Records</a>
                            <a href="?delete_id=<?php echo urlencode($row['id']); ?>" onclick="return confirm('Are you sure you want to delete this user?')"><i class="fas fa-trash-alt"></i> Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="no-results">No users found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>

    <div class="pagination">
        <?php if ($page > 1) : ?>
            <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
            <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <?php if ($page < $total_pages) : ?>
            <a href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
        <?php endif; ?>
    </div>
</div>
    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
