<?php
// Include the functions.php file
require_once 'functions.php';

// Establish database connection
$con = db_connect();

// Get the quiz ID from the URL
$quiz_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch the quiz details from the database
$quiz_query = "SELECT * FROM quizzes WHERE id = $quiz_id";
$quiz_result = query($quiz_query);
$quiz = $quiz_result ? $quiz_result[0] : null;

// Fetch the questions and choices for the quiz
$questions_query = "SELECT * FROM questions WHERE quiz_id = $quiz_id";
$questions_result = query($questions_query);

$questions_with_choices = [];
if ($questions_result) {
    foreach ($questions_result as $question) {
        $question_id = $question['id'];
        $choices_query = "SELECT * FROM choices WHERE question_id = $question_id";
        $choices_result = query($choices_query);
        $question['choices'] = $choices_result;
        $questions_with_choices[] = $question;
    }
}

// Get categories for the dropdown
$categories_query = "SELECT * FROM categories";
$categories_result = query($categories_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update quiz details
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $category_id = (int)$_POST['category_id'];
    $max_attempts = (int)$_POST['max_attempts']; // Fetch the max_attempts value

    $update_quiz_query = "UPDATE quizzes SET title = '$title', description = '$description', category_id = $category_id, max_attempts = $max_attempts WHERE id = $quiz_id";
    mysqli_query($con, $update_quiz_query);

    // Update questions and choices
    foreach ($_POST['questions'] as $question_id => $question_data) {
        $question_text = mysqli_real_escape_string($con, $question_data['text']);
        mysqli_query($con, "UPDATE questions SET question_text = '$question_text' WHERE id = $question_id");

        // Get current choices for the question
        $current_choices_query = "SELECT * FROM choices WHERE question_id = $question_id";
        $current_choices_result = query($current_choices_query);
        $current_choice_ids = array_column($current_choices_result, 'id');

        foreach ($question_data['choices'] as $choice_id => $choice_data) {
            $choice_text = mysqli_real_escape_string($con, $choice_data['text']);
            $is_correct = ($choice_id == $question_data['correct_choice']) ? 1 : 0;

            if (in_array($choice_id, $current_choice_ids)) {
                // Update existing choice
                mysqli_query($con, "UPDATE choices SET choice_text = '$choice_text', is_correct = $is_correct WHERE id = $choice_id");
            } else {
                // Insert new choice
                $insert_choice_query = "INSERT INTO choices (question_id, choice_text, is_correct) VALUES ($question_id, '$choice_text', $is_correct)";
                mysqli_query($con, $insert_choice_query);
            }
        }

        // Remove choices that are no longer in the form
        $remaining_choice_ids = array_diff($current_choice_ids, array_keys($question_data['choices']));
        foreach ($remaining_choice_ids as $remaining_choice_id) {
            mysqli_query($con, "DELETE FROM choices WHERE id = $remaining_choice_id");
        }
    }

    db_close($con); // Close the database connection after processing

    // Redirect to the quiz list page after updating
    header("Location: admin_quiz_list.php?message=update_successful");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Quiz</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }
        form {
            width: 60%;
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        label {
            font-weight: 500;
            margin-bottom: 5px;
            display: block;
        }
        input[type="text"], input[type="number"], textarea, select {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 15px;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        .question {
            margin-bottom: 20px;
        }
        .choice {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }
        .choice input[type="text"] {
            flex: 1;
            margin-right: 10px;
        }
        .choice label {
            margin-bottom: 0;
        }
        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        .admin-footer{
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Edit Quiz</h1>
    <form method="POST">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($quiz['title']); ?>" required>
        
        <label for="description">Description:</label>
        <textarea name="description" id="description"><?php echo htmlspecialchars($quiz['description']); ?></textarea>
        
        <label for="category_id">Category:</label>
        <select name="category_id" id="category_id">
            <?php foreach ($categories_result as $category) : ?>
                <option value="<?php echo htmlspecialchars($category['id']); ?>" <?php echo ($category['id'] == $quiz['category_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="max_attempts">Max Attempts:</label>
        <input type="number" name="max_attempts" id="max_attempts" value="<?php echo htmlspecialchars($quiz['max_attempts']); ?>" required>

        <h2>Questions</h2>
        <?php foreach ($questions_with_choices as $question) : ?>
            <div class="question">
                <label for="question_<?php echo $question['id']; ?>">Question:</label>
                <input type="text" name="questions[<?php echo $question['id']; ?>][text]" id="question_<?php echo $question['id']; ?>" value="<?php echo htmlspecialchars($question['question_text']); ?>" required>
                
                <h3>Choices</h3>
                <?php foreach ($question['choices'] as $choice) : ?>
                    <div class="choice">
                        <input type="text" name="questions[<?php echo $question['id']; ?>][choices][<?php echo $choice['id']; ?>][text]" value="<?php echo htmlspecialchars($choice['choice_text']); ?>" required>
                        <label>
                            <input type="radio" name="questions[<?php echo $question['id']; ?>][correct_choice]" value="<?php echo $choice['id']; ?>" <?php echo $choice['is_correct'] ? 'checked' : ''; ?>>
                            Correct
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
        
        <button type="submit">Update Quiz</button>
    </form>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
