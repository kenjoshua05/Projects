<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
    } else {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $con = db_connect();

        $query = "INSERT INTO admins (username, password_hash) VALUES ('" . mysqli_real_escape_string($con, $username) . "', '$password_hash')";
        if (mysqli_query($con, $query)) {
            echo "Registration successful. <a href='admin_login.php'>Login here</a>";
        } else {
            echo "Error: " . mysqli_error($con);
        }

        db_close($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .register-form {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .register-form h2 {
            margin-bottom: 20px;
        }

        .register-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .register-form button {
            width: 100%;
            padding: 10px;
            background: #B40023;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .register-form button:hover {
            background: #90001a;
        }

        .register-form a {
            text-align: center;
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form class="register-form" action="admin_register.php" method="POST">
        <h2>Admin Registration</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit">Register</button>
        <a href="admin_login.php">Already have an account? Login here</a>
    </form>
</body>
</html>
