<?php
// Start the session
session_start();

// Include the functions.php file for database connection
require_once 'functions.php';

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Establish database connection
$con = db_connect();

// Initialize pagination variables
$results_per_page = 10; // Number of results per page
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($current_page - 1) * $results_per_page;

// Initialize variables for sorting and searching
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'id'; // Default sort by ID
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC'; // Default order ASC
$search_word = isset($_GET['search_word']) ? $_GET['search_word'] : ''; // Search keyword

// Fetch all data from the quizzes table including category information
$query = "SELECT q.*, c.name AS category_name 
          FROM quizzes q 
          LEFT JOIN categories c ON q.category_id = c.id";

// Check if category filter is applied
if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $category_id = mysqli_real_escape_string($con, $_GET['category_id']);
    $query .= " WHERE q.category_id = '$category_id'";
}

// Add search filter if search keyword is provided
if (!empty($search_word)) {
    $search_word = mysqli_real_escape_string($con, $search_word);
    if (strpos($query, 'WHERE') === false) {
        $query .= " WHERE q.title LIKE '%$search_word%'";
    } else {
        $query .= " AND q.title LIKE '%$search_word%'";
    }
}

// Add sorting to the query
$query .= " ORDER BY $sort $order";

// Get the total number of results
$result_total = mysqli_query($con, $query);
$total_results = mysqli_num_rows($result_total);

// Add pagination limit
$query .= " LIMIT $start_from, $results_per_page";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Check if there are no results
$num_rows = mysqli_num_rows($result);

// Fetch categories for the dropdown
$categories_query = "SELECT id, name FROM categories";
$categories_result = mysqli_query($con, $categories_query);

// Check if a message is set in the session
if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success">' . $_SESSION['message'] . '</div>';
    unset($_SESSION['message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9f9f9;
    color: #333;
    margin: 0;
    padding: 20px;
}

h1 {
    color: #222;
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 600;
}

.search-controls, .sorting-controls {
    margin-bottom: 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.search-controls label, .sorting-controls label {
    margin-right: 10px;
    font-weight: 500;
}

.search-controls input[type="text"], 
.sorting-controls select, 
.search-controls select {
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.search-controls input[type="submit"], 
.sorting-controls input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 14px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.search-controls input[type="submit"]:hover, 
.sorting-controls input[type="submit"]:hover {
    background-color: #0056b3;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background-color: #fff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 15px;
    text-align: left;
    border: 1px solid #ddd;
}

th {
    background-color: #f4f4f4;
    font-weight: 500;
    color: #555;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

.no-results {
    text-align: center;
    color: red;
    font-style: italic;
}
.alert-success {
            color: green;
            text-align: center;
            border: 1px solid green;
            background-color: #d4edda;
            padding: 10px;
            margin: 10px auto;
            width: 50%;
            border-radius: 5px;
        }

.actions a {
    margin-right: 10px;
    color: #007bff;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;
}

.actions a:hover {
    color: #0056b3;
}

.pagination-controls {
    margin-top: 20px;
    text-align: center;
}

.pagination-controls a {
    display: inline-block;
    margin: 0 5px;
    padding: 10px 15px;
    background-color: #007bff;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 14px;
    transition: background-color 0.3s;
}

.pagination-controls a:hover {
    background-color: #0056b3;
}

.pagination-controls a.active {
    background-color: #0056b3;
    pointer-events: none;
}

.add-button {
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: 500;
    transition: background-color 0.3s;
}

.add-button:hover {
    background-color: #0056b3;
}

.admin-section a.add-button {
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 14px;
            display: inline-block;
            margin-bottom: 20px;
        }

        .admin-section a.add-button:hover {
            background-color: #0056b3;
        }
                
        .dashboard-button-fixed {
            position: fixed;
            top: 10%;
            right: 20px;
            transform: translateY(-50%);
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #6495ed;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
        }

        .dashboard-button-fixed i {
            margin-right: 10px;
            font-size: 18px;
        }

        .dashboard-button-fixed:hover {
            background-color: #365eaa;
            transform: scale(1.05);
        }

        .dashboard-button-fixed:active {
            transform: translateY(2px);
        }
        .admin-footer{
            text-align: center;
        }
    </style>
</head>
<body>
<a href="admin_dashboard.php" class="dashboard-button-fixed">
        <i class="fas fa-tachometer-alt"></i>
        Go to Dashboard
    </a>

    <h1>Quiz List</h1>

    <!-- Search controls -->
    <div class="search-controls">
        <form action="admin_quiz_list.php" method="get">
            <label for="search_word">Search by Title:</label>
            <input type="text" name="search_word" id="search_word" value="<?php echo htmlspecialchars($search_word); ?>">
            <input type="submit" value="Search">
        </form>
    </div>

    <!-- Sorting controls -->
    <div class="sorting-controls">
        <form action="admin_quiz_list.php" method="get">
            <label for="sort">Sort by:</label>
            <select name="sort" id="sort">
                <option value="id" <?php echo ($sort === 'id') ? 'selected' : ''; ?>>ID</option>
                <option value="title" <?php echo ($sort === 'title') ? 'selected' : ''; ?>>Title</option>
                <option value="category_name" <?php echo ($sort === 'category_name') ? 'selected' : ''; ?>>Category</option>
            </select>
            <label for="order">Order:</label>
            <select name="order" id="order">
                <option value="ASC" <?php echo ($order === 'ASC') ? 'selected' : ''; ?>>Ascending</option>
                <option value="DESC" <?php echo ($order === 'DESC') ? 'selected' : ''; ?>>Descending</option>
            </select>
            <input type="submit" value="Apply Sorting">
        </form>
    </div>
<!-- Button to add new quiz -->
<div class="add-new">
<a href="admin_quiz_create.php" class="add-button"><i class="fas fa-plus"></i> Add New Quiz</a>
    </div>
    <!-- Table displaying quizzes -->
    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Actions</th>
        </tr>
        <?php if ($num_rows === 0) : ?>
            <tr>
                <td colspan="4" class="no-results">No results found.</td>
            </tr>
        <?php else : ?>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                    <td class="actions">
                        <a href="admin_quiz_edit.php?id=<?php echo $row['id']; ?>" title="Edit">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="admin_quiz_delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this data?');" title="Delete">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    </td>

                </tr>
            <?php endwhile; ?>
        <?php endif; ?>
    </table>

    <!-- Pagination controls -->
    <div class="pagination-controls">
        <?php if ($total_results > $results_per_page) : ?>
            <?php for ($page = 1; $page <= ceil($total_results / $results_per_page); $page++) : ?>
                <a href="admin_quiz_list.php?page=<?php echo $page; ?>&sort=<?php echo $sort; ?>&order=<?php echo $order; ?>&search_word=<?php echo urlencode($search_word); ?>" class="<?php echo ($page === $current_page) ? 'active' : ''; ?>"><?php echo $page; ?></a>
            <?php endfor; ?>
        <?php endif; ?>
    </div>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

</body>
</html>

<?php
// Close the database connection
mysqli_close($con);
?>
