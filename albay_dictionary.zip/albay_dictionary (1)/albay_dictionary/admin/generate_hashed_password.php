<?php
// Function to hash passwords
function hash_password($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Generate hashed password for "1admin"
$hashed_password = hash_password('1admin');
echo "Hashed Password: " . $hashed_password . "\n";
?>
