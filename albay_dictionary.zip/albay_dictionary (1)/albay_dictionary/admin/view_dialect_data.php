<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Dialect Data</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>

        /* Global Styles */
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9fafb; /* Slightly lighter background */
    color: #333;
}

.container {
            max-width: 900px;
            margin: auto;
            margin-top: 20px;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

/* Form Styles */
form {
    max-width: 800px;
    margin: 30px auto;
    padding: 30px; /* Increased padding for a more spacious feel */
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border: 1px solid #e0e0e0;
    transition: box-shadow 0.3s ease-in-out;
}

/* Spacing for Form Elements */
div {
    margin-bottom: 25px; /* Increased spacing for clarity */
}

/* Label Styles */
label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #555;
}

/* Input and Textarea Styles */
input[type="text"],
textarea,
select {
    width: 100%;
    padding: 14px;
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus,
textarea:focus,
select:focus {
    border-color: #007bff; /* Keep the focus color */
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
}

/* Textarea Resizing */
textarea {
    resize: vertical; /* Allow vertical resizing */
}

/* Message Styles */
.message {
    margin: 20px auto;
    max-width: 800px;
    padding: 15px;
    border-radius: 8px;
    color: #fff;
    font-weight: 500;
    text-align: center;
    background-color: #dc3545; /* Error message color */
}

/* Hover Effects for Inputs */
input[type="text"],
textarea,
select {
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:hover,
textarea:hover,
select:hover {
    border-color: #007bff; /* Change border color on hover */
}

/* Media Queries for Responsive Design */
@media (max-width: 768px) {
    h1 {
        font-size: 2rem; /* Adjust header size for smaller screens */
    }

    form {
        padding: 20px; /* Adjust form padding for smaller screens */
    }
}

.dashboard-arrow {
    position: relative;
    top: 0;
    left: 0;
    font-size: 24px;
    color: #007bff;
    text-decoration: none;
    transition: color 0.3s;
    padding-bottom: 30px;
    margin-bottom: 20px; /* Add space below the arrow */
}


        .dashboard-arrow:hover {
            color: #0056b3; /* Darker color on hover */
        }
        form > div:first-child {
    padding-top: 20px; /* Add space above the form content */
}


    </style>
</head>
<body>
    <?php
    // Start the session
    session_start();

    // Include the functions.php file for database connection
    require_once 'functions.php';

    if (!isset($_SESSION['ADMIN'])) {
        header("Location: admin_login.php");
        exit;
    }
    
    // Establish database connection (assuming DB_HOST, DB_USER, DB_PASS, DB_NAME are defined in functions.php)
    $con = db_connect(); // Function from functions.php to connect to database
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch the data for the given id
    if (!isset($_GET['id'])) {
        header('Location: display_dialect_data.php');
        exit;
    }

    $id = mysqli_real_escape_string($con, $_GET['id']);

    $query = "SELECT * FROM dialect_data WHERE id='$id'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($con));
    }

    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        header('Location: display_dialect_data.php');
        exit;
    }

    // Fetch all categories from the categories table
$query_categories = "SELECT id, name FROM categories";
$result_categories = mysqli_query($con, $query_categories);

if (!$result_categories) {
    die("Query failed: " . mysqli_error($con));
}

// Fetch the category name based on the category_id
$category_id = $data['category_id'];
$query_category_name = "SELECT name FROM categories WHERE id='$category_id'";
$result_category_name = mysqli_query($con, $query_category_name);

if ($result_category_name) {
    $category = mysqli_fetch_assoc($result_category_name);
    $category_name = $category ? $category['name'] : 'Unknown Category'; // Handle case if category is not found
} else {
    $category_name = 'Error fetching category name';
}
    ?>
    <div class="container">
        <a href="display_dialect_data.php" class="dashboard-arrow">
                <i class="fas fa-arrow-left"></i>
        </a>
        
        <form>
        <div>
            <label for="word">Word:</label>
            <input type="text" name="word" id="word" value="<?php echo htmlspecialchars($data['word']); ?>" readonly>
        </div>
        <div>
            <label for="pronunciation">Pronunciation:</label>
            <textarea name="pronunciation" id="pronunciation" readonly><?php echo htmlspecialchars($data['pronunciation']); ?></textarea>
        </div>
        <div>
            <label for="example1">Example 1 (Dialect):</label>
            <textarea name="example1" id="example1" readonly><?php echo htmlspecialchars($data['example1']); ?></textarea>
        </div>
        <div>
            <label for="example1_tagalog">Example 1 (Tagalog):</label>
            <textarea name="example1_tagalog" id="example1_tagalog" readonly><?php echo htmlspecialchars($data['example1_tagalog']); ?></textarea>
        </div>
        <div>
            <label for="example1_english">Example 1 (English):</label>
            <textarea name="example1_english" id="example1_english" readonly><?php echo htmlspecialchars($data['example1_english']); ?></textarea>
        </div>
        <div>
            <label for="example2">Example 2 (Dialect):</label>
            <textarea name="example2" id="example2" readonly><?php echo htmlspecialchars($data['example2']); ?></textarea>
        </div>
        <div>
            <label for="example2_tagalog">Example 2 (Tagalog):</label>
            <textarea name="example2_tagalog" id="example2_tagalog" readonly><?php echo htmlspecialchars($data['example2_tagalog']); ?></textarea>
        </div>
        <div>
            <label for="example2_english">Example 2 (English):</label>
            <textarea name="example2_english" id="example2_english" readonly><?php echo htmlspecialchars($data['example2_english']); ?></textarea>
        </div>
        <div>
            <label for="tagalog_meaning">Tagalog Meaning:</label>
            <textarea name="tagalog_meaning" id="tagalog_meaning" readonly><?php echo htmlspecialchars($data['tagalog_meaning']); ?></textarea>
        </div>
        <div>
            <label for="english_meaning">English Meaning:</label>
            <textarea name="english_meaning" id="english_meaning" readonly><?php echo htmlspecialchars($data['english_meaning']); ?></textarea>
        </div>
        <div>
            <label for="category_name">Category:</label>
            <input type="text" name="category_name" id="category_name" value="<?php echo htmlspecialchars($category_name); ?>" readonly>
        </div>
        <div>
        <p>Audio File:</p>
    <audio controls>
        <source src="<?php echo htmlspecialchars($data['audio_file']); ?>" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>

        </div>
    </form>
</div>
</body>
</html>
