<?php
session_start();
require_once 'functions.php'; // Include functions.php for centralized functionality

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $con = db_connect(); // Establish database connection

    // Handle form fields
    $category = mysqli_real_escape_string($con, $_POST['category']);

    // Insert data into the database
    $query = "INSERT INTO categories (name) VALUES ('$category')";
    if (mysqli_query($con, $query)) {
        $_SESSION['success_message'] = "Category uploaded successfully.";
    } else {
        $_SESSION['error_message'] = "Failed to upload category: " . mysqli_error($con);
    }

    db_close($con); // Close database connection
}

// Redirect back to the display page
header('Location: display_categories.php');
exit;
?>
