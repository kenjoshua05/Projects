<?php
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
            text-align: center;
        }

        form {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        fieldset {
            border: none;
            margin-bottom: 20px;
            padding: 0;
        }

        legend {
            font-size: 18px;
            margin-bottom: 10px;
            color: #B40023;
            border-bottom: 2px solid #B40023;
            padding-bottom: 5px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        input[type="text"], input[type="number"], textarea, select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        .choices {
            margin-top: 10px;
        }

        .choice-container {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .choice-container input[type="text"] {
            flex: 1;
        }

        .choice-container input[type="radio"] {
            margin-right: 5px;
        }

        .remove-button {
            background-color: #ff6b6b;
            color: #fff;
            border: none;
            padding: 5px 10px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
            margin-left: 10px;
        }

        .remove-button:hover {
            background-color: #ff4757;
        }

        button {
            background-color: #87CEEB; /* Sky blue */
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
            margin-right: 10px;
            display: inline-block;
        }

        button:hover {
            background-color: #00BFFF; /* Deep sky blue */
        }

        .add-button {
            margin-top: 10px;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            padding: 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .back-link:hover {
            background-color: #007bff;
            color: #fff;
        }
        .admin-footer{
            text-align: center;
        }
    </style>
    <script>
        let questionCounter = 1;

        function addChoice(questionId) {
            const questionContainer = document.getElementById(`question_${questionId}`);
            const choicesContainer = questionContainer.querySelector('.choices');
            const choiceCount = choicesContainer.querySelectorAll('.choice-container').length + 1;

            const newChoiceHtml = `
                <div class="choice-container">
                    <input type="text" name="questions[${questionId}][choices][]" required>
                    <input type="radio" name="questions[${questionId}][correct_choice]" value="${choiceCount - 1}"> Correct
                    <button type="button" class="remove-button" onclick="removeChoice(this)">Remove Choice</button>
                </div>
            `;
            choicesContainer.insertAdjacentHTML('beforeend', newChoiceHtml);
        }

        function removeChoice(button) {
            const choiceContainer = button.parentElement;
            choiceContainer.remove();
        }

        function addQuestion() {
            questionCounter++;
            const questionsContainer = document.getElementById('questions_container');
            const newQuestionHtml = `
                <div class="question" id="question_${questionCounter}">
                    <label for="question_text_${questionCounter}">Question ${questionCounter}:</label>
                    <input type="text" id="question_text_${questionCounter}" name="questions[${questionCounter}][text]" required>
                    <div class="choices">
                        <label>Choices:</label>
                        <div class="choice-container">
                            <input type="text" name="questions[${questionCounter}][choices][]" required>
                            <input type="radio" name="questions[${questionCounter}][correct_choice]" value="0"> Correct
                        </div>
                        <div class="choice-container">
                            <input type="text" name="questions[${questionCounter}][choices][]" required>
                            <input type="radio" name="questions[${questionCounter}][correct_choice]" value="1"> Correct
                        </div>
                        <div class="choice-container">
                            <input type="text" name="questions[${questionCounter}][choices][]" required>
                            <input type="radio" name="questions[${questionCounter}][correct_choice]" value="2"> Correct
                        </div>
                        <div class="choice-container">
                            <input type="text" name="questions[${questionCounter}][choices][]" required>
                            <input type="radio" name="questions[${questionCounter}][correct_choice]" value="3"> Correct
                        </div>
                    </div>
                    <button type="button" class="add-button" onclick="addChoice(${questionCounter})">Add Choice</button>
                    <button type="button" class="remove-button" onclick="removeQuestion(this)">Remove Question</button>
                </div>
            `;
            questionsContainer.insertAdjacentHTML('beforeend', newQuestionHtml);
        }

        function removeQuestion(button) {
            const questionContainer = button.parentElement;
            questionContainer.remove();
        }
    </script>
</head>
<body>
    <h1>Create a New Quiz</h1>
    <form action="admin_quiz_process.php" method="post">
        <fieldset>
            <legend>Quiz Information</legend>
            <label for="title">Quiz Title:</label>
            <input type="text" id="title" name="title" required>
            <label for="description">Description:</label>
            <textarea id="description" name="description"></textarea>
            <label for="category">Category:</label>
            <select id="category" name="category" required>
                <?php
                include 'functions.php';
                $categories = query("SELECT id, name FROM categories");
                foreach ($categories as $category) {
                    echo "<option value='{$category['id']}'>{$category['name']}</option>";
                }
                ?>
            </select>
            <label for="max_attempts">Maximum Attempts:</label>
            <input type="number" id="max_attempts" name="max_attempts" min="1" value="1" required>
        </fieldset>
        <fieldset id="questions_container">
            <legend>Questions</legend>
            <div class="question" id="question_1">
                <label for="question_text_1">Question 1:</label>
                <input type="text" id="question_text_1" name="questions[1][text]" required>
                <div class="choices">
                    <label>Choices:</label>
                    <div class="choice-container">
                        <input type="text" name="questions[1][choices][]" required>
                        <input type="radio" name="questions[1][correct_choice]" value="0"> Correct
                    </div>
                    <div class="choice-container">
                        <input type="text" name="questions[1][choices][]" required>
                        <input type="radio" name="questions[1][correct_choice]" value="1"> Correct
                    </div>
                    <div class="choice-container">
                        <input type="text" name="questions[1][choices][]" required>
                        <input type="radio" name="questions[1][correct_choice]" value="2"> Correct
                    </div>
                    <div class="choice-container">
                        <input type="text" name="questions[1][choices][]" required>
                        <input type="radio" name="questions[1][correct_choice]" value="3"> Correct
                    </div>
                </div>
                <button type="button" class="add-button" onclick="addChoice(1)">Add Choice</button>
                <button type="button" class="remove-button" onclick="removeQuestion(this)">Remove Question</button>
            </div>
        </fieldset>
        <button type="button" id="add_question" class="add-button" onclick="addQuestion()">Add Question</button>
        <button type="submit">Submit Quiz</button>
    </form>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>
</body>
</html>
