<?php
require_once 'functions.php';
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);

    // Handle file upload
    $profileImagePath = $admin['profile_image'];

    if (!empty($_FILES['profile_image']['name'])) {
        $targetDir = "profile_pics/";
        $targetFile = $targetDir . basename($_FILES['profile_image']['name']);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        
        // Check if the file is an actual image
        $check = getimagesize($_FILES['profile_image']['tmp_name']);
        if ($check !== false) {
            // Save the new profile picture
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFile)) {
                $profileImagePath = $targetFile; // Update path
            }
        }
    }

    // Update username and profile image in the database
    $adminId = $admin['id'];
    $stmt = $pdo->prepare("UPDATE admins SET username = ?, profile_image = ? WHERE id = ?");
    $stmt->execute([$username, $profileImagePath, $adminId]);

    // Update session data
    $_SESSION['ADMIN']['username'] = $username;
    $_SESSION['ADMIN']['profile_image'] = $profileImagePath;

    header("Location: admin_profile.php?status=success");
    exit;
}
?>
