<?php
// Database connection parameters
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'myforum_db');

// Function to establish database connection
function db_connect() {
    $con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $con;
}

// Function to close database connection
function db_close($con) {
    mysqli_close($con);
}

// Function to authenticate admin
function authenticate($row) {
    session_start();
    $_SESSION['ADMIN'] = $row; // Store admin data in session
}

// Function to query database
function query($query) {
    $con = db_connect(); // Establish database connection

    $result = mysqli_query($con, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }

        db_close($con); // Close database connection
        return $data;
    }

    db_close($con); // Close database connection
    return false;
}

// Function to verify admin credentials
function verify_admin($username, $password) {
    $con = db_connect(); // Establish database connection

    $query = "SELECT * FROM admins WHERE username = '" . mysqli_real_escape_string($con, $username) . "' LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);
        if (password_verify($password, $admin['password_hash'])) {
            db_close($con); // Close database connection
            return $admin; // Return admin data if verified
        }
    }

    db_close($con); // Close database connection
    return false;
}


// Function to fetch categories
function fetch_categories() {
    $query = "SELECT id, name FROM categories";
    return query($query); // Use the existing query function to fetch data
}
?>
