<?php
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Upload Category</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css"> <!-- Link to your external CSS file -->
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .admin-section {
            margin-top:100px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 60%;
            max-width: 600px; /* Optional: maximum width for large screens */
            margin-bottom: auto;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: 500;
            margin-bottom: 5px;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
            align-self: flex-start;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        .admin-footer {
            margin-top: auto;
            padding: 10px 0;
            background-color: #f9f9f9;
            width: 100%;
            text-align: center;
        }

        .admin-footer p {
            margin: 0;
            color: #666;
        }
    </style>
</head>
<body>
    <section class="admin-section">
        <h1>Admin Panel - Upload Category</h1>
        <form action="admin_process_category.php" method="post">
            <div>
                <label for="category">Category Name:</label>
                <input type="text" name="category" id="category" required>
            </div>
            <div>
                <input type="submit" value="Upload">
            </div>
        </form>
    </section>

    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
    </footer>
</body>
</html>
