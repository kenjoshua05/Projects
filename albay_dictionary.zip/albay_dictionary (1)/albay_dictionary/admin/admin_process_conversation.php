<?php
session_start();
require_once 'functions.php'; // Include functions for database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $con = db_connect(); // Use the reusable db_connect function

    // Sanitize and assign form fields
    $category_id = !empty($_POST['category_id']) ? mysqli_real_escape_string($con, trim($_POST['category_id'])) : null;
    $phrase = !empty($_POST['phrase']) ? mysqli_real_escape_string($con, trim($_POST['phrase'])) : null;
    $example = !empty($_POST['example']) ? mysqli_real_escape_string($con, trim($_POST['example'])) : null;

    // Ensure required fields are not empty
    if ($category_id && $phrase && $example) {
        // Insert data into the database
        $query = "INSERT INTO common_conversations (category_id, phrase, example) VALUES ('$category_id', '$phrase', '$example')";
        if (mysqli_query($con, $query)) {
            $_SESSION['success_message'] = "Conversation uploaded successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to upload conversation: " . mysqli_error($con);
        }
    } else {
        $_SESSION['error_message'] = "Please fill in all required fields.";
    }

    db_close($con); // Close the database connection
}

// Redirect back to the upload page
header('Location: display_common_conversations.php');
exit;
?>
