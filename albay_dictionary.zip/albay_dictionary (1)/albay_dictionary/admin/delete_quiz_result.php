<?php
require('functions.php');

// Check if ID is set
if (isset($_GET['id'])) {
    $result_id = (int)$_GET['id'];

    // Function to delete a result by ID
    function delete_result($result_id) {
        $con = db_connect(); // Establish database connection
        $query = "DELETE FROM user_quiz_results WHERE id = $result_id";
        $result = mysqli_query($con, $query);
        db_close($con); // Close database connection

        return $result;
    }

    // Perform delete operation
    if (delete_result($result_id)) {
        header('Location: admin_quiz_results.php'); // Redirect back to results page
        exit;
    } else {
        echo "Error deleting result.";
    }
} else {
    echo "No result ID specified.";
}
?>
