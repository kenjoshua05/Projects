<?php
// Start session and include database connection
session_start();
require_once 'functions.php';

// Ensure the user is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

// Establish database connection
$con = db_connect();

// Fetch all admins from the database
$query = "SELECT * FROM admins";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_query = "DELETE FROM admins WHERE id = $delete_id";
    if (mysqli_query($con, $delete_query)) {
        header("Location: manage_admins.php");
        exit;
    } else {
        die("Error deleting admin: " . mysqli_error($con));
    }
}

// Close the database connection
mysqli_close($con);

// Get the number of rows in the result set
$num_rows = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin - Manage Admins</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .dashboard-arrow {
            position: relative; /* Use relative positioning */
            top: 0; /* Reset the top positioning */
            left: 0; /* Align to the left */
            font-size: 24px; /* Adjust the icon size */
            color: #007bff; /* Change the icon color */
            text-decoration: none; /* Remove underline */
            transition: color 0.3s;
            margin-bottom: 10px; /* Add space between the button and heading */
        }

        .dashboard-arrow:hover {
            color: #0056b3; /* Darker color on hover */
        }


        h1 {
            color: #222;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .add-new {
            margin-bottom: 20px;
        }

        .add-new a.add-button {
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 14px;
            display: inline-block;
        }

        .add-new a.add-button:hover {
            background-color: #0056b3;
        }

        .search-bar {
            margin-bottom: 20px;
        }

        .search-bar input {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 100%;
            max-width: 300px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 500;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .actions a:hover {
            color: #0056b3;
        }

        .no-results {
            text-align: center;
            padding: 20px;
            color: #777;
            font-style: italic;
        }
        .admin-footer{
            margin-top:50px;
        }

        .admin-footer p{
            text-align:center;
        }
    </style>
</head>
<body>
   
    <div class="container">
    <a href="admin_dashboard.php" class="dashboard-arrow">
        <i class="fas fa-arrow-left"></i>
    </a>
    <h1>Admin Panel - Manage Admins</h1>
    <div class="add-new">
        <a href="add_admin.php" class="add-button"><i class="fas fa-user-plus"></i> Add New Admin</a>
    </div>
    <div class="search-bar">
        <input type="text" id="search" placeholder="Search by username..." onkeyup="searchAdmins()">
    </div>
    <table id="admins-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($num_rows > 0) : ?>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td class="actions">
                            
                            <a href="?delete_id=<?php echo urlencode($row['id']); ?>" onclick="return confirm('Are you sure you want to delete this admin?')"><i class="fas fa-trash-alt"></i> Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" class="no-results">No results found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    </div>

    <footer class="admin-footer">
    <p>&copy; <?php echo date('Y'); ?> Albay Dialects. All rights reserved.</p>
</footer>

    <script>
        function searchAdmins() {
            const input = document.getElementById('search');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('admins-table');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) {
                let td = tr[i].getElementsByTagName('td')[1];
                if (td) {
                    let textValue = td.textContent || td.innerText;
                    if (textValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }       
            }
        }
    </script>
</body>
</html>
