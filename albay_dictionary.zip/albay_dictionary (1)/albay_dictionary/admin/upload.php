<?php
session_start();

// Include functions.php for database connection and utilities
require_once 'functions.php';

// Ensure admin is logged in
if (!isset($_SESSION['ADMIN'])) {
    header("Location: admin_login.php");
    exit;
}

$admin = $_SESSION['ADMIN'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    // Establish database connection using a reusable function
    $con = db_connect();

    // Sanitize and retrieve form inputs
    $dialect = mysqli_real_escape_string($con, $_POST['dialect']);
    $word = mysqli_real_escape_string($con, $_POST['word']);
    $antonym = mysqli_real_escape_string($con, $_POST['antonym']);
    $pronunciation = mysqli_real_escape_string($con, $_POST['pronunciation']);
    $example1 = mysqli_real_escape_string($con, $_POST['example1']);
    $example1_tagalog = mysqli_real_escape_string($con, $_POST['example1_tagalog']);
    $example1_english = mysqli_real_escape_string($con, $_POST['example1_english']);
    $example2 = mysqli_real_escape_string($con, $_POST['example2']);
    $example2_tagalog = mysqli_real_escape_string($con, $_POST['example2_tagalog']);
    $example2_english = mysqli_real_escape_string($con, $_POST['example2_english']);
    $tagalog_meaning = mysqli_real_escape_string($con, $_POST['tagalog_meaning']);
    $english_meaning = mysqli_real_escape_string($con, $_POST['english_meaning']);

    // Handle file upload
    $audio_path = '';
    if (isset($_FILES['audio']) && $_FILES['audio']['error'] === UPLOAD_ERR_OK) {
        $audio_tmp_name = $_FILES['audio']['tmp_name'];
        $audio_name = uniqid() . '_' . basename($_FILES['audio']['name']); // Generate unique name for the file
        $audio_path = 'uploads/' . $audio_name;

        if (!move_uploaded_file($audio_tmp_name, $audio_path)) {
            $_SESSION['error_message'] = "Failed to upload audio file. Check directory permissions.";
            header('Location: upload_form.php');
            exit;
        }
    } else {
        $error_message = "Failed to upload audio file.";
        if (isset($_FILES['audio']['error'])) {
            $error_message .= " Error code: " . $_FILES['audio']['error'];
        }
        $_SESSION['error_message'] = $error_message;
        header('Location: upload_form.php');
        exit;
    }

    // Prepare and execute the insert query
    $query = "INSERT INTO dialect_data (dialect, word, antonym, pronunciation, example1, example1_tagalog, example1_english, example2, example2_tagalog, example2_english, tagalog_meaning, english_meaning, audio_path) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $con->prepare($query);
    $stmt->bind_param(
        "sssssssssssss", 
        $dialect, $word, $antonym, $pronunciation, $example1, $example1_tagalog, $example1_english, $example2, $example2_tagalog, $example2_english, $tagalog_meaning, $english_meaning, $audio_path
    );

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Data uploaded successfully.";
    } else {
        $_SESSION['error_message'] = "Failed to upload data: " . $stmt->error;
    }

    // Close database connection and redirect
    $stmt->close();
    db_close($con);
    header('Location: upload_form.php');
    exit;
} else {
    // Redirect if form is not submitted properly
    header('Location: upload_form.php');
    exit;
}
?>
