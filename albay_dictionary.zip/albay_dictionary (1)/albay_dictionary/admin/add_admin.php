<?php
require_once 'functions.php';
session_start();

if (!isset($_SESSION['ADMIN'])) {
    header("Location:admin_login.php");
    exit;
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check password length
    if (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters long.";
    } else {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        $con = db_connect();

        $query = "SELECT * FROM admins WHERE username = '$username'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) > 0) {
            $error_message = "Username already exists. Please choose a different username.";
        } else {
            $query = "INSERT INTO admins (username, password_hash) VALUES ('$username', '$password_hash')";
            if (mysqli_query($con, $query)) {
                $success_message = "New admin registered successfully!";
            } else {
                $error_message = "Error: " . mysqli_error($con);
            }
        }

        db_close($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .register-container {
            background: white;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: #333;
            text-decoration: none;
            transition: color 0.3s;
        }

        .back-button:hover {
            color: #5a9eff;
        }

        .register-container h2 {
            margin-bottom: 20px;
            color: #333;
            font-size: 22px;
            text-align: center;
        }

        .input-group {
            margin-bottom: 15px;
            position: relative;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
        }

        .input-group input:focus {
            border-color: #5a9eff;
        }

        .input-group .fa {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            cursor: pointer;
        }

        .register-container button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #5a9eff;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .register-container button:hover {
            background: #4a8ce4;
        }

        .error-message, .success-message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>
    <a href="manage_admins.php" class="back-button"><i class="fa fa-arrow-left"></i> Back</a>
    
    <div class="register-container">
        <h2>Create New Admin</h2>
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form action="add_admin.php" method="POST">
            <div class="input-group">
                <input type="text" name="username" placeholder="Username" required>
                <i class="fa fa-user"></i>
            </div>
            <div class="input-group">
                <input type="password" name="password" id="password" placeholder="Password" required>
                <i class="fa fa-eye" id="toggle-password" onclick="togglePassword()"></i>
            </div>
            <button type="submit">Add Admin</button>
        </form>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById('password');
            var toggleIcon = document.getElementById('toggle-password');
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
