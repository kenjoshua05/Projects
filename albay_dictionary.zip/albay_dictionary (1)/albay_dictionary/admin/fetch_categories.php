<script>
    fetch('admin/fetch_categories.php')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
    })
    .then(categories => {
        console.log(categories); // Debug statement to check response
        if (categories.error) {
            console.error(categories.error);
            return;
        }
        const selectElement = document.getElementById('category_id');
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            selectElement.appendChild(option);
        });
    })
    .catch(error => console.error('Error fetching categories:', error));

</script>