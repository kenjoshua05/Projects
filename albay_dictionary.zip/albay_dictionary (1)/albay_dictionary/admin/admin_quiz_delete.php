<?php
// admin_quiz_delete.php

// Include functions and establish a database connection
require_once 'functions.php';
session_start();
$con = db_connect();

// Check if quiz_id is provided
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $quiz_id = mysqli_real_escape_string($con, $_GET['id']);

    // Prepare SQL statements to delete related records
    $delete_user_quiz_answers_query = "
        DELETE uqa FROM user_quiz_answers uqa 
        JOIN questions q ON uqa.question_id = q.id 
        WHERE q.quiz_id = $quiz_id
    ";
    $delete_user_quiz_results_query = "
        DELETE FROM user_quiz_results 
        WHERE quiz_id = $quiz_id
    ";
    $delete_choices_query = "
        DELETE FROM choices 
        WHERE question_id IN (SELECT id FROM questions WHERE quiz_id = $quiz_id)
    ";
    $delete_questions_query = "
        DELETE FROM questions 
        WHERE quiz_id = $quiz_id
    ";
    $delete_quiz_query = "
        DELETE FROM quizzes 
        WHERE id = $quiz_id
    ";

    // Execute queries in the correct order
    mysqli_query($con, $delete_user_quiz_answers_query);
    mysqli_query($con, $delete_user_quiz_results_query);
    mysqli_query($con, $delete_choices_query);
    mysqli_query($con, $delete_questions_query);
    mysqli_query($con, $delete_quiz_query);

    // Set success message
    $_SESSION['message'] = "Quiz successfully deleted.";

    // Close database connection
    db_close($con);

    // Redirect to the quiz list page
    header("Location: admin_quiz_list.php");
    exit();
} else {
    // Redirect to the quiz list page if no quiz ID is provided
    header("Location: admin_quiz_list.php");
    exit();
}
?>
