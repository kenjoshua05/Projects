<?php
require('config.inc.php');
require('functions.php');

// Check if the request is for autocomplete and has a query
if (isset($_GET['query'])) {
    $searchQuery = trim($_GET['query']);
    $category = $_GET['category'] ?? 'all';

    // Prepare the SQL query to fetch matching results based on the category
    $sql = "SELECT word FROM dialect_data WHERE ";
    $conditions = [];

    if ($category === 'words') {
        $conditions[] = "word LIKE ?";
    } elseif ($category === 'example') {
        $conditions[] = "(example1 LIKE ? OR example2 LIKE ?)";
    } elseif ($category === 'meaning') {
        $conditions[] = "(tagalog_meaning LIKE ? OR english_meaning LIKE ?)";
    } elseif ($category === 'all') {
        $conditions[] = "(word LIKE ? OR example1 LIKE ? OR example2 LIKE ? OR tagalog_meaning LIKE ? OR english_meaning LIKE ?)";
    }

    // Join conditions
    $sql .= implode(' OR ', $conditions);

    // Prepare and execute the query
    $stmt = $con->prepare($sql);
    $searchTerm = '%' . $searchQuery . '%';
    
    if ($category === 'words') {
        $stmt->bind_param('s', $searchTerm);
    } elseif ($category === 'example') {
        $stmt->bind_param('ss', $searchTerm, $searchTerm);
    } elseif ($category === 'meaning') {
        $stmt->bind_param('ss', $searchTerm, $searchTerm);
    } elseif ($category === 'all') {
        $stmt->bind_param('sssss', $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch results and return as JSON
    $suggestions = [];
    while ($row = $result->fetch_assoc()) {
        $suggestions[] = $row['word'];
    }

    echo json_encode($suggestions); // Return the suggestions as JSON

    $stmt->close();
}
?>
