<?php defined('APP') or die('direct script access denied!'); ?>

<div class="class_16 hide" >
	<i class="bi bi-exclamation-circle-fill class_14">
	</i>
	<div class="class_15"  >
		Something went wrong!
		<br>
	</div>
</div>