<?php
include 'config.inc.php';  // Include the database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $category_name = htmlspecialchars($_POST['category_name']);

    // Insert the new category into the database
    $insert_query = "INSERT INTO forum_categories (name) VALUES ('$category_name')";

    if ($con->query($insert_query) === TRUE) {
        echo "New category created successfully!";
        header("Location: new_forum.php"); // Redirect to the home page after success
        exit;
    } else {
        echo "Error: " . $con->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        header {
            background-color: #B40023;
            color: white;
            padding: 15px 0;
            text-align: center;
        }
        h1 {
            margin: 0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #B40023;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 4px;
        }
        button:hover {
            background-color: #A1001E;
        }
    </style>
</head>
<body>

<header>
    <h1>Create New Category</h1>
</header>

<div class="container">
    <div class="form-container">
        <form action="add_category.php" method="POST">
            <label for="category_name">Category Name</label>
            <input type="text" id="category_name" name="category_name" required>

            <button type="submit">Create Category</button>
        </form>
    </div>
</div>

</body>
</html>
