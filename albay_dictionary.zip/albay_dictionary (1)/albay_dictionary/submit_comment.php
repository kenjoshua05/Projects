<?php
// Include the database connection file (config or db connection script)
include 'config.inc.php'; // adjust to your file path

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form values
    $post_id = $_POST['post_id'];
    // If the guest_name field is empty, default to "Guest"
    $guest_name = !empty($_POST['guest_name']) ? $_POST['guest_name'] : 'Guest';
    $content = $_POST['comment'];

    // Prepare and execute the insert query
    $stmt = $con->prepare("INSERT INTO forum_comments (post_id, guest_name, content) VALUES (?, ?, ?)");
    $stmt->bind_param('iss', $post_id, $guest_name, $content);

    if ($stmt->execute()) {
        // Get the thread_id associated with the post
        $query_thread_id = "SELECT thread_id FROM forum_posts WHERE id = $post_id";
        $result_thread = $con->query($query_thread_id);
        $thread_data = $result_thread->fetch_assoc();
        $thread_id = $thread_data['thread_id']; // Get the thread_id from the post
        
        // Redirect to the thread page
        header("Location: thread.php?id=$thread_id");
        exit();
    } else {
        // Handle error
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>
