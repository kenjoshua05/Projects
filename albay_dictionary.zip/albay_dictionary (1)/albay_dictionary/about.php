<?php
define('APP', true); // Define the APP constant to allow access
require_once 'functions.php'; // Include your functions.php file
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>
    <link rel="icon" href="bg/logo4.png" type="image/png">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
</head>
<body> 
<style>
		
		@keyframes appear{
			0%{
				opacity: 0;
			}
			100%{
				opacity: 1;
			}
		}

		.hide{
			display:none;
		}

	</style>
    <section class="class_1">
    <?php include('header.inc.php') ?>

        <div class="about1">
            <h4 style="color: rgb(77, 68, 68);">ABOUT US</h4>
            <h1 style="color: #00ab66;">Albay Dialects Hub: <br>A Web-based Learning Guide <br>in Mastering Albay’s Different <br>Basic Dialects</h1>
          </div>

        <div class="content1">
            <div class="paragraph">
                <h2 style=" color: #00ab66;">Albay Dialects Hub: Fostering Inclusive Community Development</h2>
                <p>
                    Language goes beyond simple communication; it holds the essence of cultural heritage, carrying the stories, 
                    traditions, and values of generations. Within its words lie the wisdom of the past and the identity of the present, 
                    shaping how communities perceive the world and interact with one another. Language acts as a bridge, connecting 
                    individuals to their roots and fostering a sense of belonging within their community. Its preservation is crucial, 
                    serving as a means to maintain cultural identity amidst the tide of modernization and globalization. 
                    Exploring language reveals the depth of cultural diversity and highlights the importance of linguistic heritage in 
                    preserving the richness of human expression. Thus, the efforts to protect and celebrate linguistic diversity are not 
                    only academic pursuits but essential endeavors in honoring the diversity of human experience.
                </p>
            </div>
            <div class="image">
                <img src="bg/mayon.jpg" alt="Your Image Description">
            </div>
        </div>
        
        <div class="content2">
            <div class="paragraph">
                <p>
                    The linguistic diversity within Albay Province, Philippines, presents a significant challenge for communication 
                    and cultural preservation. With various basic dialects prevalent across the region, residents often face barriers 
                    in understanding and mastering these linguistic variations. This lack of comprehension can hinder effective
                    communication, limit access to educational resources, and contribute to the erosion of cultural identity. 
                    Furthermore, the absence of centralized learning resources exacerbates these challenges, leaving individuals 
                    without a structured platform to enhance their linguistic proficiency.<br> <br class="space">The Albay Dialects Hub: A Web-Based 
                    Learning Guide in Mastering Albay's Different Basic Dialects represents a pivotal undertaking aimed at addressing 
                    the challenges posed by linguistic diversity and cultural preservation within Albay Province, Philippines. 
                    This study seeks to offer a comprehensive solution to the barriers encountered in understanding and mastering 
                    Albay's various basic dialects. Through accessible resources and interactive forums, individuals can bridge the 
                    gaps in communication and foster greater understanding and appreciation for Albay's linguistic heritage. </br>
                </p>
            </div>
            <div class="image">
                <img src="bg/daraga church.jpg" alt="Your Image Description">
            </div>
        </div>

        <footer class="footer">
            <div class="waves">
                <div class="wave" id="wave1"></div>
                <div class="wave" id="wave2"></div>
                <div class="wave" id="wave3"></div>
                <div class="wave" id="wave4"></div>
            </div>
            <ul class="social-icon">
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-twitter"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-linkedin"></ion-icon>
                </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="#">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
            </ul>
            <ul class="f-menu">
                <li class="menu__item"><a class="menu__link" href="#">Home</a></li>
                <li class="menu__item"><a class="menu__link" href="about.html">About</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Dialects</a></li>
                <li class="menu__item"><a class="menu__link" href="#">Forum</a></li>
            
            </ul>
            <p>2024 Albay Dialects | All Rights Reserved</p>
        </footer>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

        <br><br>
		<?php include('signup.inc.php') ?>
		<?php include('login.inc.php') ?>
    </section>
    <!-- Scroll to top button -->
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
</body>
</html>
