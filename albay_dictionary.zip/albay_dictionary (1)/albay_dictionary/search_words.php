<?php
require('config.inc.php');
require('functions.php');

// Check if search query and category are provided
if (isset($_GET['query']) && isset($_GET['category'])) {
    $query = mysqli_real_escape_string($con, $_GET['query']);
    $current_category = mysqli_real_escape_string($con, $_GET['category']);

    // Fetch words from dialect_data table based on search query and category
    $words_query = "
        SELECT id, word, english_meaning
        FROM dialect_data
        WHERE category_id = '$current_category'
        AND (word LIKE '%$query%' OR english_meaning LIKE '%$query%')
    ";
    $words_result = mysqli_query($con, $words_query);

    // Check for errors in the query
    if (!$words_result) {
        die("Database query failed: " . mysqli_error($con));
    }
} else {
    // If no search query or category, redirect or handle the case
    header("Location: error.php?message=No search query or category provided");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Results for Words</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <h1>Search Results for "<?php echo htmlspecialchars($query); ?>" in Category "<?php echo htmlspecialchars($current_category); ?>"</h1>
    <div class="word-grid">
        <?php while ($row = mysqli_fetch_assoc($words_result)) : ?>
            <a href="word.php?id=<?php echo $row['id']; ?>" class="word-card-link">
                <div class="word-card">
                    <h2><?php echo htmlspecialchars($row['word']); ?></h2>
                    <p><?php echo htmlspecialchars($row['english_meaning']); ?></p>
                </div>
            </a>
        <?php endwhile; ?>
    </div>
</body>
</html>
