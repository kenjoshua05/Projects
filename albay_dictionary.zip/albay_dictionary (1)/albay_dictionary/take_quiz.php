<?php
require('config.inc.php');
require('functions.php');

// Check if the user is logged in
if (!logged_in()) {
    header('Location: login.php'); // Redirect to login page
    exit;
}

// Get the quiz ID from the URL
$quiz_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($quiz_id == 0) {
    echo "Invalid quiz ID.";
    exit;
}

// Fetch the quiz details
$query = "SELECT * FROM quizzes WHERE id = $quiz_id";
$quiz = query($query);
if (!$quiz) {
    echo "Quiz not found.";
    exit;
}
$quiz = $quiz[0];

// Fetch maximum attempts for the quiz
$query = "SELECT max_attempts FROM quizzes WHERE id = $quiz_id";
$result = query($query);
if (!$result) {
    echo "Unable to fetch quiz settings.";
    exit;
}
$max_attempts = $result[0]['max_attempts'];

// Fetch number of attempts already made by the user
$user_id = $_SESSION['USER']['id']; // Assuming user ID is stored in the session
$query = "SELECT COUNT(*) AS attempts FROM user_quiz_results WHERE quiz_id = $quiz_id AND user_id = $user_id";
$result = query($query);
$attempts = $result[0]['attempts'];

// Check if the user has reached the maximum number of attempts
$attempts_left = $max_attempts - $attempts;

// Generate a new attempt_id
$attempt_id = time(); // Using time() to generate a unique ID
$_SESSION['attempt_id'] = $attempt_id; // Store the attempt_id in the session

// Fetch the questions and choices for the quiz
$query = "SELECT q.id as question_id, q.question_text, c.id as choice_id, c.choice_text
          FROM questions q
          LEFT JOIN choices c ON q.id = c.question_id
          WHERE q.quiz_id = $quiz_id";
$questions = query($query);

// Group the questions and choices
$quiz_data = [];
foreach ($questions as $question) {
    if (!isset($quiz_data[$question['question_id']])) {
        $quiz_data[$question['question_id']] = [
            'question_text' => $question['question_text'],
            'choices' => []
        ];
    }
    $quiz_data[$question['question_id']]['choices'][] = [
        'choice_id' => $question['choice_id'],
        'choice_text' => $question['choice_text']
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($quiz['title']) ?></title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="scripts.js" defer></script>
    <style>
        @keyframes appear {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .hide {
            display: none;
        }

        h1 {
            margin-bottom: 20px;
            color: #007BFF;
            text-align: center;
        }

        p {
            margin-bottom: 20px;
            color: #555;
            text-align: center;
        }

        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .question {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .question p {
            margin: 0 0 10px;
            color: #333;
        }

        .question div {
            margin-bottom: 10px;
        }

        .question input[type="radio"] {
            margin-right: 10px;
        }

        .question label {
            color: #333;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: block;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
<?php include('header.inc.php'); ?>

    <h1><?= htmlspecialchars($quiz['title']) ?></h1>
    <p><?= htmlspecialchars($quiz['description']) ?></p>
    
    <p>Maximum Attempts: <?= htmlspecialchars($max_attempts) ?></p>
    <p>Attempts Remaining: <?= htmlspecialchars($attempts_left) ?></p>

    <?php
    // Display error message if any
    $error_message = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : '';
    if ($error_message) {
        echo "<p style='color: red; text-align: center;'>$error_message</p>";
    }
    ?>

    <div class="form-container">
        <form id="quizForm" method="post" action="submit_quiz.php">
            <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">
            <input type="hidden" name="attempt_id" value="<?= $attempt_id ?>"> <!-- Include attempt_id -->
            <?php foreach ($quiz_data as $question_id => $question): ?>
                <div class="question">
                    <p><?= htmlspecialchars($question['question_text']) ?></p>
                    <?php foreach ($question['choices'] as $choice): ?>
                        <div>
                            <input type="radio" id="choice_<?= $choice['choice_id'] ?>" name="answers[<?= $question_id ?>]" value="<?= $choice['choice_id'] ?>" required>
                            <label for="choice_<?= $choice['choice_id'] ?>"><?= htmlspecialchars($choice['choice_text']) ?></label>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <button type="submit" <?= $attempts_left <= 0 ? 'disabled' : '' ?>>Submit Quiz</button>
        </form>
    </div>

    <!-- Include your signup and login modals here -->
    <?php include('signup.inc.php'); ?>
    <?php include('login.inc.php'); ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('quizForm').addEventListener('submit', function(event) {
            const form = event.target;
            const questions = form.querySelectorAll('.question');
            let allAnswered = true;

            questions.forEach(function(question) {
                const questionId = question.querySelector('input[type="radio"]').name;
                const selectedAnswer = form.querySelector(`input[name="${questionId}"]:checked`);

                if (!selectedAnswer) {
                    allAnswered = false;
                    question.style.border = '2px solid red'; // Highlight unanswered questions
                } else {
                    question.style.border = ''; // Remove highlight if answered
                }
            });

            if (!allAnswered) {
                event.preventDefault(); // Prevent form submission
                alert('Please answer all questions before submitting.');
            }
        });
    });
    </script>
    <button onclick="scrollToTop()" id="scrollBtn" title="Go to top"></button>
    <script src="script.js"></script>
</body>
</html>
