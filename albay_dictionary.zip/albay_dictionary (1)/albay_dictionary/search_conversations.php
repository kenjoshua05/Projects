<?php
require('config.inc.php');
require('functions.php');

// Initialize current_category with a default value
$current_category = "Undefined Category";

// Check if search query and category are provided
if (isset($_GET['query']) && isset($_GET['category'])) {
    $query = mysqli_real_escape_string($con, $_GET['query']);
    $current_category = mysqli_real_escape_string($con, $_GET['category']);

    // Fetch common conversations based on search query and category
    $common_query = "
        SELECT id, phrase, example 
        FROM common_conversations 
        WHERE category_id = '$current_category' 
        AND (phrase LIKE '%$query%' OR example LIKE '%$query%')
    ";
    $common_result = mysqli_query($con, $common_query);

    // Check for errors in the query
    if (!$common_result) {
        die("Database query failed: " . mysqli_error($con));
    }
} else {
    // If no search query or category, redirect or handle the case
    header("Location: error.php?message=No search query or category provided");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Results for Conversations</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <h1>Search Results for "<?php echo htmlspecialchars($query); ?>" in Category "<?php echo htmlspecialchars($current_category); ?>"</h1>
    <div class="conversation-list">
        <?php while ($row = mysqli_fetch_assoc($common_result)) : ?>
            <div class="conversation-item">
                <h3><?php echo htmlspecialchars($row['phrase']); ?></h3>
                <p><?php echo htmlspecialchars($row['example']); ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
