<?php defined('APP') or die('direct script access denied!'); ?>
<div class="class_13 hide" >
	<i class="bi bi-info-circle-fill class_14">
	</i>
	<div class="class_15"  >
		Your settings were saved successfully!
		<br>
	</div>
</div>